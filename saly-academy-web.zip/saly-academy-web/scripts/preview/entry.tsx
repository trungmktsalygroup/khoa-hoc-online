/* Bản xem thử 1 file: chạy CHÍNH code giao diện trong src/ bằng router theo dấu # (không cần máy chủ). */
import { Component, useEffect, useState, type ReactNode } from 'react';
import { createRoot } from 'react-dom/client';
import { CartProvider } from '@/components/shared/CartProvider';
import { Header } from '@/components/site/Header';
import { Footer } from '@/components/site/Footer';
import { LearnHeader } from '@/components/learn/LearnHeader';
import HomePage from '@/app/(site)/page';
import CoursesPage from '@/app/(site)/khoa-hoc/page';
import ToolsPage from '@/app/(site)/cong-cu/page';
import ActivityPage from '@/app/(site)/hoat-dong/page';
import BlogPage from '@/app/(site)/blog/page';
import ArticlePage from '@/app/(site)/blog/[slug]/page';
import AboutPage from '@/app/(site)/author/ly-pham/page';
import LoginPage from '@/app/(auth)/dang-nhap/page';
import LearnPage from '@/app/(learn)/hoc/[slug]/page';
import NotFound from '@/app/not-found';
import CheckoutPage from '@/app/(site)/thanh-toan/page';
import PackagePage from '@/app/(site)/khoa-hoc/[slug]/page';

// Form tư vấn: giả lập máy chủ trả về thành công
const realFetch = window.fetch.bind(window);
window.fetch = (input: RequestInfo | URL, init?: RequestInit) =>
  String(input).includes('/api/lead') ? Promise.resolve(new Response(JSON.stringify({ ok: true }), { status: 200, headers: { 'Content-Type': 'application/json' } })) : realFetch(input, init);

const TITLES: [RegExp, string][] = [
  [/^\/$/, 'SaLy Academy – Học mở quán từ người đã tự mở quán'], [/^\/khoa-hoc\/.+/, 'Thông tin khóa học'], [/^\/khoa-hoc/, 'Khóa học'], [/^\/cong-cu/, 'Công cụ cho chủ quán'], [/^\/hoat-dong/, 'Hoạt động'],
  [/^\/blog\/.+/, 'Bài viết'], [/^\/blog/, 'Blog'], [/^\/author\/ly-pham/, 'Tác giả Ly Phạm'], [/^\/dang-nhap/, 'Đăng nhập / Đăng ký'], [/^\/hoc\//, 'Trang học Online'], [/^\/thanh-toan/, 'Giỏ hàng & thanh toán'],
];
const getPath = () => (location.hash.replace(/^#/, '').split(/[?#]/)[0] || '/');

function Async({ load }: { load: () => Promise<ReactNode> }) {
  const [el, setEl] = useState<ReactNode>(null);
  useEffect(() => { let on = true; load().then((e) => on && setEl(e)).catch(() => on && setEl(<NotFound />)); return () => { on = false; }; }, [load]);
  return <>{el}</>;
}
class Boundary extends Component<{ children: ReactNode }, { err: boolean }> {
  state = { err: false };
  static getDerivedStateFromError() { return { err: true }; }
  render() { return this.state.err ? <NotFound /> : this.props.children; }
}
const Site = ({ children }: { children: ReactNode }) => (<><Header /><main id="noi-dung">{children}</main><Footer /></>);

function App() {
  const [path, setPath] = useState(getPath());
  useEffect(() => {
    const onHash = () => {
      const raw = location.hash.slice(1);
      if (raw && !raw.startsWith('/')) { document.getElementById(raw)?.scrollIntoView({ behavior: 'smooth' }); return; }
      const p = getPath(); const anchor = raw.split('#')[1];
      setPath((old) => { if (old !== p) window.scrollTo(0, 0); return p; });
      if (anchor) setTimeout(() => document.getElementById(anchor)?.scrollIntoView({ behavior: 'smooth' }), 300);
    };
    window.addEventListener('hashchange', onHash);
    return () => window.removeEventListener('hashchange', onHash);
  }, []);
  useEffect(() => { document.title = (TITLES.find(([r]) => r.test(path))?.[1] ?? 'SaLy Academy') + ' | SaLy Academy (bản xem thử)'; }, [path]);

  let page: ReactNode;
  const blog = path.match(/^\/blog\/([^/]+)/);
  const learn = path.match(/^\/hoc\/([^/]+)/);
  const pkg = path.match(/^\/khoa-hoc\/([^/]+)/);
  if (path === '/') page = <Site><HomePage /></Site>;
  else if (path === '/khoa-hoc') page = <Site><CoursesPage /></Site>;
  else if (pkg) page = <Site><Async key={pkg[1]} load={() => PackagePage({ params: Promise.resolve({ slug: pkg[1] }) })} /></Site>;
  else if (path === '/cong-cu') page = <Site><ToolsPage /></Site>;
  else if (path === '/hoat-dong') page = <Site><ActivityPage /></Site>;
  else if (path === '/blog') page = <Site><BlogPage /></Site>;
  else if (blog) page = <Site><Async key={blog[1]} load={() => ArticlePage({ params: Promise.resolve({ slug: blog[1] }) })} /></Site>;
  else if (path === '/thanh-toan') page = <Site><CheckoutPage /></Site>;
  else if (path === '/author/ly-pham' || path === '/giang-vien-ly-pham') page = <Site><AboutPage /></Site>;
  else if (path === '/dang-nhap') page = <><Header /><main id="noi-dung"><LoginPage /></main></>;
  else if (learn) page = <div className="min-h-screen bg-[#F7F5F2]"><LearnHeader /><main id="noi-dung"><LearnPage /></main></div>;
  else page = <NotFound />;
  return <CartProvider><Boundary key={path}>{page}</Boundary></CartProvider>;
}

createRoot(document.getElementById('app')!).render(<App />);
