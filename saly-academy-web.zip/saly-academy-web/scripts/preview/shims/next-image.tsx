import type { CSSProperties, ImgHTMLAttributes } from 'react';
declare global { interface Window { __IMG__?: Record<string, string> } }
type Props = Omit<ImgHTMLAttributes<HTMLImageElement>, 'src'> & { src: string; fill?: boolean; priority?: boolean; sizes?: string };
export default function Image({ src, fill, priority, sizes, style, alt, ...rest }: Props) {
  const real = (typeof window !== 'undefined' && window.__IMG__?.[src]) || src;
  const s: CSSProperties = fill ? { position: 'absolute', inset: 0, width: '100%', height: '100%', ...style } : { ...style };
  return <img src={real} alt={alt ?? ''} style={s} loading="eager" decoding="async" {...rest} />;
}
