import { useEffect, useState } from 'react';
const parse = () => { const h = location.hash.replace(/^#/, '') || '/'; const [path, q = ''] = h.split('?'); return { path: path || '/', q }; };
function useHash() {
  const [h, setH] = useState(parse());
  useEffect(() => { const f = () => setH(parse()); window.addEventListener('hashchange', f); return () => window.removeEventListener('hashchange', f); }, []);
  return h;
}
export const usePathname = () => useHash().path;
export const useSearchParams = () => new URLSearchParams(useHash().q);
export const useRouter = () => ({ push: (p: string) => { location.hash = p; }, replace: (p: string) => { location.hash = p; }, back: () => history.back() });
export function notFound(): never { throw new Error('NOT_FOUND'); }
