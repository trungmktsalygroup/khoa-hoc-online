import type { AnchorHTMLAttributes, ReactNode } from 'react';
export const toHash = (href: string) => (href.startsWith('/') ? '#' + href : href);
export default function Link({ href, children, ...rest }: AnchorHTMLAttributes<HTMLAnchorElement> & { href: string; children?: ReactNode }) {
  return <a href={toHash(href)} {...rest}>{children}</a>;
}
