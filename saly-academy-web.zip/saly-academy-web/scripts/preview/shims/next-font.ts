export function Be_Vietnam_Pro(_: unknown) { return { variable: '', className: '' }; }
export function Oswald(_: unknown) { return { variable: '', className: '' }; }
export function Pacifico(_: unknown) { return { variable: '', className: '' }; }
