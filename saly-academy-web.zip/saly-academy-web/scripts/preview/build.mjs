// Đóng gói toàn bộ giao diện thành 1 file HTML để xem thử / gửi link test: node scripts/preview/build.mjs
import { build } from 'esbuild';
import { execSync } from 'node:child_process';
import { readFileSync, readdirSync, writeFileSync, mkdirSync } from 'node:fs';
import path from 'node:path';

const root = path.resolve(import.meta.dirname, '../..');
const out = path.join(root, 'preview-dist');
mkdirSync(out, { recursive: true });
const shim = (f) => path.join(root, 'scripts/preview/shims', f);

const js = await build({
  entryPoints: [path.join(root, 'scripts/preview/entry.tsx')],
  bundle: true, minify: true, write: false, format: 'iife', target: 'es2020', jsx: 'automatic',
  tsconfig: path.join(root, 'tsconfig.json'),
  alias: { 'next/image': shim('next-image.tsx'), 'next/link': shim('next-link.tsx'), 'next/navigation': shim('next-navigation.ts'), 'next/font/google': shim('next-font.ts'), next: shim('next-types.ts') },
  define: { 'process.env.NODE_ENV': '"production"', 'process.env.NEXT_PUBLIC_SITE_URL': '"https://saly.academy"', 'process.env.NEXT_PUBLIC_PREVIEW': '"1"' },
  loader: { '.css': 'empty' },
});

execSync(`npx @tailwindcss/cli -i src/app/globals.css -o ${out}/tw.css --minify`, { cwd: root, stdio: 'inherit' });
const css = readFileSync(`${out}/tw.css`, 'utf8');

const img = {};
for (const f of readdirSync(path.join(root, 'public/images'), { recursive: true })) {
  const full = path.join(root, 'public/images', f);
  if (!/\.(png|jpe?g|svg|webp)$/i.test(f)) continue;
  const ext = f.split('.').pop().toLowerCase();
  const mime = ext === 'png' ? 'image/png' : ext === 'svg' ? 'image/svg+xml' : ext === 'webp' ? 'image/webp' : 'image/jpeg';
  img['/images/' + f.split(path.sep).join('/')] = `data:${mime};base64,` + readFileSync(full).toString('base64');
}
// Ảnh dùng trong CSS (ảnh ghép video)
const cssFinal = css;
// Font nhúng sẵn (base64) – không phụ thuộc Google Fonts, tránh lỗi font khi môi trường xem thử chặn tải ngoài
const fontsInline = readFileSync(path.join(path.dirname(new URL(import.meta.url).pathname), 'fonts/fonts-inline.css'), 'utf8');
const bundle = js.outputFiles[0].text.replaceAll('url(/images/video-shorts-sprite.jpg)', `url(${img['/images/video-shorts-sprite.jpg']})`);

const html = `<!doctype html>
<html lang="vi"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>SaLy Academy (bản xem thử)</title>
<style>${fontsInline}</style>
<style>:root{--font-be-vietnam:'Be Vietnam Pro';--font-oswald:'Oswald';--font-pacifico:'Pacifico'}${cssFinal}
/* Trang xem thử được bọc trong khung có sẵn font hệ thống 14px – ép lại font & cỡ chữ gốc của web */
html,body,#app{font-family:'Be Vietnam Pro',system-ui,-apple-system,'Segoe UI',sans-serif!important}
#app{font-size:16px;line-height:1.5;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale;color:var(--color-ink,#1E1B18)}
#app .font-display{font-family:'Oswald','Arial Narrow',sans-serif!important}
#app .font-script{font-family:'Pacifico',cursive!important}</style>
</head><body class="font-sans antialiased"><div id="app"></div>
<script>window.__IMG__=${JSON.stringify(img)};</script>
<script>${bundle.replace(/<\/script/gi, '<\\/script')}</script>
</body></html>`;
writeFileSync(path.join(out, 'saly-academy-preview.html'), html);
console.log('✓ preview-dist/saly-academy-preview.html', (html.length / 1e6).toFixed(1) + ' MB');
