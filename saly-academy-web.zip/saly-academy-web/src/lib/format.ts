import type { CSSProperties } from 'react';
export const vnd = (n: number) => n.toLocaleString('vi-VN') + 'đ';
export const discountPercent = (price: number, old: number) => Math.round(((old - price) / old) * 100);
/** Vị trí ô trong ảnh ghép video 6×3 */
export const spriteStyle = (i: number): CSSProperties => ({
  backgroundImage: 'url(/images/video-shorts-sprite.jpg)',
  backgroundSize: '600% 300%',
  backgroundPosition: `${(i % 6) * 20}% ${Math.floor(i / 6) * 50}%`,
});

/** Ô video trong khung ngang 16:9 – lấy phần trên của ảnh dọc */
export const spriteCoverStyle = (i: number): CSSProperties => {
  const r = Math.floor(i / 6);
  const H = 9 / 16, tileH = 4 / 3, total = 3 * tileH;
  return {
    backgroundImage: 'url(/images/video-shorts-sprite.jpg)',
    backgroundSize: `600% ${(total / H) * 100}%`,
    backgroundPosition: `${(i % 6) * 20}% ${((r * tileH) / (total - H)) * 100}%`,
  };
};
