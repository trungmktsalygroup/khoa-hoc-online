/**
 * Một số môi trường xem thử (link test trên claude.ai) chặn trình phát nhúng từ trang ngoài.
 * Khi đó hiện ảnh bìa + nút mở video ở tab mới thay vì khung bị chặn.
 */
export const embedBlocked = () =>
  typeof window !== 'undefined' && /claude|anthropic/i.test(window.location.hostname);
