import { SITE } from '@/data/site';

/**
 * Dữ liệu có cấu trúc (schema.org) – giúp Google và các trợ lý AI (SEO / AEO / GEO)
 * hiểu đúng: trang là gì, của ai, trả lời câu hỏi nào.
 */
export const abs = (path: string) => (path.startsWith('http') ? path : `${SITE.url}${path}`);

export const ORG_ID = `${SITE.url}/#to-chuc`;
export const PERSON_ID = `${SITE.url}/author/ly-pham#ly-pham`;

export const organization = () => ({
  '@context': 'https://schema.org',
  '@type': 'EducationalOrganization',
  '@id': ORG_ID,
  name: SITE.name,
  alternateName: SITE.tagline,
  url: SITE.url,
  logo: abs('/images/logo-saly-academy.png'),
  description: `Học viện pha chế và kinh doanh quán đồ uống của Cô Ly Phạm – ${SITE.stats.years} năm kinh nghiệm, ${SITE.stats.students} học viên.`,
  legalName: SITE.company,
  taxID: SITE.taxCode,
  email: SITE.email,
  telephone: '+84964220098',
  address: { '@type': 'PostalAddress', streetAddress: 'Số 17, Đường 39, KDC Vạn Phúc', addressLocality: 'Thủ Đức', addressRegion: 'TP. Hồ Chí Minh', addressCountry: 'VN' },
  founder: { '@type': 'Person', '@id': PERSON_ID, name: 'Ly Phạm' },
  sameAs: [SITE.links.facebook, SITE.links.youtube, SITE.links.tiktok, SITE.links.linkedin],
});

export const breadcrumb = (items: { name: string; path: string }[]) => ({
  '@context': 'https://schema.org',
  '@type': 'BreadcrumbList',
  itemListElement: items.map((it, i) => ({ '@type': 'ListItem', position: i + 1, name: it.name, item: abs(it.path) })),
});

export const faqPage = (list: { q: string; a: string }[]) => ({
  '@context': 'https://schema.org',
  '@type': 'FAQPage',
  mainEntity: list.map((f) => ({ '@type': 'Question', name: f.q, acceptedAnswer: { '@type': 'Answer', text: f.a } })),
});

/** "dd/mm/yyyy" → "yyyy-mm-dd" */
export const isoDate = (d?: string) => (d && /^\d{2}\/\d{2}\/\d{4}$/.test(d) ? d.split('/').reverse().join('-') : undefined);
