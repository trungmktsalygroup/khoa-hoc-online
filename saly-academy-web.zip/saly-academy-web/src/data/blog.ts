export type Post = { slug: string; category: string; title: string; image: string; excerpt?: string; date?: string; readMinutes?: number };

export const BLOG_CATEGORIES = ['Tất cả bài viết', 'Kiến thức pha chế', 'Công thức đồ uống', 'Kinh doanh quán', 'Mở quán khởi nghiệp', 'Nguyên liệu & dụng cụ', 'Câu chuyện học viên', 'Tin tức & sự kiện'];

export const FEATURED_POST: Post = {
  slug: 'tra-quyt-tuoi',
  category: 'Công thức đồ uống',
  title: 'Công thức trà quýt tươi thơm ngon, chuẩn vị kinh doanh',
  image: '/images/blog/tra-quyt-tuoi/cong-thuc-tra-quyt-tuoi-thom-ngon.jpg',
  excerpt: 'Món trà trái cây chua ngọt thanh mát từ quýt tươi và trà đen đậm vị. Công thức cho ly 500ml và 700ml, mẹo pha giữ vị chuẩn, cách tính giá cost để đưa vào menu quán.',
  date: '28/08/2026',
  readMinutes: 13,
};

export const POSTS: Post[] = [
  { slug: 'mo-quan-ca-phe-can-bao-nhieu-von', category: 'Mở quán khởi nghiệp', title: 'Mở quán cà phê, trà sữa cần bao nhiêu vốn? Vốn tham khảo theo 4 mô hình', image: '/images/mo-hinh/kiosk-tra.jpg', excerpt: 'Vốn mở quán theo từng mô hình: xe trà 50–70 triệu, quán mang đi 100–200 triệu, quán có chỗ ngồi 300–500 triệu, quy mô lớn từ 500 triệu – kèm các khoản chi cần dự trù.', date: '06/10/2026', readMinutes: 7 },
  { slug: 'phan-biet-3-loai-tra', category: 'Kiến thức pha chế', title: 'Phân biệt 3 loại trà chính và cách chọn trà phù hợp cho từng món', image: '/images/thumb-bai-3.jpg' },
  { slug: 'u-tra-dung-cach', category: 'Kiến thức pha chế', title: 'Ủ trà đúng cách và những lưu ý quan trọng khi bảo quản', image: '/images/thumb-bai-5.jpg' },
  { slug: 'chon-dung-cu-u-tra', category: 'Nguyên liệu & dụng cụ', title: 'Chọn dụng cụ ủ trà sao cho hiệu quả và tiết kiệm', image: '/images/thumb-bai-4.jpg' },
  { slug: 'tra-trai-cay-truoc-khi-dua-vao-menu', category: 'Công thức đồ uống', title: 'Trà trái cây: những điều cần biết trước khi đưa vào menu', image: '/images/thumb-bai-1.jpg' },
  { slug: 'tang-hieu-suat-quay-gio-cao-diem', category: 'Kinh doanh quán', title: 'Tăng hiệu suất quầy pha chế vào giờ cao điểm', image: '/images/thumb-bai-2.jpg' },
  { slug: 'bo-tri-quay-pha-che-quan-nho', category: 'Kinh doanh quán', title: 'Bố trí quầy pha chế gọn cho quán nhỏ', image: '/images/video-bai-hoc.jpg' },
];

export const ALL_POSTS: Post[] = [FEATURED_POST, ...POSTS];
