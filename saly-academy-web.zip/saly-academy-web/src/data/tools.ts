export type ToolIcon = 'map' | 'calc' | 'chart' | 'wallet' | 'scale' | 'cal';
export type Tool = { name: string; desc: string; group: string; icon: ToolIcon; tile: string; thumbBg: string; price: string; live: boolean; href: string };

export const TOOL_GROUPS = ['Tất cả', 'Mở quán', 'Chi phí & giá bán', 'Vận hành', 'Marketing'];

// TODO: 4 công cụ cuối là đề xuất – cập nhật danh sách thật
export const TOOLS: Tool[] = [
  { name: 'Mở Quán', desc: 'Nhập số vốn, nhận ngay kế hoạch mở quán phù hợp với ngân sách của bạn.', group: 'Mở quán', icon: 'map', tile: '#0D824B', thumbBg: '#DCEFE3', price: 'Miễn phí', live: true, href: 'https://mo-quan-app.vercel.app' },
  { name: 'Tính cost đồ uống', desc: 'Nhập định lượng và giá nguyên liệu, ra giá vốn từng ly và giá bán đề xuất.', group: 'Chi phí & giá bán', icon: 'calc', tile: '#F29546', thumbBg: '#FDE7D3', price: 'Miễn phí', live: true, href: '#tinh-gia-von' },
  { name: 'Tính điểm hòa vốn', desc: 'Biết mỗi ngày cần bán bao nhiêu ly để quán đủ bù chi phí.', group: 'Chi phí & giá bán', icon: 'chart', tile: '#0A7D45', thumbBg: '#E2ECE5', price: '[Miễn phí / PRO]', live: false, href: '#' },
  { name: 'Dự toán vốn setup quán', desc: 'Liệt kê hạng mục máy móc, dụng cụ, sửa chữa để không vượt ngân sách.', group: 'Mở quán', icon: 'wallet', tile: '#C9621A', thumbBg: '#F8E4D2', price: '[Miễn phí / PRO]', live: false, href: '#' },
  { name: 'Nhân công thức theo mẻ', desc: 'Đổi định lượng từ 1 ly sang mẻ lớn để pha sẵn đầu ca, không lệch vị.', group: 'Vận hành', icon: 'scale', tile: '#0C864A', thumbBg: '#DCEDE2', price: '[Miễn phí / PRO]', live: false, href: '#' },
  { name: 'Lịch đăng bài cho quán', desc: 'Gợi ý nội dung đăng mỗi tuần cho trang bán hàng của quán.', group: 'Marketing', icon: 'cal', tile: '#E5761F', thumbBg: '#FFEBD8', price: '[Miễn phí / PRO]', live: false, href: '#' },
];
