// Mốc vốn & mô hình: xem PACKAGES trong src/data/packages.ts

export const FAQS = [
  { q: 'Khóa học dành cho ai?', a: 'Cho người có đam mê pha chế và đang ấp ủ mở quán, kể cả khi chưa biết gì. Người đã có quán muốn nâng cao kỹ năng pha chế và kinh doanh cũng học được.' },
  { q: 'Ngoài pha chế, khóa học còn dạy gì?', a: 'Quản lý, marketing, tối ưu chi phí, tính giá cost và các chiến lược kinh doanh F&B để quán vận hành hiệu quả.' },
  { q: 'Học Online có được hỗ trợ trực tiếp không?', a: 'Có. Giảng viên hỗ trợ qua các buổi tư vấn trực tiếp 1-1 hoặc nhóm nhỏ trên Zoom/Meet để giải đáp thắc mắc trong quá trình học.' },
  { q: 'Chưa biết nên mở mô hình nào thì học gói nào?', a: 'Không sao – phần lớn học viên cũng bắt đầu như vậy. Chọn kiểu quán bạn đang hình dung ở mục “Bước đầu tiên” trên trang chủ, hoặc để lại số điện thoại để tư vấn viên giúp bạn xác định mô hình và lộ trình phù hợp.' },
  { q: 'Mua nguyên liệu, dụng cụ ở đâu?', a: 'SaLy Shop cung cấp nguyên liệu và dụng cụ pha chế, đúng loại được dùng trong khóa học.' },
];

export const CONSULT_TOPICS = ['Học phí', 'Lịch khai giảng', 'Khóa học Offline', 'Khóa học Online', 'Nguyên liệu pha chế'];

/** Câu chuyện học viên – số liệu theo saly.academy */
export const TESTIMONIALS = [
  { name: 'Chị Thúy', store: 'The RIO Coffee & Tea', place: 'Long Hải, Vũng Tàu', cohort: 'K34', avatar: '/images/hv-avatar-thuy.png', photo: '/images/hv-thuy-rio.jpg',
    stats: [['856 triệu', 'doanh thu quý II/2024'], ['10 triệu', 'doanh thu trung bình mỗi ngày']],
    quote: 'Bí quyết thật sự không chỉ ở đồ uống, mà ở cách quản lý chi phí, làm marketing và tạo trải nghiệm tốt cho khách.' },
  { name: 'Chị Thúy Vinh', store: 'Phố Cổ Coffee & Tea', place: 'Long Khánh', cohort: 'K32', avatar: '/images/hv-avatar-thuy-vinh.png', photo: '/images/hv-thuy-vinh-pho-co.jpg',
    stats: [['90 triệu', 'doanh thu trung bình/tháng'], ['173 triệu', 'tháng cao nhất']],
    quote: 'Ở đây không chỉ học pha chế mà còn được hướng dẫn tính giá cost, quản lý thu chi và xây chiến lược marketing.' },
  { name: 'Chị Trúc Phương', store: 'Lucky Tea & Coffee', place: 'Buôn Ma Thuột', cohort: 'K49', avatar: '/images/hv-avatar-truc-phuong.png', photo: '/images/hv-truc-phuong-lucky.jpg',
    stats: [['71 triệu', 'tháng cao nhất'], ['3,3 triệu', 'doanh thu trung bình mỗi ngày']],
    quote: 'Khởi nghiệp với kinh nghiệm gần như bằng 0, học xong mình đủ tự tin mở Lucky Tea & Coffee.' },
  { name: 'Anh Tài', store: 'Tiệm Trà Ngố', place: 'Bình Thạnh, TP.HCM', cohort: 'K19', avatar: '/images/hv-avatar-tai.png', photo: '/images/hv-tai-tra-ngo.jpg',
    stats: [['71 triệu', 'tháng cao nhất'], ['Tạp dề bạc', 'trên GrabFood']],
    quote: 'Sau khóa học mình chuyển sang mặt bằng ổn định và đầu tư bán online, quán nhanh chóng được khách trẻ yêu thích.' },
] as const;

/** Đặc quyền học viên PRO – theo saly.academy */
export const PERKS = [
  { title: 'Học trọn đời, cập nhật liên tục', text: 'Nhận thêm công thức mới, chiến lược kinh doanh và xu hướng thị trường mà không trả thêm phí.' },
  { title: 'Trọn bộ video chất lượng cao', text: 'Bài giảng quay rõ nét, theo lộ trình bài bản. Học mọi lúc, mọi nơi trên điện thoại.' },
  { title: 'Cộng đồng học viên riêng', text: 'Tham gia cộng đồng của Cô Ly Phạm để hỏi đáp, chia sẻ kinh nghiệm với những người cùng mở quán.' },
  { title: 'Hỗ trợ trực tiếp từ giảng viên', text: 'Buổi hỗ trợ định kỳ qua Zoom/Meet, có buổi 1-1 hoặc nhóm nhỏ trong suốt quá trình học và khởi nghiệp.' },
] as const;

/** Hành trình Cô Ly – theo saly.academy & lypham.vn. Ảnh 2017, 2020, 2023 đã có sẵn năm trên ảnh. */
export const TIMELINE = [
  { year: '2017', title: 'Khởi nguồn đam mê pha chế', photo: '/images/hanh-trinh/2017-luc-coffee.jpg', w: 760, h: 725, yearOnPhoto: true,
    text: 'Còn là sinh viên năm cuối, Ly Phạm và Hồ Đăng Sang dùng vốn tích góp, vay mượn để khai trương Lục Coffee & Tea đầu tiên tại Bình Thạnh vào tháng 7/2017.' },
  { year: '2019', title: 'Định hình và phát triển', photo: '/images/hanh-trinh/2019-lop-hoc.jpg', w: 640, h: 480, yearOnPhoto: false,
    text: 'Vượt qua nhiều thất bại khi xây thương hiệu và vận hành, Ly cải thiện dần sản phẩm, dịch vụ, mô hình và bắt đầu chia sẻ lại kinh nghiệm qua những lớp học nhỏ.' },
  { year: '2020', title: 'Bước ngoặt mùa dịch', photo: '/images/hanh-trinh/2020-day-pha-che.jpg', w: 760, h: 725, yearOnPhoto: true,
    text: 'Doanh thu gần như bằng 0, quán chuyển sang bán online và ứng dụng công nghệ – vừa giữ vững thương hiệu, vừa mở rộng các lớp đào tạo pha chế.' },
  { year: '2023', title: 'Thành lập SaLy Academy', photo: '/images/hanh-trinh/2023-khai-truong-saly-academy.jpg', w: 528, h: 480, yearOnPhoto: true,
    text: 'Học viện đào tạo pha chế và kinh doanh F&B chính thức khai trương, đồng hành cùng hàng ngàn học viên trên con đường mở quán.' },
] as const;

/** Video giới thiệu khóa học trên trang chủ */
export const INTRO_VIDEO = {
  id: 'XtenzcnEaQE',
  title: 'SaLy Academy | Khóa học pha chế toàn diện dành cho người khởi nghiệp – Giới thiệu',
  thumb: '/images/video-gioi-thieu.jpg',
};

/** Ảnh chụp lời khen, tin nhắn của học viên – nguồn: lypham.vn. Mỗi mảng là 1 cột chạy. */
const F = (n: string, w: number, h: number) => ({ src: `/images/danh-gia/${n}`, w, h });
export const FEEDBACK_COLUMNS = [
  [F('danh-gia-chi-thao-vo.jpg', 520, 1125), F('fb1.jpg', 259, 348), F('fb5.jpg', 260, 349), F('fb9.jpg', 259, 348)],
  [F('fb2.jpg', 259, 348), F('danh-gia-tich-cuc-tu-hoc-vien.jpg', 520, 1191), F('fb6.jpg', 260, 349), F('fb10.jpg', 259, 349)],
  [F('fb3.jpg', 259, 348), F('fb7.jpg', 259, 348), F('danh-gia-cuc-ki-tot.jpg', 520, 1191), F('fb12.jpg', 259, 349)],
  [F('fb4.jpg', 260, 349), F('fb8.jpg', 259, 348), F('fb14.jpg', 259, 348), F('danh-gia-chi-tuyet-ngan.jpg', 520, 1126)],
];

/** Ảnh quán học viên – bố cục ghép đúng theo lypham.vn (x, y, w, h tính theo % khung 1410×1015) */
export const STUDENT_SHOPS = [
  { src: '/images/quan-hoc-vien/hsv1.jpg', iw: 263, ih: 162, x: 11.16, y: 0.00, w: 15.79, h: 13.82 },
  { src: '/images/quan-hoc-vien/quan-cafe-hoc-vien-saly-academy-1.jpg', iw: 560, ih: 420, x: 5.58, y: 15.51, w: 21.43, h: 13.94 },
  { src: '/images/quan-hoc-vien/hsv3.jpg', iw: 273, ih: 276, x: 0.00, y: 31.02, w: 16.38, h: 23.01 },
  { src: '/images/quan-hoc-vien/hsv4.jpg', iw: 278, ih: 247, x: 5.58, y: 56.04, w: 16.69, h: 20.68 },
  { src: '/images/quan-hoc-vien/di-tham-quan-cua-hoc-vien.jpg', iw: 299, ih: 168, x: 9.00, y: 78.65, w: 17.94, h: 14.36 },
  { src: '/images/quan-hoc-vien/hsv6.jpg', iw: 151, ih: 126, x: 17.83, y: 31.02, w: 9.06, h: 10.64 },
  { src: '/images/quan-hoc-vien/chi-phuong-quan-lucky-tea.jpg', iw: 199, ih: 126, x: 17.83, y: 43.54, w: 11.94, h: 10.80 },
  { src: '/images/quan-hoc-vien/hsv8.jpg', iw: 216, ih: 260, x: 28.39, y: 2.84, w: 12.96, h: 22.24 },
  { src: '/images/quan-hoc-vien/hsv9.jpg', iw: 216, ih: 180, x: 28.39, y: 27.02, w: 12.96, h: 15.15 },
  { src: '/images/quan-hoc-vien/quan-cafe-hoc-vien-1.jpg', iw: 560, ih: 420, x: 31.21, y: 43.78, w: 10.09, h: 10.52 },
  { src: '/images/quan-hoc-vien/hsv11.jpg', iw: 294, ih: 247, x: 23.65, y: 56.04, w: 17.65, h: 20.72 },
  { src: '/images/quan-hoc-vien/hsv12.jpg', iw: 216, ih: 228, x: 28.33, y: 78.65, w: 12.96, h: 18.97 },
  { src: '/images/quan-hoc-vien/quan-tai-buon-me-thuot.jpg', iw: 168, ih: 168, x: 42.74, y: 7.25, w: 10.09, h: 14.01 },
  { src: '/images/quan-hoc-vien/the-rio-coffee.jpg', iw: 335, ih: 173, x: 42.74, y: 23.27, w: 20.11, h: 14.81 },
  { src: '/images/quan-hoc-vien/hsv15.jpg', iw: 336, ih: 296, x: 42.74, y: 39.69, w: 20.11, h: 24.77 },
  { src: '/images/quan-hoc-vien/hsv16.jpg', iw: 216, ih: 359, x: 42.74, y: 66.39, w: 12.96, h: 29.42 },
  { src: '/images/quan-hoc-vien/hsv18.jpg', iw: 336, ih: 255, x: 64.40, y: 25.10, w: 12.96, h: 18.65 },
  { src: '/images/quan-hoc-vien/quan-hoc-vien.jpg', iw: 560, ih: 420, x: 64.40, y: 45.78, w: 19.99, h: 21.45 },
  { src: '/images/quan-hoc-vien/quan-cafe-hoc-vien-k59.jpg', iw: 560, ih: 420, x: 57.14, y: 69.06, w: 12.96, h: 16.26 },
  { src: '/images/quan-hoc-vien/quan-pho-co.jpg', iw: 216, ih: 133, x: 57.14, y: 87.24, w: 12.96, h: 11.39 },
  { src: '/images/quan-hoc-vien/hsv21.jpg', iw: 213, ih: 126, x: 71.55, y: 70.22, w: 12.79, h: 10.83 },
  { src: '/images/quan-hoc-vien/di-tham-quan-hoc-vien-o-tinh.jpg', iw: 213, ih: 165, x: 71.55, y: 82.73, w: 12.79, h: 13.93 },
  { src: '/images/quan-hoc-vien/hinh-web-2.jpg', iw: 560, ih: 420, x: 78.81, y: 23.27, w: 15.48, h: 20.55 },
  { src: '/images/quan-hoc-vien/quan-hoc-vien-khai-truong-dep.jpg', iw: 206, ih: 168, x: 85.84, y: 45.78, w: 12.36, h: 14.16 },
  { src: '/images/quan-hoc-vien/quan-hoc-vien-1.jpg', iw: 560, ih: 420, x: 85.84, y: 61.80, w: 14.11, h: 29.12 },
];
