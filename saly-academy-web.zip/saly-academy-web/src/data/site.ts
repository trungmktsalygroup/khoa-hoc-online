export const SITE = {
  name: 'SaLy Academy',
  tagline: 'Ly Phạm – Dạy Pha Chế',
  url: process.env.NEXT_PUBLIC_SITE_URL ?? 'https://saly.academy',
  hotline: '0964 220 098',
  hotlineTel: 'tel:0964220098',
  email: 'support@lypham.vn',
  company: 'CÔNG TY TNHH THƯƠNG MẠI VÀ DỊCH VỤ SA LY GROUP',
  address: 'Số 17, Đường 39, KDC Vạn Phúc, Thủ Đức, TP.HCM',
  taxCode: '0317808766',
  slogan: 'Lan tỏa đam mê – Nâng tầm pha chế',
  /** Bản demo: đăng nhập/đăng ký nhận thông tin bất kỳ. TODO: đổi thành false khi nối hệ thống tài khoản thật */
  demoMode: true,
  stats: { years: '8+', students: '6.000+', videos: '150+', freeLessons: '30+' },
  links: {
    moQuanApp: 'https://mo-quan-app.vercel.app',
    /** Nút "Xem kế hoạch chi tiết" ở khối chọn số vốn (trang chủ) */
    capitalPlanApp: 'https://demo-app-qua-tang-mkt.vercel.app/',
    book: 'https://sachphache.lypham.vn/',
    shop: 'https://salyshop.vn/',
    tiktok: 'https://www.tiktok.com/@lyphamdayphache',
    facebook: 'https://www.facebook.com/LyPham8995',
    linkedin: 'https://www.linkedin.com/in/lyphamphache/',
    youtube: 'https://www.youtube.com/@LyPham-Dayphache',
  },
} as const;

/** Menu chính – thống nhất trên mọi trang */
export const NAV = [
  { label: 'Trang chủ', href: '/' },
  { label: 'Khóa học', href: '/khoa-hoc' },
  { label: 'Công cụ', href: '/cong-cu' },
  { label: 'Hoạt động', href: '/hoat-dong' },
  { label: 'Blog', href: '/blog' },
  { label: 'Về Cô Ly Phạm', href: '/author/ly-pham' },
] as const;

export const FOOTER_COLUMNS = [
  { title: 'Học cùng SaLy', links: [
    { label: 'Khóa học Online', href: '/khoa-hoc' },
    { label: 'Khóa học Offline', href: '/khoa-hoc' },
    { label: 'Lịch khai giảng', href: '/hoat-dong' },
    { label: 'Ưu đãi khóa học', href: '/khoa-hoc' },
    { label: 'Hỗ trợ học lại miễn phí', href: '#' },
  ] },
  { title: 'Tài nguyên', links: [
    { label: 'Công cụ cho chủ quán', href: '/cong-cu' },
    { label: 'Blog', href: '/blog' },
    { label: 'Công thức pha chế', href: '/blog' },
    { label: 'Sách Làm Chủ Từ Đam Mê Pha Chế', href: 'https://sachphache.lypham.vn/' },
    { label: 'Nguyên liệu SaLy Shop', href: 'https://salyshop.vn/' },
  ] },
  { title: 'Về chúng tôi', links: [
    { label: 'Về Cô Ly Phạm', href: '/author/ly-pham' },
    { label: 'Hoạt động', href: '/hoat-dong' },
    { label: 'Câu hỏi thường gặp', href: '/#cau-hoi' },
    { label: 'Chính sách thanh toán', href: '#' },
    { label: 'Điều khoản & bảo mật', href: '#' },
  ] },
] as const;

/** Thông tin nhận chuyển khoản – TODO: điền tài khoản thật trước khi chạy */
export const PAYMENT = {
  bank: '[Tên ngân hàng]',
  accountNo: '[Số tài khoản]',
  accountName: '[Tên chủ tài khoản]',
  /** Mã giảm giá dùng thử trên giao diện – thay bằng kiểm tra mã ở máy chủ */
  demoCoupons: { SALY10: 0.1 } as Record<string, number>,
};
