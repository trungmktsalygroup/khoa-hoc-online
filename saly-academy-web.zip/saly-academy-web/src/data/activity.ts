export type ActivityPost = { category: string; title: string; body: string; image?: string; videoIndex?: number };
export type ShortVideo = { title: string; views: string };

export const ACTIVITY_CATEGORIES = ['Tất cả', 'Thăm học viên', 'Món mới', 'Lớp học', 'Học viên', 'Tin tức'];

export const QUICK_NEWS = [
  { tag: 'Tin tức', text: 'Sách tái bản 2026 đã có mặt: 130+ công thức có giá cost, thêm 3 chuyên đề Matcha, Cafe hiện đại, Kem hạt dẻ cười.' },
  { tag: 'Công cụ', text: 'Công cụ Mở Quán: nhập số vốn, nhận ngay kế hoạch mở quán phù hợp. Miễn phí cho mọi người.' },
  { tag: 'Khai giảng', text: 'Khai giảng lớp [Tên lớp] – Thời gian: [giờ, ngày/tháng] tại [địa điểm].' },
  { tag: 'Livestream', text: 'Chủ đề: [Tên chủ đề] – Host: Cô Ly Phạm – Thời gian: [giờ, ngày/tháng].' },
  { tag: 'Thông báo', text: '[Nội dung thông báo ngắn]' },
];

export const ACTIVITY_POSTS: ActivityPost[] = [
  { category: 'Thăm học viên', title: 'SaLy Academy ghé thăm quán của học viên đã mở bán', body: '[Nội dung: tên học viên, tên quán, mô hình kinh doanh, cảm nhận sau khi mở quán]', image: '/images/tham-hoc-vien.jpg' },
  { category: 'Lớp học', title: 'Lớp Pha chế và kinh doanh thực chiến K66', body: '[Tổng kết lớp: chuyên đề đã học, hình ảnh buổi thực hành và bế giảng]', image: '/images/lop-thuc-chien-k66.jpg' },
  { category: 'Món mới', title: 'Ra món mới: Trà sữa Olong sốt cốm', body: '[Mô tả món, nguyên liệu chính, giá vốn tham khảo và link video công thức]', videoIndex: 12 },
  { category: 'Học viên', title: 'Trà xoài chanh dây – món học viên bán theo công thức trong sách', body: '[Câu chuyện học viên áp dụng công thức vào quán]', image: '/images/do-uong-hoc-vien.jpg' },
  { category: 'Tin tức', title: 'Sách “Làm Chủ Từ Đam Mê Pha Chế” tái bản 2026', body: 'Bổ sung 30 công thức mới và 3 chuyên đề: Matcha, Cafe hiện đại, Kem hạt dẻ cười.', image: '/images/lop-nhan-sach.jpg' },
  { category: 'Món mới', title: 'Ra món mới: Matcha latte sữa nguyên kem', body: '[Mô tả món, nguyên liệu chính, giá vốn tham khảo và link video công thức]', videoIndex: 14 },
];

/** Thứ tự khớp ảnh ghép /images/video-shorts-sprite.jpg (6 cột × 3 hàng). Thay bằng ảnh bìa thật khi nối API TikTok. */
export const SHORT_VIDEOS: ShortVideo[] = [
  { title: 'Muốn mở quán nhưng không biết bắt đầu từ đâu', views: '1.2M' },
  { title: 'Khai trương Học viện Pha chế Ly Phạm – SaLy Academy', views: '157.1K' },
  { title: 'Học pha chế tổng hợp trực tiếp', views: '357K' },
  { title: 'Câu nói thật với mọi người', views: '1.591' },
  { title: 'Chia sẻ ngân sách phù hợp chọn mặt bằng', views: '533' },
  { title: 'Lưu ý khi mở quán mô hình ngồi lại', views: '3.476' },
  { title: 'Sử dụng pump làm khúc bạch chân mèo đúng cách', views: '1.002' },
  { title: 'Lời ảo trong kinh doanh', views: '2.219' },
  { title: 'Sữa chua việt quất bán 20K có lời không?', views: '12.4K' },
  { title: 'Kinh doanh đừng lấy công làm lời', views: '2.045' },
  { title: 'Chủ quán cần biết pha chế', views: '5.715' },
  { title: 'Cách tăng giá trị ly cà phê', views: '1.511' },
  { title: 'Trà sữa Olong sốt cốm hot trend', views: '5.378' },
  { title: 'Hạt đác rim đường', views: '2.526' },
  { title: 'Matcha latte sữa nguyên kem', views: '5.813' },
  { title: 'Chuẩn bị nguyên liệu bao lâu là hợp lý?', views: '2.761' },
  { title: 'Sữa chua việt quất', views: '94.9K' },
  { title: '[Tiêu đề video]', views: '2.227' },
];
