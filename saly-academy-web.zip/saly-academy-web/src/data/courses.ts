export type Course = {
  slug: string;
  title: string;
  image: string;
  categories: string[];
  price: number | null; // null = chưa có giá
  oldPrice?: number;
};

export const COURSE_FILTERS = [
  'Chuyên đề ăn vặt',
  'Chuyên đề Kinh doanh mở quán F&B',
  'Chuyên đề pha chế 2025',
  'Khóa học miễn phí',
  'Khóa Học Pha Chế Ly Phạm',
  'Khóa học thử',
];

export const COURSES: Course[] = [
  { slug: 'tra-sua-2026', title: 'Khóa Học Trà Sữa [Update 2026]', image: '/images/khoa-hoc-tra-sua.jpg', categories: ['Chuyên đề pha chế 2025'], price: 1900000, oldPrice: 3200000 },
  { slug: 'nuoc-ep-trai-cay-2026', title: 'Khóa học Nước ép trái cây 2026 [Cập nhật xu hướng đồ uống mùa hè]', image: '/images/khoa-hoc-nuoc-ep.jpg', categories: ['Chuyên đề pha chế 2025', 'Khóa Học Pha Chế Ly Phạm'], price: null },
  { slug: 'tra-trai-cay', title: 'Khóa Học Trà Trái Cây [Update 2026]', image: '/images/khoa-hoc-tra-trai-cay.jpg', categories: ['Chuyên đề pha chế 2025'], price: null },
];

export const SORTS = ['Mới nhất', 'Giá thấp đến cao', 'Giá cao đến thấp', 'Giảm giá nhiều nhất'] as const;

/* ───── Sản phẩm bán được (gói mô hình + khóa lẻ) – dùng cho giỏ hàng & thanh toán ───── */
import { PACKAGES, isDealActive } from './packages';

export type Product = Course & { kind: 'package' | 'course'; gift?: string };

export function getProducts(now = new Date()): Product[] {
  const deal = isDealActive(now);
  const pk: Product[] = PACKAGES.map((p) => ({
    slug: p.slug, title: `Gói ${p.name}`, image: p.thumb, categories: ['Gói theo mô hình'], kind: 'package',
    price: deal && p.dealPrice ? p.dealPrice : p.price, oldPrice: deal && p.dealPrice ? p.price : undefined,
    gift: deal ? p.dealGift : undefined,
  }));
  return [...pk, ...COURSES.map((c) => ({ ...c, kind: 'course' as const }))];
}
