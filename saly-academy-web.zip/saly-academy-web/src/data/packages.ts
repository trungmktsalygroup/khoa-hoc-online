/**
 * Gói khóa học theo MÔ HÌNH QUÁN – sản phẩm chính (theo chính sách bán theo mô hình).
 * Khóa lẻ theo chuyên đề món (src/data/courses.ts) là sản phẩm phụ.
 * Thông điệp theo bộ Insight học viên Online từng mô hình: KHÔNG công khai mức vốn cho khách tự so sánh;
 * khách chọn theo KIỂU MÔ HÌNH, vốn chỉ để Sale phân loại khi tư vấn.
 * TODO (cần anh Sang xác nhận): tên đầy đủ của các viết tắt TP, MC & ĐX, ST & SC; quà tặng gói Trọn bộ.
 */
export type Perk = { text: string; special?: boolean };

export type ModelPackage = {
  slug: string;
  capital: string;          // mức vốn – CHỈ dùng nội bộ cho Sale, không hiển thị cho khách
  capitalRef: number;
  /** Câu định vị ngắn của mô hình (hiển thị thay cho mức vốn) */
  tagline: string;
  /** Nhãn lựa chọn khi khách tự nhận diện mô hình (khối 'Bước đầu tiên', form tư vấn) */
  choice: string;
  /** Phù hợp nếu bạn… – giúp khách tự nhận diện mô hình */
  fitFor: string[];
  name: string;
  short: string;            // tên ngắn cho nút chọn
  focus: string;            // định hướng mô hình
  price: number;            // ngân sách khóa (giá niêm yết)
  dealPrice?: number;       // giá ưu đãi mở bán
  dealGift?: string;        // quà tặng mở bán
  topics: string[];         // khóa / nhóm chính
  examples?: string;        // quán tham khảo
  image: string;
  /** Ảnh bìa khóa học (thumbnail) – dùng ở khối chọn vốn, giỏ hàng */
  thumb: string;
  popular?: boolean;
  /** Biểu tượng nhỏ cạnh tên gói trên thẻ */
  cardIcon: 'leaf' | 'coffee' | 'crown';
  /** Học xong học viên làm được gì (kết quả, không phải nội dung khóa) */
  outcomes: string[];
  /** Quà tặng kèm – special = điểm riêng của gói */
  gifts: Perk[];
  /** Quyền lợi – special = điểm riêng của gói */
  benefits: Perk[];
};

/** Thời gian ưu đãi mở bán */
export const DEAL = { label: '10/10 – 20/10', start: '2026-10-10T00:00:00+07:00', end: '2026-10-20T23:59:59+07:00' };
export const isDealActive = (now = new Date()) => now >= new Date(DEAL.start) && now <= new Date(DEAL.end);

const BASE_BENEFITS: Perk[] = [
  { text: 'Giải đáp, hỗ trợ 1-1 từ đội trợ giảng' },
  { text: '“Kiến Mơ” hỗ trợ trọn đời' },
  { text: 'Setup menu và giá bán' },
  { text: 'Tư vấn danh sách nguyên liệu, dụng cụ theo menu' },
];
const PLUS_BENEFITS: Perk[] = [
  { text: 'Cập nhật công thức món mới', special: true },
  { text: 'Dịch vụ thiết kế menu', special: true },
];
const BASE_GIFTS: Perk[] = [
  { text: 'Danh sách máy móc, dụng cụ cần thiết để tiết kiệm chi phí' },
  { text: 'Mẫu lên menu có giá bán' },
  { text: 'Tài liệu hướng dẫn thủ tục đăng ký kinh doanh và thuế' },
];
const COFFEE_TEA_GIFTS: Perk[] = [
  { text: 'Bộ 9 công thức Topping bán kèm', special: true },
  { text: 'Bảng mẫu tính điểm hòa vốn mô hình Coffee & Tea', special: true },
  ...BASE_GIFTS,
];

export const PACKAGES: ModelPackage[] = [
  {
    slug: 'kinh-doanh-xe-tra', capital: '50 – 70 triệu', capitalRef: 60, short: 'Xe trà', name: 'Pha chế kinh doanh Xe trà',
    focus: 'Mô hình nhỏ gọn, dễ hình dung để bắt đầu – đặt ở khu dân cư, gần trường học, khu công nghiệp. Chuẩn bị được song song với công việc hiện tại.',
    cardIcon: 'leaf', choice: 'Xe trà, quầy nhỏ',
    tagline: 'Nhỏ gọn, vừa sức để bắt đầu',
    fitFor: ['Bạn muốn bắt đầu bằng một mô hình nhỏ, không quá nặng đầu tư', 'Bạn chưa chắc nên mở gì – chỉ biết mình muốn bán đồ uống', 'Bạn cần học theo thời gian riêng, chuẩn bị song song công việc'],
    price: 2500000, topics: ['Trà trái cây', 'Trà sữa', 'Topping', 'MAP – Lên kế hoạch mở quán (bản lẻ)'],
    image: '/images/mo-hinh/xe-tra-mang-di.jpg', thumb: '/images/khoa-hoc-xe-tra.jpg',
    outcomes: ['Biết đúng nhóm món cần học để bắt đầu bán xe trà', 'Có menu gợi ý theo mô hình – không phải tự ghép chuyên đề', 'Pha đều tay trà trái cây, trà sữa và topping', 'Setup menu và giá bán phù hợp khu vực bán', 'Có lộ trình rõ ràng và người hỗ trợ khi thực hành'],
    gifts: [{ text: 'Bảng giá cost đã tính sẵn các món Cô Ly hướng dẫn', special: true }, { text: 'Bảng mẫu tính điểm hòa vốn' }, ...BASE_GIFTS],
    benefits: BASE_BENEFITS,
  },
  {
    slug: 'coffee-tea-mang-di', capital: '100 – 200 triệu', capitalRef: 150, short: 'Coffee & Tea mang đi', name: 'Pha chế kinh doanh Coffee & Tea mang đi',
    focus: 'Quán Coffee & Tea bán mang đi: gọn hơn quán ngồi, chuyên nghiệp hơn xe đẩy – hợp khu dân cư, trường học, văn phòng và bán Online.',
    cardIcon: 'coffee', choice: 'Quán bán mang đi',
    tagline: 'Gọn hơn quán ngồi, chuyên nghiệp hơn xe đẩy',
    fitFor: ['Bạn muốn mô hình chỉn chu hơn xe đẩy nhưng chưa cần chỗ ngồi', 'Bạn muốn bán cả cà phê và trà, menu cân bằng mà không quá dài', 'Bạn không muốn tự ghép nhiều khóa lẻ rồi đoán xem đã đủ chưa'],
    price: 4950000, dealPrice: 4450000, topics: ['Trà trái cây', 'Cà phê', 'Matcha', 'Trà sữa đậm vị', 'MAP – Lên kế hoạch mở quán'],
    examples: 'Lục Coffee & Tea (THL, LQD), Ngô Gia…', image: '/images/mo-hinh/kiosk-tra.jpg', thumb: '/images/khoa-hoc-tra-trai-cay.jpg', popular: true,
    outcomes: ['Có menu Coffee & Tea cân bằng, vừa đủ cho quán mang đi', 'Biết món nào nên ưu tiên và vai trò từng món trong menu', 'Pha chuẩn trà trái cây, cà phê, matcha, trà sữa đậm vị', 'Setup menu và giá bán theo tệp khách khu vực', 'Xem lại công thức để hướng dẫn nhân viên khi cần'],
    gifts: COFFEE_TEA_GIFTS,
    benefits: [...BASE_BENEFITS, ...PLUS_BENEFITS, { text: 'Bộ 4 cuốn sách giáo trình: Trà trái cây, Trà sữa, Cà phê, Matcha', special: true }],
  },
  {
    slug: 'coffee-tea-ngoi-lai', capital: '300 – 500 triệu', capitalRef: 300, short: 'Coffee & Tea ngồi lại', name: 'Pha chế kinh doanh Coffee & Tea ngồi lại',
    focus: 'Quán có không gian ngồi lại, chỉn chu về sản phẩm và trải nghiệm – menu phong phú hơn, thường kết hợp thêm nước ép.',
    cardIcon: 'coffee', choice: 'Quán có chỗ ngồi',
    tagline: 'Có không gian, chỉn chu trải nghiệm',
    fitFor: ['Bạn muốn quán có chỗ ngồi, tạo trải nghiệm tốt cho khách', 'Bạn đã có hoặc đang tìm mặt bằng phù hợp', 'Bạn muốn menu phong phú nhưng có logic rõ ràng'],
    price: 5950000, dealPrice: 5450000, topics: ['Trà trái cây', 'Cà phê', 'Matcha', 'Trà sữa đậm vị', 'Nước ép', 'MAP – Lên kế hoạch mở quán'],
    examples: 'Lục Trường Sa, Loco Coffee & Tea…', image: '/images/mo-hinh/quan-nho-co-cho-ngoi.jpg', thumb: '/images/khoa-hoc-nuoc-ep.jpg',
    outcomes: ['Có menu phong phú với nhóm món chủ lực và nhóm bổ trợ', 'Menu hợp với hình ảnh quán và tệp khách bạn hướng tới', 'Pha chuẩn cà phê, trà, matcha, trà sữa đậm vị và nước ép', 'Setup menu, giá bán và thiết kế menu chuyên nghiệp', 'Học song song giai đoạn chuẩn bị mặt bằng và khai trương'],
    gifts: COFFEE_TEA_GIFTS,
    benefits: [...BASE_BENEFITS, ...PLUS_BENEFITS, { text: 'Bộ 5 cuốn sách giáo trình: Trà trái cây, Trà sữa, Cà phê, Matcha, Nước ép', special: true }],
  },
  {
    slug: 'kinh-doanh-online-tron-bo', capital: 'Từ 500 triệu', capitalRef: 500, short: 'Lộ trình trọn bộ', name: 'Pha chế kinh doanh Online – Lộ trình trọn bộ',
    focus: 'Cho người chuẩn bị đầu tư nghiêm túc, quy mô lớn – cần một chương trình đủ đầy, bài bản thay vì học rời từng phần.',
    cardIcon: 'crown', choice: 'Đầu tư lớn, bài bản',
    tagline: 'Lộ trình toàn diện cho người đầu tư nghiêm túc',
    fitFor: ['Bạn chuẩn bị đầu tư nghiêm túc, kỳ vọng cao vào mô hình', 'Bạn không muốn học rời rạc và sợ thiếu phần quan trọng', 'Bạn cần nền tảng để đào tạo nhân viên và làm việc với đội ngũ'],
    price: 7686000, dealGift: 'Tặng khóa Nước ép Online',
    topics: ['Trà trái cây', 'Trà sữa', 'Topping', 'Cà phê', 'Matcha', 'MC & Đá xay', 'Sinh tố & Sữa chua', 'MAP – Lên kế hoạch mở quán'],
    image: '/images/mo-hinh/quan-lon.jpg', thumb: '/images/video-gioi-thieu.jpg',
    outcomes: ['Nền tảng đầy đủ: pha chế, menu, cost, giá bán và kinh doanh F&B', 'Học theo thứ tự rõ ràng – phần nền tảng trước, phần triển khai sau', 'Làm chủ toàn bộ menu: trà, cà phê, matcha, đá xay, sinh tố, sữa chua…', 'Có thư viện kiến thức dùng lâu dài để đào tạo nhân viên', 'Giảm thử sai trước khi bỏ khoản đầu tư lớn'],
    gifts: [], // TODO: chính sách chưa có danh mục quà tặng cho gói này
    benefits: [...BASE_BENEFITS, ...PLUS_BENEFITS, { text: 'Sách giáo trình “Làm Chủ Từ Đam Mê Pha Chế”', special: true }],
  },
];

/** % chi phí học trên vốn tham chiếu – chỉ dùng nội bộ (Sale), không hiển thị cho khách */
export const costRatio = (p: ModelPackage) => ((p.price / (p.capitalRef * 1_000_000)) * 100).toFixed(2).replace('.', ',');

/** Bảng so sánh các gói (thứ tự cột = thứ tự PACKAGES). true = có, false = không, chuỗi = ghi chú riêng */
export const COMPARE: { group: string; rows: { label: string; values: (boolean | string)[] }[] }[] = [
  { group: 'Khóa học trong gói', rows: [
    { label: 'Trà trái cây', values: [true, true, true, true] },
    { label: 'Trà sữa', values: [true, 'Trà sữa đậm vị', 'Trà sữa đậm vị', true] },
    { label: 'Topping', values: [true, false, false, true] },
    { label: 'Cà phê', values: [false, true, true, true] },
    { label: 'Matcha', values: [false, true, true, true] },
    { label: 'Nước ép', values: [false, false, true, 'Tặng khi mở bán'] },
    { label: 'MC & Đá xay', values: [false, false, false, true] },
    { label: 'Sinh tố & Sữa chua', values: [false, false, false, true] },
    { label: 'MAP – Lên kế hoạch mở quán', values: ['Bản lẻ', true, true, true] },
  ] },
  { group: 'Quà tặng kèm', rows: [
    { label: 'Bảng giá cost đã tính sẵn', values: [true, false, false, false] },
    { label: 'Bảng mẫu tính điểm hòa vốn', values: [true, 'Mô hình Coffee & Tea', 'Mô hình Coffee & Tea', false] },
    { label: 'Bộ 9 công thức Topping bán kèm', values: [false, true, true, false] },
    { label: 'Danh sách máy móc, dụng cụ tiết kiệm chi phí', values: [true, true, true, false] },
    { label: 'Mẫu lên menu có giá bán', values: [true, true, true, false] },
    { label: 'Tài liệu thủ tục đăng ký kinh doanh & thuế', values: [true, true, true, false] },
  ] },
  { group: 'Quyền lợi', rows: [
    { label: 'Giải đáp, hỗ trợ 1-1 từ đội trợ giảng', values: [true, true, true, true] },
    { label: '“Kiến Mơ” hỗ trợ trọn đời', values: [true, true, true, true] },
    { label: 'Setup menu và giá bán', values: [true, true, true, true] },
    { label: 'Tư vấn nguyên liệu, dụng cụ theo menu', values: [true, true, true, true] },
    { label: 'Cập nhật công thức món mới', values: [false, true, true, true] },
    { label: 'Dịch vụ thiết kế menu', values: [false, true, true, true] },
    { label: 'Sách giáo trình', values: [false, 'Bộ 4 cuốn', 'Bộ 5 cuốn', '“Làm Chủ Từ Đam Mê Pha Chế”'] },
  ] },
];

/** Mô tả ngắn từng chuyên đề trong gói (hiển thị ở trang thông tin khóa học) */
export const TOPIC_INFO: Record<string, string> = {
  'Trà trái cây': 'Ủ trà nền đúng chuẩn, sơ chế và bảo quản trái cây, công thức trà trái cây bán chạy, cách giữ vị đồng đều mỗi ly.',
  'Trà sữa': 'Nấu trà sữa chuẩn vị, cân chỉnh độ đậm – ngọt – béo theo khẩu vị khách, công thức bán chạy.',
  'Trà sữa đậm vị': 'Trà sữa đậm vị trà theo xu hướng: chọn trà, nấu cốt, cân bằng vị đậm và béo.',
  'Topping': 'Trân châu, thạch, kem và các loại topping bán kèm giúp tăng giá trị mỗi ly.',
  'Cà phê': 'Pha cà phê phin, máy và các món cà phê hiện đại phù hợp quán mang đi và quán ngồi lại.',
  'Matcha': 'Đánh matcha đúng kỹ thuật, các món matcha latte và biến tấu đang được ưa chuộng.',
  'Nước ép': 'Chọn trái cây, ép và phối vị nước ép, bảo quản để món luôn tươi ngon.',
  'MC & Đá xay': 'Các món đá xay mát lạnh và nhóm món MC theo giáo trình của Cô Ly.',
  'Sinh tố & Sữa chua': 'Sinh tố trái cây và các món sữa chua đa dạng cho menu quán.',
};
export const topicKey = (t: string) => (t.startsWith('MAP') ? 'MAP' : t);
TOPIC_INFO.MAP = 'MAP – Master Action Plan (Kế hoạch hành động chính): chọn mặt bằng, dự trù vốn, máy móc, nhân sự, giá bán và kế hoạch khai trương.';
