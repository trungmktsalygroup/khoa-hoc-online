/** Video bài học: Vimeo (bản chính thức) hoặc YouTube (tạm) */
export type LessonVideo = { provider: 'vimeo' | 'youtube'; id: string; h?: string; title: string; thumb?: string };
export type Lesson = { title: string; duration: string; tag: 'FREE' | 'PRO'; thumb: string; video?: LessonVideo };

/** Video mẫu dùng cho trang học khi bài chưa có video riêng. TODO: gán video thật (Vimeo) cho từng bài */
export const DEMO_VIDEO: LessonVideo = { provider: 'youtube', id: 'zP3QEu01IS8', title: 'Cách lên menu nước ép trái cây tươi siêu hút khách', thumb: '/images/video-bai-hoc-mau.jpg' };
/** Video Vimeo mẫu – dùng lại khi Vimeo cho phép nhúng trên tên miền web */
export const DEMO_VIMEO: LessonVideo = { provider: 'vimeo', id: '1112488693', title: '01. Hướng dẫn làm món Cacao sữa đá pha từng ly' };

export const TOPIC = { slug: 'tra-trai-cay', title: 'Trà Trái Cây', total: 54, length: '06:14:19', views: 625 };

export const LESSONS: Lesson[] = [
  { title: 'Tổng quan về chuyên đề trà trái cây. Những điều cần biết trước khi bắt đầu', duration: '06:17', tag: 'FREE', thumb: '/images/thumb-bai-1.jpg' },
  { title: 'Mẹo kinh doanh: Tiết kiệm thời gian với quy trình sắp xếp, bố trí và pha chế trà trái cây hiệu quả', duration: '06:04', tag: 'PRO', thumb: '/images/thumb-bai-2.jpg' },
  { title: 'Phân biệt 3 loại trà chính và cách dùng loại trà phù hợp', duration: '13:22', tag: 'PRO', thumb: '/images/thumb-bai-3.jpg' },
  { title: 'Hướng dẫn sử dụng các dụng cụ ủ trà sao cho hiệu quả', duration: '04:26', tag: 'PRO', thumb: '/images/thumb-bai-4.jpg' },
  { title: 'Hướng dẫn ủ trà đúng cách và các lưu ý quan trọng để bảo quản', duration: '22:13', tag: 'PRO', thumb: '/images/thumb-bai-5.jpg' },
];
