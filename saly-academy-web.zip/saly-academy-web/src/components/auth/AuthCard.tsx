'use client';
import Link from 'next/link';
import { useRouter, useSearchParams } from 'next/navigation';
import { useState, type FormEvent } from 'react';
import { SITE } from '@/data/site';

/** Đăng nhập / Đăng ký. TODO: nối NextAuth (Google) + API tài khoản. Hiện bấm nút sẽ chuyển sang trang học mẫu. */
export function AuthCard() {
  const params = useSearchParams();
  const router = useRouter();
  const [mode, setMode] = useState<'login' | 'register'>(params.get('che-do') === 'dang-ky' ? 'register' : 'login');
  const [showPw, setShowPw] = useState(false);
  const reg = mode === 'register';

  function onSubmit(e: FormEvent) { e.preventDefault(); router.push('/hoc/tra-trai-cay'); }

  return (
    <div className="flex flex-col gap-4.5 rounded-[20px] bg-white p-5 shadow-[0_12px_32px_rgba(20,67,42,0.12)] md:rounded-3xl md:p-7 md:shadow-[0_20px_48px_rgba(20,67,42,0.12)]">
      <div className="flex flex-col gap-1.5">
        <h2 className="text-2xl font-extrabold leading-8">{reg ? 'Tạo tài khoản học miễn phí' : 'Chào mừng bạn quay lại'}</h2>
        <p className="text-sm text-muted">{reg ? 'Mở khóa ngay hơn 30 bài học miễn phí.' : 'Đăng nhập để học tiếp bài đang dở.'}</p>
      </div>
      <div className="flex flex-wrap gap-2">
        {['Không nhập form rườm rà', 'Không cần nạp thẻ', 'Không giới hạn thời gian'].map((t) => <span key={t} className="rounded-lg bg-brand-100 px-2.5 py-1 text-xs font-semibold text-brand-700">{t}</span>)}
      </div>
      <button type="button" className="flex h-[50px] items-center justify-center gap-2.5 rounded-xl border border-[#D9D3CB] bg-white text-[15px] font-semibold">
        <svg width="20" height="20" viewBox="0 0 48 48" aria-hidden><path fill="#FFC107" d="M43.6 20.5H42V20H24v8h11.3C33.7 32.7 29.2 36 24 36c-6.6 0-12-5.4-12-12s5.4-12 12-12c3.1 0 5.8 1.2 7.9 3.1l5.7-5.7C34 6.1 29.3 4 24 4 13 4 4 13 4 24s9 20 20 20 20-9 20-20c0-1.3-.1-2.4-.4-3.5z" /><path fill="#FF3D00" d="M6.3 14.7l6.6 4.8C14.7 15.1 19 12 24 12c3.1 0 5.8 1.2 7.9 3.1l5.7-5.7C34 6.1 29.3 4 24 4 16.3 4 9.7 8.3 6.3 14.7z" /><path fill="#4CAF50" d="M24 44c5.2 0 9.9-2 13.4-5.2l-6.2-5.2C29.2 35.1 26.7 36 24 36c-5.2 0-9.6-3.3-11.3-7.9l-6.5 5C9.5 39.6 16.2 44 24 44z" /><path fill="#1976D2" d="M43.6 20.5H42V20H24v8h11.3c-.8 2.2-2.2 4.2-4.1 5.6l6.2 5.2C37 39.2 44 34 44 24c0-1.3-.1-2.4-.4-3.5z" /></svg>
        Tiếp tục với Google
      </button>
      <div className="flex items-center gap-3 text-[13px] text-muted"><span className="h-px flex-1 bg-[#ECE7E1]" />hoặc dùng email<span className="h-px flex-1 bg-[#ECE7E1]" /></div>
      <div role="tablist" aria-label="Chế độ" className="grid grid-cols-2 gap-1 rounded-xl bg-[#F3F0EC] p-1">
        {(['login', 'register'] as const).map((m) => (
          <button key={m} type="button" role="tab" aria-selected={mode === m} onClick={() => setMode(m)}
            className={`h-10 rounded-[9px] text-sm font-bold ${mode === m ? 'bg-white text-ink shadow-sm' : 'text-muted'}`}>{m === 'login' ? 'Đăng nhập' : 'Đăng ký mới'}</button>
        ))}
      </div>
      <form onSubmit={onSubmit} className="flex flex-col gap-3.5">
        {reg && (<>
          <label className="flex flex-col gap-1.5 text-[13px] font-semibold">Họ và tên<input className="input font-normal" placeholder="Nguyễn Văn A" autoComplete="name" required /></label>
          <label className="flex flex-col gap-1.5 text-[13px] font-semibold">Số điện thoại<input type="tel" className="input font-normal" placeholder="09xx xxx xxx" autoComplete="tel" required /></label>
        </>)}
        <label className="flex flex-col gap-1.5 text-[13px] font-semibold">Email<input type="email" className="input font-normal" placeholder="ban@email.com" autoComplete="email" required /></label>
        <div className="flex flex-col gap-1.5">
          <label htmlFor="mat-khau" className="text-[13px] font-semibold">Mật khẩu</label>
          <div className="flex h-12 items-center rounded-xl border border-[#D9D3CB] pl-3.5 pr-1">
            <input id="mat-khau" type={showPw ? 'text' : 'password'} className="min-w-0 flex-1 bg-transparent text-[15px] outline-none" placeholder="Nhập mật khẩu" autoComplete={reg ? 'new-password' : 'current-password'} required />
            <button type="button" onClick={() => setShowPw((s) => !s)} aria-label={showPw ? 'Ẩn mật khẩu' : 'Hiện mật khẩu'} className="flex size-10 items-center justify-center text-muted">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z" /><circle cx="12" cy="12" r="3" />{showPw && <path d="M4 4l16 16" />}</svg>
            </button>
          </div>
        </div>
        {!reg && (
          <div className="flex items-center justify-between text-sm">
            <label className="flex cursor-pointer items-center gap-2"><input type="checkbox" className="size-[18px] accent-brand-600" />Ghi nhớ đăng nhập</label>
            <a href="#" className="font-semibold text-accent-600">Quên mật khẩu?</a>
          </div>
        )}
        {SITE.demoMode && (
          <p className="flex items-start gap-2 rounded-xl border border-dashed border-accent-500/60 bg-accent-100 px-3 py-2.5 text-[13px] leading-5 text-ink-2" role="note">
            <span className="shrink-0 rounded bg-accent-500 px-1.5 py-0.5 text-[10.5px] font-extrabold text-white">DEMO</span>
            <span>Bản demo: nhập <strong>email và mật khẩu bất kỳ</strong> để thử{reg ? ' (email, số điện thoại đúng định dạng)' : ''}.</span>
          </p>
        )}
        <button type="submit" className="btn btn-accent btn-lg h-[54px]">{reg ? 'Đăng ký & học ngay' : 'Đăng nhập & học ngay'}</button>
      </form>
      <div className="flex items-center gap-2.5 rounded-[14px] bg-accent-100 p-3.5 text-[13px] leading-[19px]">
        <span className="shrink-0 rounded-md bg-brand-600 px-2 py-0.5 text-[11px] font-bold text-white">PRO</span>
        <span className="text-ink-2">Ưu đãi riêng cho học viên đăng ký PRO sớm. <Link href="/khoa-hoc" className="font-bold text-accent-600">Xem ưu đãi</Link></span>
      </div>
    </div>
  );
}
