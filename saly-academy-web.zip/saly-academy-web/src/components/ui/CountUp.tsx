/**
 * Số liệu hiển thị đủ ngay khi tải trang (không chạy từ 0) – để Google chụp trang
 * và máy yếu đều thấy đúng con số. Giữ tên CountUp để không phải sửa nơi dùng.
 */
export function CountUp({ value, className }: { value: string; duration?: number; className?: string }) {
  const target = parseInt(value.replace(/\D/g, ''), 10) || 0;
  const suffix = value.replace(/[\d.,\s]/g, '');
  return <span className={className}>{target.toLocaleString('vi-VN')}{suffix}</span>;
}
