import Image from 'next/image';

/** Ngôi sao lấp lánh – họa tiết nhận diện SaLy (dùng tiết chế, 1–2 chiếc mỗi khu vực) */
export function Sparkle({ size = 22, color = '#F29546', className = '' }: { size?: number; color?: string; className?: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" aria-hidden className={className}>
      <path d="M12 0c.6 6.2 5.8 11.4 12 12-6.2.6-11.4 5.8-12 12C11.4 17.8 6.2 12.6 0 12 6.2 11.4 11.4 6.2 12 0z" fill={color} />
    </svg>
  );
}

/** Lát cam – dùng làm huy hiệu đánh số / điểm nhấn */
export function OrangeSlice({ size = 40, className = '' }: { size?: number; className?: string }) {
  return <Image src="/images/lat-cam.png" alt="" width={size} height={size} className={className} aria-hidden />;
}

/** Đường cong chuyển tiếp giữa các khối màu (giống saly.academy) */
export function Wave({ color, flip = false, className = '' }: { color: string; flip?: boolean; className?: string }) {
  return (
    <svg viewBox="0 0 1440 64" preserveAspectRatio="none" aria-hidden className={`block h-8 w-full md:h-16 ${flip ? 'rotate-180' : ''} ${className}`}>
      <path d="M0 64V30C240 2 480-6 720 14s480 44 720 16V64z" fill={color} />
    </svg>
  );
}

/** Hai chiếc lá đan nhau – lấy từ biểu tượng logo SaLy */
export function LeafMark({ size = 28, className = '' }: { size?: number; className?: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 40 40" aria-hidden className={className}>
      <path d="M6 30C2 20 6 8 16 6c6-1 9 4 7 9-2 6-9 8-17 15z" fill="#E0954A" />
      <path d="M34 10c4 10 0 22-10 24-6 1-9-4-7-9 2-6 9-8 17-15z" fill="#11904F" />
    </svg>
  );
}
