'use client';
import { useEffect, useRef, useState, type ElementType, type ReactNode } from 'react';

/** Gắn data-reveal="in" khi phần tử cuộn vào màn hình (chạy 1 lần). Hiệu ứng cụ thể khai báo bằng CSS. */
export function Reveal({ as: Tag = 'div', className, children, threshold = 0.3 }: { as?: ElementType; className?: string; children: ReactNode; threshold?: number }) {
  const ref = useRef<HTMLElement>(null);
  const [inView, setInView] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el || typeof IntersectionObserver === 'undefined') { setInView(true); return; }
    const io = new IntersectionObserver(([e]) => { if (e.isIntersecting) { setInView(true); io.disconnect(); } }, { threshold });
    io.observe(el);
    return () => io.disconnect();
  }, [threshold]);
  return <Tag ref={ref} className={className} data-reveal={inView ? 'in' : 'out'}>{children}</Tag>;
}
