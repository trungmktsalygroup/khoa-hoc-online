'use client';
import Image from 'next/image';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useEffect, useState } from 'react';
import { NAV, SITE } from '@/data/site';
import { Icon } from '@/components/ui/Icon';
import { useCart } from '@/components/shared/CartProvider';

function isActive(pathname: string, href: string) {
  return href === '/' ? pathname === '/' : pathname.startsWith(href);
}

export function Header() {
  const pathname = usePathname();
  const { items } = useCart();
  const [open, setOpen] = useState(false);
  useEffect(() => setOpen(false), [pathname]);

  return (
    <header className="sticky top-0 z-40 border-b border-line bg-white">
      <div className="container-site flex min-h-16 items-center gap-2 md:min-h-[76px] md:gap-5">
        <Link href="/" aria-label="SaLy Academy – Trang chủ" className="flex flex-1 items-center md:flex-none">
          <Image src="/images/logo-saly-academy.png" alt="SaLy Academy – Ly Phạm Dạy Pha Chế" width={936} height={250} priority className="h-9 w-auto md:h-[46px]" />
        </Link>

        <nav aria-label="Menu chính" className="hidden flex-1 items-center justify-center gap-0.5 xl:flex">
          {NAV.map((n) => {
            const active = isActive(pathname, n.href);
            return (
              <Link key={n.href} href={n.href} aria-current={active ? 'page' : undefined}
                className={`whitespace-nowrap rounded-[10px] px-2.5 py-2.5 text-[15px] 2xl:px-3.5 ${active ? 'bg-brand-100 font-bold text-brand-600' : 'font-medium text-ink-2 hover:bg-mint'}`}>
                {n.label}
              </Link>
            );
          })}
        </nav>

        <div className="ml-auto flex shrink-0 items-center gap-1 md:gap-2.5">
          <Link href="/thanh-toan" aria-label={`Giỏ hàng, ${items.length} khóa học`} className="relative flex size-11 items-center justify-center rounded-xl text-brand-700 md:border md:border-line-2">
            <Icon name="cart" size={21} />
            <span className="absolute -right-1 -top-1 flex h-5 min-w-5 items-center justify-center rounded-full bg-accent-500 px-1 text-[11px] font-extrabold text-white">{items.length}</span>
          </Link>
          <a href={SITE.hotlineTel} aria-label={`Gọi hotline ${SITE.hotline}`} className="flex size-11 items-center justify-center rounded-xl text-brand-500 2xl:hidden"><Icon name="phone" size={21} /></a>
          <a href={SITE.hotlineTel} className="hidden whitespace-nowrap px-1 text-sm font-semibold text-brand-500 2xl:inline">{SITE.hotline}</a>
          <Link href="/dang-nhap" className="btn hidden border border-brand-500 bg-white text-sm text-brand-500 md:inline-flex">Đăng nhập</Link>
          <Link href="/dang-nhap?che-do=dang-ky" className="btn hidden bg-brand-500 text-sm text-white md:inline-flex">Học thử miễn phí</Link>
          <button type="button" onClick={() => setOpen((o) => !o)} aria-expanded={open} aria-controls="menu-di-dong" aria-label={open ? 'Đóng menu' : 'Mở menu'}
            className="flex size-11 items-center justify-center rounded-xl text-ink xl:hidden">
            <Icon name={open ? 'close' : 'menu'} size={22} />
          </button>
        </div>
      </div>

      {open && (
        <nav id="menu-di-dong" aria-label="Menu di động" className="absolute inset-x-0 top-full flex flex-col gap-0.5 border-b border-line bg-white px-3 pb-4 pt-2.5 md:px-6 xl:hidden shadow-[0_18px_40px_rgba(20,67,42,0.16)]">
          {NAV.map((n) => {
            const active = isActive(pathname, n.href);
            return (
              <Link key={n.href} href={n.href} aria-current={active ? 'page' : undefined}
                className={`flex min-h-[50px] items-center justify-between rounded-xl px-3.5 text-base ${active ? 'bg-brand-100 font-bold text-brand-600' : 'font-semibold text-ink'}`}>
                {n.label}<Icon name="chevronRight" size={18} />
              </Link>
            );
          })}
          <div className="mt-2.5 flex gap-2 md:hidden">
            <Link href="/dang-nhap" className="btn btn-outline flex-1">Đăng nhập</Link>
            <Link href="/dang-nhap?che-do=dang-ky" className="btn btn-accent flex-1">Học thử miễn phí</Link>
          </div>
          <a href={SITE.hotlineTel} className="mt-1 flex min-h-11 items-center justify-center gap-2 text-sm font-bold text-brand-500"><Icon name="phone" size={18} />Hotline {SITE.hotline}</a>
        </nav>
      )}
    </header>
  );
}
