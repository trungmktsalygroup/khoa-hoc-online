import Image from 'next/image';
import Link from 'next/link';
import { FOOTER_COLUMNS, SITE } from '@/data/site';

export function Footer({ withMobileBar = false }: { withMobileBar?: boolean }) {
  return (
    <footer className="border-t border-line bg-white">
      <div className={`container-site flex flex-col gap-8 pt-8 md:gap-10 md:pb-8 md:pt-14 ${withMobileBar ? 'pb-28' : 'pb-8'}`}>
        <div className="flex flex-wrap gap-6 md:gap-12">
          <div className="flex min-w-0 flex-[1.3_1_280px] flex-col gap-3">
            <Link href="/" className="self-start"><Image src="/images/logo-saly-academy.png" alt="SaLy Academy – Ly Phạm Dạy Pha Chế" width={936} height={250} className="h-12 w-auto" /></Link>
            <p className="text-sm leading-[22px] text-ink-2"><strong>{SITE.company}</strong><br />{SITE.address}<br />MST: {SITE.taxCode}</p>
            <p className="text-sm text-ink-2">Hotline: <a href={SITE.hotlineTel} className="font-bold text-accent-600">{SITE.hotline}</a> · <a href={`mailto:${SITE.email}`} className="font-semibold text-accent-600">{SITE.email}</a></p>
          </div>
          {FOOTER_COLUMNS.map((col) => (
            <nav key={col.title} aria-label={col.title} className="flex flex-[1_1_150px] flex-col gap-0.5">
              <strong className="mb-1.5 text-[15px] text-brand-700">{col.title}</strong>
              {col.links.map((l) => (
                <Link key={l.label} href={l.href} className="py-1.5 text-sm text-ink-2 hover:text-brand-600">{l.label}</Link>
              ))}
            </nav>
          ))}
        </div>
        <div className="flex flex-wrap justify-between gap-3 border-t border-[#ECEFEC] pt-4 text-[13px] text-muted">
          <span>© SaLy Group · {SITE.slogan}</span><span>Được quản lý bởi SaLy Group</span>
        </div>
      </div>
    </footer>
  );
}
