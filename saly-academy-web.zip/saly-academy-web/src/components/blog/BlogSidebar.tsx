import Image from 'next/image';
import Link from 'next/link';
import { POSTS } from '@/data/blog';
import { SITE } from '@/data/site';
import { CheckCircle, Icon } from '@/components/ui/Icon';

export function AuthorCard() {
  return (
    <div className="card flex flex-col gap-4 rounded-[20px] p-6">
      <div className="flex items-center gap-3.5">
        <Image src="/images/ly-pham-tach-nen-nho.png" alt="Giảng viên Ly Phạm" width={72} height={72} className="size-[72px] shrink-0 rounded-full border-[3px] border-brand-600 bg-brand-100 object-cover object-top" />
        <div className="flex flex-col gap-1">
          <span className="self-start rounded-md bg-accent-50 px-2 py-0.5 text-[11px] font-extrabold tracking-wider text-accent-700">TÁC GIẢ</span>
          <span className="text-lg font-extrabold text-brand-700">Ly Phạm</span>
          <span className="text-[13px] text-muted">Đồng sáng lập &amp; Giảng viên SaLy Academy</span>
        </div>
      </div>
      <ul className="flex flex-col gap-2.5 text-sm leading-[21px]">
        <li className="flex gap-2.5"><CheckCircle />Hơn {SITE.stats.years.replace('+', '')} năm kinh nghiệm pha chế và vận hành thương hiệu F&amp;B</li>
        <li className="flex gap-2.5"><CheckCircle />{SITE.stats.videos} video bài giảng pha chế và kinh doanh quán</li>
      </ul>
      <a href={SITE.hotlineTel} className="btn btn-outline">Gọi tư vấn {SITE.hotline}</a>
    </div>
  );
}

export function CourseCta() {
  return (
    <div className="bg-brand-corner flex flex-col gap-3 rounded-[20px] p-6 text-white">
      <span className="text-xs font-extrabold tracking-[0.08em]">KHÓA HỌC</span>
      <span className="text-[22px] font-extrabold leading-[29px]">Pha chế toàn diện cho người khởi nghiệp</span>
      <span className="text-sm leading-[21px] text-[#E3F1E8]">Hơn 30 bài học miễn phí. Không nhập thẻ, không giới hạn thời gian.</span>
      <Link href="/dang-nhap?che-do=dang-ky" className="btn btn-accent btn-lg">Học thử miễn phí <Icon name="arrowRight" size={16} strokeWidth={2.4} /></Link>
    </div>
  );
}

export function PopularPosts() {
  return (
    <div className="card flex flex-col gap-1 rounded-[20px] px-6 py-5.5">
      <h2 className="mb-2 text-[17px] font-extrabold text-brand-700">Đọc nhiều nhất</h2>
      {POSTS.slice(0, 4).map((p, i) => (
        <Link key={p.slug} href={`/blog/${p.slug}`} className="flex gap-3.5 border-t border-[#F0F2F0] py-2.5">
          <span className="w-9 shrink-0 whitespace-nowrap text-[22px] font-extrabold tabular-nums text-accent-500">0{i + 1}</span>
          <span className="text-sm font-semibold leading-[21px]">{p.title}</span>
        </Link>
      ))}
    </div>
  );
}
