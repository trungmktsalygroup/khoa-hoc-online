'use client';
import type { ReactNode } from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { useState } from 'react';
import { BLOG_CATEGORIES, POSTS } from '@/data/blog';
import { Icon } from '@/components/ui/Icon';

export function BlogChipsAndList({ sidebar }: { sidebar: ReactNode }) {
  const [cat, setCat] = useState(0);
  const [q, setQ] = useState('');
  const filtered = POSTS.filter((p) => (cat === 0 || p.category === BLOG_CATEGORIES[cat]) && p.title.toLowerCase().includes(q.trim().toLowerCase()));
  const list = filtered.length ? filtered : POSTS;
  return (
    <>
      <div className="flex flex-col gap-4">
        <label className="flex h-[46px] items-center gap-2 rounded-xl border border-line-2 bg-white px-3.5 text-muted md:max-w-[340px]">
          <Icon name="search" size={18} /><span className="sr-only">Tìm bài viết</span>
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Tìm bài viết, công thức…" className="w-full bg-transparent text-[15px] text-ink outline-none md:text-sm" />
        </label>
        <nav aria-label="Danh mục bài viết" className="no-scrollbar -mx-4 flex gap-2 overflow-x-auto px-4 md:mx-0 md:flex-wrap md:gap-2.5 md:px-0">
          {BLOG_CATEGORIES.map((c, i) => <button key={c} type="button" aria-pressed={i === cat} onClick={() => setCat(i)} className="chip shrink-0">{c}</button>)}
        </nav>
      </div>
      <div className="flex flex-wrap items-start gap-7">
        <section className="flex min-w-0 flex-[999_1_640px] flex-col gap-4 md:gap-5.5 md:rounded-[20px] md:border md:border-line md:bg-white md:p-7">
          <div className="flex items-center justify-between gap-3 md:border-b md:border-[#ECEFEC] md:pb-4.5">
            <h2 className="text-[19px] font-extrabold text-brand-700 md:text-[22px]">Bài viết mới nhất</h2>
            <span className="hidden rounded-full bg-brand-100 px-3 py-1.5 text-[13px] font-bold text-brand-600 md:inline">[Tổng số] bài viết</span>
          </div>
          <div className="flex flex-col gap-2 md:grid md:grid-cols-[repeat(auto-fill,minmax(250px,1fr))] md:gap-x-5 md:gap-y-6">
            {list.map((p) => (
              <Link key={p.slug} href={`/blog/${p.slug}`} className="card flex gap-3 p-3 md:flex-col md:border-0 md:p-0">
                <span className="relative block h-20 w-28 shrink-0 overflow-hidden rounded-[10px] md:aspect-[16/10] md:h-auto md:w-full md:rounded-[14px]">
                  <Image src={p.image} alt="" fill sizes="(max-width: 768px) 112px, 30vw" className="object-cover" />
                  <span className="absolute left-2.5 top-2.5 hidden rounded-full bg-brand-600 px-2.5 py-1 text-[11px] font-bold text-white md:inline">{p.category}</span>
                </span>
                <span className="flex min-w-0 flex-col gap-1.5">
                  <span className="text-[11px] font-bold tracking-wide text-brand-600 md:hidden">{p.category}</span>
                  <span className="line-clamp-3 text-[15px] font-bold leading-[21px] md:text-[17px] md:leading-6">{p.title}</span>
                  <span className="hidden text-[13px] text-muted md:block">Ly Phạm · [Ngày đăng]</span>
                </span>
              </Link>
            ))}
          </div>
          <button type="button" className="btn btn-outline self-center rounded-full text-sm">Xem thêm bài viết</button>
        </section>
        <aside className="flex min-w-0 max-w-full flex-[1_1_320px] flex-col gap-5 md:max-w-[400px]">{sidebar}</aside>
      </div>
    </>
  );
}
