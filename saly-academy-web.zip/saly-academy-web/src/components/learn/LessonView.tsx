'use client';
import Image from 'next/image';
import Link from 'next/link';
import { useState } from 'react';
import { DEMO_VIDEO, LESSONS, TOPIC } from '@/data/lessons';
import { LessonPlayer } from './LessonPlayer';
import { SITE } from '@/data/site';
import { Icon } from '@/components/ui/Icon';

type Tab = 'lessons' | 'desc' | 'docs' | 'qa';
const TABS: [Tab, string][] = [['lessons', 'Bài học'], ['desc', 'Mô tả'], ['docs', 'Tài liệu'], ['qa', 'Hỏi đáp']];

/** TODO: tiến độ, bài đã học, video thật lấy từ API học viên. */
export function LessonView() {
  const [cur, setCur] = useState(1);
  const [done, setDone] = useState<number[]>([0]);
  const [tab, setTab] = useState<Tab>('lessons');
  const lesson = LESSONS[cur];
  const video = lesson.video ?? DEMO_VIDEO;
  const pct = Math.round((done.length / TOPIC.total) * 100);
  const next = () => { setDone((d) => (d.includes(cur) ? d : [...d, cur])); setCur((c) => Math.min(LESSONS.length - 1, c + 1)); };
  const prev = () => setCur((c) => Math.max(0, c - 1));

  const progress = (
    <div className="flex flex-col gap-1.5 rounded-xl bg-accent-100 px-3 py-2.5 md:bg-transparent md:p-0">
      <div className="flex justify-between text-[13px]"><span className="font-semibold md:font-normal md:text-muted">Tiến độ chuyên đề</span><span className="font-bold text-accent-700">{done.length}/{TOPIC.total} bài · {pct}%</span></div>
      <div className="h-1.5 overflow-hidden rounded bg-[#F3DCC4]" role="progressbar" aria-valuenow={pct} aria-valuemin={0} aria-valuemax={100}><div className="h-full rounded bg-accent-500" style={{ width: `${Math.max(pct, 2)}%` }} /></div>
    </div>
  );

  const lessonList = (
    <div className="flex flex-col gap-0.5">
      {LESSONS.map((l, i) => {
        const isCur = i === cur, isDone = done.includes(i) && !isCur;
        return (
          <button key={l.title} type="button" onClick={() => setCur(i)} aria-current={isCur ? 'true' : undefined}
            className={`flex w-full items-start gap-3 rounded-xl p-2.5 text-left ${isCur ? 'bg-accent-50' : 'hover:bg-mint'}`}>
            <span className="relative h-[60px] w-[104px] shrink-0 overflow-hidden rounded-lg md:h-[68px] md:w-[120px]">
              <Image src={l.thumb} alt="" fill sizes="120px" className="object-cover" />
              <span className="absolute bottom-1 right-1 rounded bg-black/70 px-1.5 text-[10px] font-semibold text-white md:text-[11px]">{l.duration}</span>
            </span>
            <span className="flex min-w-0 flex-1 flex-col gap-1.5">
              <span className={`line-clamp-2 text-[13px] leading-[18px] md:text-sm md:leading-5 ${isCur ? 'font-bold' : 'font-medium'}`}>{i + 1}. {l.title}</span>
              <span className="flex items-center gap-1.5 text-[11px] font-bold">
                <span className={`rounded-[5px] px-1.5 tracking-wide ${l.tag === 'FREE' ? 'bg-brand-100 text-brand-600' : 'bg-brand-600 text-white'}`}>{l.tag}</span>
                {isCur && <span className="text-accent-600">Đang học</span>}
                {isDone && <span className="flex items-center gap-0.5 text-brand-600"><Icon name="check" size={13} strokeWidth={3} />Đã học</span>}
              </span>
            </span>
          </button>
        );
      })}
      <button type="button" className="btn mx-2 mt-1.5 border border-[#E3DCD3] bg-white text-sm text-ink">Xem thêm {TOPIC.total - LESSONS.length} bài</button>
    </div>
  );

  const tabContent = (t: Tab) => {
    if (t === 'lessons') return <div className="p-2 md:hidden">{lessonList}</div>;
    if (t === 'desc') return (
      <div className="flex flex-wrap gap-6 p-4 md:px-6 md:py-5">
        <div className="flex flex-[2_1_360px] flex-col gap-2.5 text-[15px] leading-6"><strong className="text-base">Bài này bạn sẽ học</strong><p className="text-ink-2">[Mô tả bài học – lấy từ hệ thống quản trị]</p></div>
        <div className="flex flex-[1_1_240px] items-center gap-3 self-start rounded-xl bg-page p-3.5"><span className="flex size-11 items-center justify-center rounded-full bg-brand-500 font-bold text-white">LP</span><span className="flex flex-col"><strong>Ly Phạm</strong><span className="text-[13px] text-muted">Giảng viên · Đồng sáng lập SaLy</span></span></div>
      </div>
    );
    if (t === 'docs') return (
      <div className="grid gap-3 p-4 md:grid-cols-[repeat(auto-fill,minmax(260px,1fr))] md:px-6 md:py-5">
        {[['doc', 'Giáo trình Trà Trái Cây', 'PDF · [dung lượng]', 'Tải về', 'bg-accent-100 text-accent-700'], ['check', 'Công thức của bài', '[định lượng, nguyên liệu]', 'Xem', 'bg-brand-100 text-brand-600']].map(([ic, a, b, c, cls]) => (
          <a key={a} href="#" className="flex items-center gap-3 rounded-xl border border-line p-3.5">
            <span className={`flex size-[42px] items-center justify-center rounded-[10px] ${cls}`}><Icon name={ic as 'doc'} size={20} /></span>
            <span className="flex flex-1 flex-col"><strong className="text-sm">{a}</strong><span className="text-xs text-muted">{b}</span></span>
            <span className="text-[13px] font-bold text-accent-600">{c}</span>
          </a>
        ))}
      </div>
    );
    return (
      <form className="flex flex-col gap-3 p-4 md:px-6 md:py-5" onSubmit={(e) => e.preventDefault()}>
        <label htmlFor="cau-hoi" className="text-[15px] font-bold">Hỏi giảng viên về bài này</label>
        <textarea id="cau-hoi" placeholder="Nhập câu hỏi của bạn…" className="min-h-24 resize-y rounded-xl border border-[#DDD5CB] p-3 text-[15px]" />
        <div className="flex flex-wrap items-center justify-between gap-3">
          <span className="text-[13px] text-muted">Cần hỗ trợ gấp? Gọi <a href={SITE.hotlineTel} className="font-bold text-accent-600">{SITE.hotline}</a></span>
          <button type="submit" className="btn btn-accent w-full text-sm md:w-auto">Gửi câu hỏi</button>
        </div>
      </form>
    );
  };

  return (
    <div className="mx-auto max-w-[1360px] pb-20 md:px-6 md:pb-12 md:pt-4">
      {/* Thanh trên Mobile */}
      <div className="sticky top-0 z-30 flex h-14 items-center gap-1 border-b border-line bg-white px-1.5 md:hidden">
        <Link href="/khoa-hoc" aria-label="Quay lại danh sách khóa học" className="flex size-11 items-center justify-center rounded-xl"><Icon name="chevronLeft" size={22} /></Link>
        <div className="flex min-w-0 flex-1 flex-col"><strong className="text-[15px]">{TOPIC.title}</strong><span className="text-xs text-muted">Bài {cur + 1}/{TOPIC.total} · {TOPIC.length}</span></div>
        <button type="button" onClick={() => setTab('docs')} aria-label="Tài liệu" className="flex size-11 items-center justify-center rounded-xl"><Icon name="doc" size={21} /></button>
        <a href={SITE.hotlineTel} aria-label="Gọi hỗ trợ" className="flex size-11 items-center justify-center rounded-xl"><Icon name="comment" size={21} /></a>
      </div>

      <nav aria-label="Đường dẫn" className="mb-4 hidden gap-2 text-[13px] text-muted md:flex"><Link href="/khoa-hoc">Khóa học của tôi</Link><span>/</span><Link href="/khoa-hoc">{TOPIC.title}</Link><span>/</span><span className="font-semibold text-ink">Bài {cur + 1}</span></nav>

      <div className="flex flex-wrap items-start gap-6">
        <div className="flex min-w-0 flex-[999_1_640px] flex-col md:gap-5">
          {/* Trình phát video bài học (Vimeo/YouTube) – mỗi bài dùng lesson.video, chưa có thì dùng video mẫu */}
          <div className="sticky top-14 z-20 aspect-video overflow-hidden bg-[#111] md:relative md:top-auto md:z-auto md:rounded-2xl">
            <LessonPlayer key={cur} video={video} />
          </div>

          <div className="flex flex-col gap-2.5 bg-white p-4 md:flex-row md:flex-wrap md:items-start md:justify-between md:gap-4 md:bg-transparent md:p-0">
            <div className="flex min-w-0 flex-col gap-2.5 md:flex-[1_1_420px]">
              <h1 className="text-[17px] font-bold leading-6 md:text-[22px] md:leading-[30px] md:tracking-tight">{lesson.title}</h1>
              {!lesson.video && <p className="flex items-center gap-1.5 text-[12.5px] text-muted"><Icon name="video" size={14} className="shrink-0 text-accent-600" />Đang phát video mẫu: {video.title}</p>}
              <div className="flex flex-wrap items-center gap-3 text-[13px] text-muted md:gap-4 md:text-sm">
                <span className="hidden md:inline">Bài {cur + 1}/{TOPIC.total}</span><span>{lesson.duration}</span><span>{TOPIC.views} lượt xem</span>
                <span className="rounded-md bg-brand-500 px-2 py-0.5 text-[11px] font-bold tracking-wide text-white">{lesson.tag}</span>
              </div>
              <div className="md:hidden">{progress}</div>
            </div>
            <div className="hidden gap-2.5 md:flex">
              <button type="button" onClick={prev} className="btn border border-[#E3DCD3] bg-white text-sm text-ink">Bài trước</button>
              <button type="button" onClick={next} className="btn btn-accent text-sm"><Icon name="check" size={17} strokeWidth={2.6} />Hoàn thành &amp; học tiếp</button>
            </div>
          </div>

          <section className="bg-white md:rounded-2xl md:border md:border-line">
            <div role="tablist" aria-label="Nội dung bài học" className="sticky top-[calc(56px+56.25vw)] z-10 grid grid-cols-4 border-y border-line bg-white md:static md:flex md:gap-1 md:border-t-0 md:px-3">
              {TABS.map(([id, label]) => (
                <button key={id} type="button" role="tab" aria-selected={tab === id} onClick={() => setTab(id)}
                  className={`h-12 text-sm md:h-[52px] md:px-3.5 md:text-[15px] ${id === 'lessons' ? 'md:hidden' : ''} ${tab === id ? 'font-bold text-accent-600 shadow-[inset_0_-3px_0_#F29546]' : 'font-medium text-muted'} ${tab === 'lessons' && id === 'desc' ? 'md:font-bold md:text-accent-600 md:shadow-[inset_0_-3px_0_#F29546]' : ''}`}>{label}</button>
              ))}
            </div>
            <div role="tabpanel" className="md:hidden">{tabContent(tab)}</div>
            <div role="tabpanel" className="hidden md:block">{tabContent(tab === 'lessons' ? 'desc' : tab)}</div>
          </section>
        </div>

        <aside className="hidden min-w-0 max-w-[420px] flex-[1_1_360px] flex-col overflow-hidden rounded-2xl border border-line bg-white md:flex">
          <div className="flex flex-col gap-3 border-b border-line p-[18px]">
            <button type="button" className="flex h-[46px] items-center justify-between rounded-xl border border-[#E3DCD3] px-3.5">
              <span className="flex flex-col items-start"><span className="text-[11px] text-muted">Chuyên đề</span><strong className="text-[15px]">{TOPIC.title}</strong></span><Icon name="chevronDown" size={18} />
            </button>
            <div className="flex justify-between text-[13px] text-muted"><span>{TOPIC.total} video · {TOPIC.length}</span></div>
            {progress}
            <label className="flex h-10 items-center gap-2 rounded-[10px] bg-[#F3F0EC] px-3 text-muted"><Icon name="search" size={16} /><span className="sr-only">Tìm trong bài học</span><input placeholder={`Tìm trong ${TOPIC.total} bài`} className="w-full bg-transparent text-sm text-ink outline-none" /></label>
          </div>
          <div className="max-h-[640px] overflow-y-auto p-2">{lessonList}</div>
        </aside>
      </div>

      {/* Thanh hành động cố định đáy (Mobile) */}
      <div className="fixed inset-x-0 bottom-0 z-30 flex gap-2.5 border-t border-line bg-white px-3 pb-3.5 pt-2.5 md:hidden">
        <button type="button" onClick={prev} aria-label="Bài trước" className="flex h-12 w-[52px] items-center justify-center rounded-[14px] border border-[#E3DCD3]"><Icon name="chevronLeft" size={20} strokeWidth={2.2} /></button>
        <button type="button" onClick={next} className="btn btn-accent btn-lg h-12 flex-1"><Icon name="check" size={18} strokeWidth={2.6} />Hoàn thành &amp; học tiếp</button>
      </div>
    </div>
  );
}
