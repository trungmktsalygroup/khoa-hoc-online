'use client';
import Image from 'next/image';
import { useEffect, useState } from 'react';
import type { LessonVideo } from '@/data/lessons';
import { embedBlocked } from '@/lib/embed';
import { Icon } from '@/components/ui/Icon';

const src = (v: LessonVideo) => v.provider === 'vimeo'
  ? `https://player.vimeo.com/video/${v.id}?${v.h ? `h=${v.h}&` : ''}title=0&byline=0&portrait=0&badge=0&autopause=0&dnt=1`
  : `https://www.youtube.com/embed/${v.id}?rel=0&playsinline=1&modestbranding=1`;
const watchUrl = (v: LessonVideo) => v.provider === 'vimeo' ? `https://vimeo.com/${v.id}` : `https://www.youtube.com/watch?v=${v.id}`;

/** Trình phát video bài học. Nơi chặn nhúng (link xem thử) → ảnh bìa + mở video ở tab mới. */
export function LessonPlayer({ video }: { video: LessonVideo }) {
  const [blocked, setBlocked] = useState(false);
  useEffect(() => setBlocked(embedBlocked()), []);

  if (blocked) {
    return (
      <a href={watchUrl(video)} target="_blank" rel="noopener" className="group absolute inset-0 block" aria-label={`Xem video: ${video.title}`}>
        {video.thumb && <Image src={video.thumb} alt="" fill sizes="900px" className="object-cover opacity-90" />}
        <span className="absolute inset-0 bg-black/35" aria-hidden />
        <span className="absolute left-1/2 top-1/2 flex -translate-x-1/2 -translate-y-1/2 flex-col items-center gap-2 text-white">
          <span className="flex size-11 items-center justify-center rounded-full bg-accent-500 shadow-lg transition-transform group-hover:scale-105 md:size-14"><Icon name="play" size={20} className="translate-x-0.5" /></span>
          <span className="whitespace-nowrap rounded-full bg-black/60 px-3 py-1 text-[11.5px] font-semibold md:text-[12.5px]">Xem trên {video.provider === 'vimeo' ? 'Vimeo' : 'YouTube'} ↗</span>
        </span>
      </a>
    );
  }
  return (
    <iframe className="absolute inset-0 size-full" src={src(video)} title={video.title}
      allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; fullscreen; web-share"
      referrerPolicy="strict-origin-when-cross-origin" allowFullScreen />
  );
}
