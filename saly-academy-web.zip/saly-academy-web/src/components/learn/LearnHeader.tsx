import Image from 'next/image';
import Link from 'next/link';
import { Icon } from '@/components/ui/Icon';

const LINKS = [['Khóa học của tôi', '/hoc/tra-trai-cay', true], ['Khóa học', '/khoa-hoc', false], ['Công cụ', '/cong-cu', false], ['Hoạt động', '/hoat-dong', false], ['Blog', '/blog', false]] as const;

/** Header dành cho học viên đã đăng nhập. TODO: lấy tên/gói từ phiên đăng nhập. */
export function LearnHeader() {
  return (
    <header className="sticky top-0 z-40 hidden border-b border-line bg-white md:block">
      <div className="mx-auto flex min-h-[68px] max-w-[1360px] flex-wrap items-center gap-6 px-6">
        <Link href="/" aria-label="SaLy Academy – Trang chủ"><Image src="/images/logo-saly-academy.png" alt="SaLy Academy" width={936} height={250} className="h-[46px] w-auto" /></Link>
        <nav aria-label="Menu học viên" className="flex flex-wrap gap-1">
          {LINKS.map(([t, h, a]) => <Link key={t} href={h} aria-current={a ? 'page' : undefined} className={`rounded-[10px] px-3 py-2.5 text-sm ${a ? 'bg-accent-50 font-bold text-accent-600' : 'font-medium text-ink-2'}`}>{t}</Link>)}
        </nav>
        <div className="flex flex-[1_1_200px] items-center justify-end gap-3">
          <label className="flex h-[42px] min-w-40 flex-[0_1_280px] items-center gap-2 rounded-xl bg-[#F3F0EC] px-3.5 text-muted"><Icon name="search" size={17} /><span className="sr-only">Tìm bài học</span><input placeholder="Tìm bài học, công thức…" className="w-full bg-transparent text-sm text-ink outline-none" /></label>
          <button type="button" className="flex h-11 items-center gap-2.5 rounded-full border border-line pl-1 pr-3">
            <span className="flex size-9 items-center justify-center rounded-full bg-brand-600 text-sm font-bold text-white">LT</span>
            <span className="text-sm font-semibold">Lê Tr…</span>
            <span className="rounded-md bg-brand-500 px-1.5 py-0.5 text-[11px] font-bold text-white">PRO</span>
          </button>
        </div>
      </div>
    </header>
  );
}
