import Image from 'next/image';
import type { CSSProperties } from 'react';
import { TIMELINE } from '@/data/home';
import { Reveal } from '@/components/ui/Reveal';

/** Đường cong nét đứt nối ảnh mốc này sang mốc kế tiếp (giống lypham.vn) */
function Connector({ flip }: { flip: boolean }) {
  return (
    <svg viewBox="0 0 600 120" preserveAspectRatio="none" aria-hidden className={`jt-connector mx-auto hidden h-24 w-[56%] md:block ${flip ? '-scale-x-100' : ''}`}>
      <path d="M40 0 C 60 70, 260 50, 330 70 S 540 90, 560 120" fill="none" stroke="#F4C9A3" strokeWidth="26" strokeLinecap="round" opacity=".45" />
      <path d="M40 0 C 60 70, 260 50, 330 70 S 540 90, 560 120" fill="none" stroke="#E5761F" strokeWidth="3" strokeDasharray="14 12" strokeLinecap="round" />
    </svg>
  );
}

export function JourneyTimeline() {
  return (
    <ol className="flex flex-col overflow-x-clip">
      {TIMELINE.map((m, i) => {
        const right = i % 2 === 1;
        return (
          <li key={m.year} className="flex flex-col">
            <Reveal className={`jt-row grid items-center gap-5 md:grid-cols-2 md:gap-14 ${right ? 'jt-right' : 'jt-left'}`} threshold={0.35}>
              <figure className={`jt-photo group relative mx-auto w-full max-w-[460px] ${right ? 'md:order-2 md:mr-0' : 'md:ml-0'}`}>
                <div className={`relative transition-[rotate,scale] duration-500 ease-out group-hover:scale-[1.02] ${right ? 'group-hover:rotate-[2deg]' : 'group-hover:-rotate-[2deg]'}`}>
                  <Image src={m.photo} alt={`${m.year} – ${m.title}`} width={m.w} height={m.h} sizes="(max-width: 768px) 100vw, 520px"
                    className="h-auto w-full rounded-2xl border-[6px] border-white object-cover shadow-[0_18px_40px_rgba(20,67,42,0.16)] transition-shadow duration-500 group-hover:shadow-[0_26px_50px_rgba(20,67,42,0.24)]" />
                  {!m.yearOnPhoto && (
                    <span className="absolute bottom-4 left-4 rounded-lg bg-white/90 px-3 py-1 text-2xl font-extrabold text-brand-700 shadow-sm md:text-3xl">{m.year}</span>
                  )}
                </div>
              </figure>
              <div className={`jt-text flex flex-col gap-3 ${right ? 'md:order-1 md:items-end md:text-right' : ''}`} style={{ '--d': '160ms' } as CSSProperties}>
                <span className="font-display text-[44px] font-bold leading-none tracking-tight text-accent-500 md:text-[56px]">{m.year}</span>
                <h3 className="text-[20px] font-extrabold uppercase leading-tight tracking-[-0.01em] text-brand-700 md:text-[26px]">{m.title}</h3>
                <p className={`max-w-[460px] text-[15px] leading-[26px] text-ink-2 ${right ? 'md:border-r-[3px] md:pr-4' : 'md:border-l-[3px] md:pl-4'} border-accent-500`}>{m.text}</p>
              </div>
            </Reveal>
            {i < TIMELINE.length - 1 && (
              <Reveal className="jt-link" threshold={0.6}>
                <Connector flip={right} />
                <span className="mx-auto my-4 block h-10 w-0 border-l-2 border-dashed border-accent-500/60 md:hidden" aria-hidden />
              </Reveal>
            )}
          </li>
        );
      })}
    </ol>
  );
}
