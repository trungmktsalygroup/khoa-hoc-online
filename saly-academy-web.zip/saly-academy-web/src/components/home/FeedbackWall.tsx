import Image from 'next/image';
import { FEEDBACK_COLUMNS } from '@/data/home';

/** Tường lời khen của học viên: các cột ảnh tự chạy lên / xuống xen kẽ, dừng khi rê chuột. */
export function FeedbackWall() {
  return (
    <div className="feedback-wall relative grid h-[560px] grid-cols-2 gap-3 overflow-hidden md:h-[680px] md:grid-cols-4 md:gap-5">
      {FEEDBACK_COLUMNS.map((col, c) => (
        <div key={c} className={`overflow-hidden ${c >= 2 ? 'hidden md:block' : ''}`}>
          {/* Lặp 2 lần để chạy liên tục không đứt đoạn */}
          <div className={`fw-track flex flex-col ${c % 2 ? 'fw-down' : 'fw-up'}`} style={{ animationDuration: `${38 + c * 6}s` }}>
            {[...col, ...col].map((img, i) => (
              <Image key={i} src={img.src} alt={i < col.length ? 'Lời khen, tin nhắn của học viên SaLy Academy' : ''} aria-hidden={i >= col.length}
                width={img.w} height={img.h} sizes="(max-width: 768px) 50vw, 300px"
                className="mb-3 h-auto w-full rounded-2xl border md:mb-5 border-black/5 bg-white shadow-[0_6px_20px_rgba(20,67,42,0.08)]" />
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}
