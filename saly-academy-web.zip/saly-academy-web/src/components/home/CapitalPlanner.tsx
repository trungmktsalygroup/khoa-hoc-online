'use client';
import Image from 'next/image';
import Link from 'next/link';
import { useState } from 'react';
import { DEAL, PACKAGES } from '@/data/packages';
import { vnd } from '@/lib/format';
import { CheckCircle, Icon } from '@/components/ui/Icon';

/** Khách tự nhận diện KIỂU MÔ HÌNH (không công khai mức vốn – theo Insight) → gói phù hợp → 1 nút duy nhất */
export function CapitalPlanner() {
  const [i, setI] = useState(1);
  const p = PACKAGES[i];
  return (
    <div className="card grid gap-5 p-[18px] shadow-[0_20px_48px_rgba(20,67,42,0.10)] md:gap-8 md:p-8 lg:grid-cols-2">
      <div className="flex min-w-0 flex-col gap-3.5">
        <span className="eyebrow">BƯỚC ĐẦU TIÊN</span>
        <h2 className="text-[20px] font-extrabold leading-tight text-brand-700 md:text-[24px]">Bạn đang hình dung quán của mình thế nào?</h2>
        <div role="radiogroup" aria-label="Kiểu quán bạn muốn mở" className="grid grid-cols-2 gap-2.5">
          {PACKAGES.map((c, k) => (
            <button key={c.slug} type="button" role="radio" aria-checked={k === i} onClick={() => setI(k)}
              className={`flex min-h-[72px] items-center gap-3 rounded-[14px] border-2 p-2.5 text-left transition-colors md:min-h-[84px] ${k === i ? 'border-brand-600 bg-brand-100' : 'border-line bg-white hover:border-line-2'}`}>
              <Image src={c.image} alt="" width={64} height={64} className="hidden size-12 shrink-0 rounded-xl object-cover sm:block md:size-14" />
              <span className="flex min-w-0 flex-col">
                <strong className={`text-[15px] leading-tight ${k === i ? 'text-brand-600' : 'text-ink'}`}>{c.choice}</strong>
                <span className="mt-0.5 text-[12.5px] leading-snug text-muted">{c.tagline}</span>
              </span>
            </button>
          ))}
        </div>
        <p className="text-[13px] leading-5 text-muted">Chưa chắc? Chọn kiểu gần nhất – hoặc để tư vấn viên giúp bạn xác định mô hình.</p>
        <div className="mt-2 hidden flex-col gap-3 rounded-2xl border border-line p-4 lg:flex">
          <strong className="text-[15px] text-brand-700">Vì sao nên học theo mô hình?</strong>
          {([['Đúng món, đủ món', 'Chỉ học những chuyên đề mô hình của bạn thật sự cần bán – không mua thừa khóa.'], ['Lộ trình đóng gói sẵn', 'Biết học gì trước, học gì sau – không phải tự ghép nhiều khóa lẻ.'], ['Đồng hành đến ngày khai trương', 'Trợ giảng hỗ trợ 1-1, setup menu giá bán và tư vấn nguyên liệu theo menu.']] as const).map(([t, d], k) => (
            <div key={t} className="flex gap-3">
              <span className="flex size-7 shrink-0 items-center justify-center rounded-full bg-accent-500 text-[13px] font-extrabold text-white">{k + 1}</span>
              <span className="flex flex-col"><strong className="text-[14px] text-ink">{t}</strong><span className="text-[13px] leading-5 text-muted">{d}</span></span>
            </div>
          ))}
        </div>
      </div>

      <div className="flex min-w-0 flex-col overflow-hidden rounded-[18px] bg-mint" aria-live="polite">
        <div key={p.image} className="cp-fade relative aspect-[16/9] w-full overflow-hidden">
          <Image src={p.image} alt={`Mô hình ${p.short} của học viên SaLy Academy`} fill sizes="(max-width: 768px) 100vw, 520px" className="object-cover" />
          <span className="absolute inset-x-0 bottom-0 h-1/2 bg-gradient-to-t from-black/55 to-transparent" aria-hidden />
          <span className="absolute left-3 top-3 rounded-full bg-white/95 px-3 py-1 text-[12px] font-bold text-brand-700">Mô hình gợi ý</span>
          <strong className="absolute bottom-3 left-4 right-4 text-[20px] leading-tight text-white drop-shadow md:text-[23px]">{p.short}</strong>
        </div>
        <div className="flex flex-1 flex-col gap-3 p-4 md:p-5">
          <p className="text-[14.5px] leading-[23px] text-ink-2">{p.focus}</p>
          <div className="flex flex-col gap-1.5">
            <span className="text-[12.5px] font-extrabold uppercase tracking-wide text-accent-600">Học xong, bạn làm được</span>
            <ul className="flex flex-col gap-1.5 text-[14px] leading-[21px]">
              {p.outcomes.slice(0, 3).map((o) => <li key={o} className="flex gap-2"><CheckCircle size={16} />{o}</li>)}
            </ul>
          </div>
          <div className="flex items-center gap-3 rounded-xl bg-white px-3.5 py-3">
            <span className="relative h-12 w-[72px] shrink-0 overflow-hidden rounded-lg bg-line md:h-14 md:w-[84px]">
              <Image key={p.thumb} src={p.thumb} alt="" fill sizes="84px" className="cp-fade object-cover" />
              <span className="absolute bottom-1 left-1 flex size-5 items-center justify-center rounded-full bg-black/55 text-white"><Icon name="play" size={10} /></span>
            </span>
            <span className="flex min-w-0 flex-1 flex-col"><span className="text-xs text-muted">Gói khóa học phù hợp</span><strong className="text-[15px] leading-snug">{p.name}</strong><span className="mt-0.5 text-[14px] font-extrabold text-accent-600 sm:hidden">{vnd(p.dealPrice ?? p.price)}{p.dealPrice && <span className="ml-1.5 text-[11px] font-normal text-muted">mở bán {DEAL.label}</span>}</span></span>
            <span className="hidden shrink-0 flex-col items-end leading-tight sm:flex">
              <strong className="text-[15px] text-accent-600">{vnd(p.dealPrice ?? p.price)}</strong>
              {p.dealPrice && <span className="text-[11px] text-muted">mở bán {DEAL.label}</span>}
            </span>
          </div>
          <div className="flex flex-wrap gap-1.5 text-[12px] font-semibold text-ink-2">
            <span className="rounded-full bg-white px-2.5 py-1">{p.topics.length} khóa học</span>
            <span className="rounded-full bg-white px-2.5 py-1">{p.benefits.length} quyền lợi</span>
            {p.gifts.length > 0 && <span className="rounded-full bg-accent-100 px-2.5 py-1 text-accent-700">🎁 {p.gifts.length} quà tặng</span>}
            {p.dealGift && <span className="rounded-full bg-accent-100 px-2.5 py-1 text-accent-700">🎁 {p.dealGift}</span>}
          </div>
          <Link href={`/khoa-hoc/${p.slug}`} className="btn btn-accent btn-lg mt-auto w-full">Xem gói khóa học phù hợp <Icon name="arrowRight" size={16} strokeWidth={2.4} /></Link>
          <Link href="/khoa-hoc#so-sanh" className="-mt-1 text-center text-[13.5px] font-bold text-brand-600 hover:underline">So sánh cả 4 gói</Link>
        </div>
      </div>
    </div>
  );
}
