'use client';
import { useRouter } from 'next/navigation';
import { useState, type FormEvent, type ReactNode } from 'react';
import { SITE } from '@/data/site';
import { Icon } from '@/components/ui/Icon';

function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <label className="relative flex flex-col">
      <span className="absolute -top-2 left-3 bg-white px-1 text-[11.5px] font-medium text-muted">{label}</span>
      {children}
    </label>
  );
}

function Password({ name, placeholder, autoComplete }: { name: string; placeholder: string; autoComplete: string }) {
  const [show, setShow] = useState(false);
  return (
    <div className="flex h-12 items-center rounded-xl border border-[#D9D3CB] pl-3.5 pr-1 focus-within:border-brand-600">
      <input name={name} type={show ? 'text' : 'password'} placeholder={placeholder} autoComplete={autoComplete} className="min-w-0 flex-1 bg-transparent text-[15px] outline-none" />
      <button type="button" onClick={() => setShow((s) => !s)} aria-label={show ? 'Ẩn mật khẩu' : 'Hiện mật khẩu'} className="flex size-10 items-center justify-center text-muted">
        <Icon name="eye" size={18} />
      </button>
    </div>
  );
}

const INPUT = 'h-12 w-full rounded-xl border border-[#D9D3CB] px-3.5 text-[15px] outline-none focus:border-brand-600';

/** Form đăng ký học thử / đăng nhập ngay ở màn hình đầu trang chủ. TODO: nối Auth (Google + email) thật. */
export function HeroSignup() {
  const router = useRouter();
  const [tab, setTab] = useState<'register' | 'login'>('register');
  const [error, setError] = useState('');
  const [sending, setSending] = useState(false);
  const reg = tab === 'register';

  async function submit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const f = new FormData(e.currentTarget);
    const email = String(f.get('email') ?? '').trim();
    const pw = String(f.get('password') ?? '');
    if (!/^\S+@\S+\.\S+$/.test(email)) return setError('Email chưa đúng định dạng.');
    if (reg) {
      const phone = String(f.get('phone') ?? '').replace(/\s/g, '');
      if (!/^0\d{9}$/.test(phone)) return setError('Số điện thoại chưa đúng (10 số, bắt đầu bằng 0).');
      if (pw.length < 6) return setError('Mật khẩu cần ít nhất 6 ký tự.');
      if (pw !== f.get('confirm')) return setError('Mật khẩu xác nhận chưa khớp.');
      setError(''); setSending(true);
      await fetch('/api/lead', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ source: 'trang-chu-dang-ky-hoc-thu', email, phone }) }).catch(() => null);
      setSending(false);
    } else {
      if (!pw) return setError('Vui lòng nhập mật khẩu.');
      setError('');
    }
    router.push('/hoc/tra-trai-cay');
  }

  return (
    <div id="dang-ky" className="scroll-mt-24 overflow-hidden rounded-[22px] bg-white text-ink shadow-[0_30px_70px_rgba(4,40,22,0.35)]">
      {/* Dải xanh cam kết */}
      <div className="flex items-center gap-3 bg-[#22B573] px-5 py-4 text-white md:px-6">
        <span className="flex size-11 shrink-0 items-center justify-center rounded-full bg-white/20"><Icon name="check" size={22} strokeWidth={2.8} /></span>
        <p className="text-[14.5px] font-bold leading-snug md:text-[16px]">Không nhập form rườm rà, không nhập thẻ, không giới hạn thời gian – Đăng ký là học ngay!</p>
      </div>

      <div className="flex flex-col gap-4 p-4 md:p-5">
        <ul className="grid grid-cols-3 divide-x divide-line text-center">
          {([['wallet', 'Không cần nạp thẻ'], ['infinity', 'Không giới hạn thời gian'], ['bell', 'Không gửi tin rác']] as const).map(([ic, t]) => (
            <li key={t} className="flex flex-col items-center gap-1.5 px-1.5">
              <Icon name={ic} size={22} className="text-brand-600" />
              <span className="text-[11.5px] font-bold uppercase leading-tight text-ink-2 md:text-[12.5px]">{t}</span>
            </li>
          ))}
        </ul>

        <button type="button" className="flex h-12 items-center justify-center gap-2.5 rounded-xl border border-[#D9D3CB] bg-white text-[15px] font-semibold hover:bg-mint">
          <svg width="20" height="20" viewBox="0 0 48 48" aria-hidden><path fill="#FFC107" d="M43.6 20.5H42V20H24v8h11.3C33.7 32.7 29.2 36 24 36c-6.6 0-12-5.4-12-12s5.4-12 12-12c3.1 0 5.8 1.2 7.9 3.1l5.7-5.7C34 6.1 29.3 4 24 4 13 4 4 13 4 24s9 20 20 20 20-9 20-20c0-1.3-.1-2.4-.4-3.5z" /><path fill="#FF3D00" d="M6.3 14.7l6.6 4.8C14.7 15.1 19 12 24 12c3.1 0 5.8 1.2 7.9 3.1l5.7-5.7C34 6.1 29.3 4 24 4 16.3 4 9.7 8.3 6.3 14.7z" /><path fill="#4CAF50" d="M24 44c5.2 0 9.9-2 13.4-5.2l-6.2-5.2C29.2 35.1 26.7 36 24 36c-5.2 0-9.6-3.3-11.3-7.9l-6.5 5C9.5 39.6 16.2 44 24 44z" /><path fill="#1976D2" d="M43.6 20.5H42V20H24v8h11.3c-.8 2.2-2.2 4.2-4.1 5.6l6.2 5.2C37 39.2 44 34 44 24c0-1.3-.1-2.4-.4-3.5z" /></svg>
          Đăng nhập với Google
        </button>

        <div className="overflow-hidden rounded-2xl border-2 border-accent-500">
          <div role="tablist" aria-label="Đăng ký hoặc đăng nhập" className="grid grid-cols-2 bg-accent-500">
            {(['register', 'login'] as const).map((t) => (
              <button key={t} type="button" role="tab" aria-selected={tab === t} onClick={() => { setTab(t); setError(''); }}
                className={`h-12 text-[16px] font-bold transition-colors ${tab === t ? 'rounded-t-xl bg-white text-accent-600' : 'text-white hover:bg-white/10'}`}>
                {t === 'register' ? 'Đăng ký ngay' : 'Đăng nhập'}
              </button>
            ))}
          </div>
          <form onSubmit={submit} noValidate className="flex flex-col gap-4 bg-white p-4">
            <p className="text-[13.5px] text-ink-2">{reg ? <>Không có thêm bước nào cả – <span className="font-semibold text-brand-600">đăng ký là xem được ngay!</span></> : 'Đăng nhập để học tiếp bài đang dở.'}</p>
            <div className={`grid gap-4 ${reg ? 'sm:grid-cols-2' : ''}`}>
              <Field label="Email"><input name="email" type="email" placeholder="Email của bạn" autoComplete="email" className={INPUT} /></Field>
              {reg && <Field label="Số điện thoại"><input name="phone" type="tel" placeholder="Số điện thoại của bạn" autoComplete="tel" className={INPUT} /></Field>}
              <Field label="Mật khẩu"><Password name="password" placeholder="Mật khẩu" autoComplete={reg ? 'new-password' : 'current-password'} /></Field>
              {reg && <Field label="Xác nhận mật khẩu"><Password name="confirm" placeholder="Nhập lại mật khẩu" autoComplete="new-password" /></Field>}
            </div>
            {!reg && <a href="#" className="-mt-1 self-end text-[13px] font-semibold text-accent-600">Quên mật khẩu?</a>}
            {SITE.demoMode && (
              <p className="flex items-start gap-2 rounded-xl border border-dashed border-accent-500/60 bg-accent-100 px-3 py-2.5 text-[13px] leading-5 text-ink-2" role="note">
                <span className="shrink-0 rounded bg-accent-500 px-1.5 py-0.5 text-[10.5px] font-extrabold text-white">DEMO</span>
                <span>Bản demo: nhập <strong>email và mật khẩu bất kỳ</strong> để thử{reg ? ' (email, số điện thoại đúng định dạng)' : ''}.</span>
              </p>
            )}
            {error && <p role="alert" className="text-[13.5px] font-semibold text-[#B42318]">{error}</p>}
            <button type="submit" disabled={sending}
              className="relative flex min-h-[64px] items-center justify-center gap-3 rounded-xl bg-gradient-to-r from-accent-500 to-[#F27B2E] px-4 py-2.5 text-white shadow-[0_10px_24px_rgba(242,123,46,0.35)] transition-[filter] hover:brightness-95 disabled:opacity-60">
              {reg && <span className="free-spin hidden size-11 shrink-0 items-center min-[380px]:flex justify-center rounded-full bg-[#FFD34E] text-[11px] font-extrabold text-[#C9621A] shadow" aria-hidden>FREE</span>}
              <span className="flex flex-col items-start leading-tight">
                <strong className="whitespace-nowrap text-[15.5px] font-extrabold uppercase sm:text-[17px] md:text-[19px]">{sending ? 'Đang tạo tài khoản…' : reg ? 'Đăng ký học thử ngay' : 'Đăng nhập & học ngay'}</strong>
                {reg && <span className="whitespace-nowrap text-[12px] font-medium text-white/90 sm:text-[12.5px]">Hoàn toàn miễn phí · {SITE.stats.freeLessons} bài học</span>}
              </span>
            </button>
          </form>
        </div>
        <p className="text-center text-[13px] leading-5 text-ink-2">Khóa học đã được chứng minh qua <span className="font-bold text-accent-600">{SITE.stats.students} học viên mở quán thành công</span>. Cần hỗ trợ? Gọi <a href={SITE.hotlineTel} className="font-bold text-brand-600">{SITE.hotline}</a></p>
      </div>
    </div>
  );
}
