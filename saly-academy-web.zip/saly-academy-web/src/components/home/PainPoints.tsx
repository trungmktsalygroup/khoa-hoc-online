import Image from 'next/image';
import type { ReactNode } from 'react';

/** Theo Insight học viên Online: pain chỉ để mở nhu cầu (mơ hồ về mô hình & lộ trình), không đẩy bài toán tài chính */
const PAINS = [
  ['Chưa biết nên chọn mô hình nào', 'Xe trà, quán mang đi hay quán có chỗ ngồi – mô hình nào hợp với mình?'],
  ['Không biết học gì để bắt đầu bán', 'Nhiều chuyên đề rời rạc, không biết học cái nào trước, học bao nhiêu là đủ.'],
  ['Không biết xây menu, chọn món chủ lực', 'Món nào nên bán trước, menu bao nhiêu món là vừa với tệp khách?'],
  ['Sợ học Online chỉ có video', 'Xem xong vẫn không biết áp dụng vào quán của mình thế nào.'],
];

function Emoji({ children, className = '' }: { children: ReactNode; className?: string }) {
  return <span aria-hidden className={`absolute select-none text-[34px] leading-none drop-shadow-[0_4px_8px_rgba(0,0,0,0.18)] ${className}`}>{children}</span>;
}

/** Thẻ minh họa: phân vân chọn mô hình */
function CostCard() {
  const opts = ['Xe trà', 'Quán mang đi', 'Quán có chỗ ngồi'];
  return (
    <div className="relative w-[230px] rounded-2xl bg-white p-4 shadow-[0_18px_40px_rgba(20,67,42,0.14)]">
      <strong className="text-[15px] text-ink">Nên mở mô hình nào?</strong>
      <div className="mt-3 flex flex-col gap-2">
        {opts.map((o) => (
          <div key={o} className="flex items-center gap-2 rounded-lg border border-line px-2.5 py-1.5 text-[12.5px]">
            <span className="size-3.5 rounded-full border-2 border-line-2" />{o}<span className="ml-auto font-bold text-accent-600">?</span>
          </div>
        ))}
      </div>
      <Emoji className="-bottom-5 -left-5">🤔</Emoji>
    </div>
  );
}

/** Thẻ minh họa: quá nhiều chuyên đề rời */
function RevenueCard() {
  const tags = ['Trà trái cây', 'Cà phê', 'Matcha', 'Trà sữa', 'Topping', 'Nước ép', 'Đá xay', 'Sinh tố', 'Sữa chua', 'Kế hoạch mở quán'];
  return (
    <div className="relative w-[250px] rounded-2xl bg-white p-4 shadow-[0_18px_40px_rgba(20,67,42,0.14)]">
      <strong className="text-[15px] text-ink">Học cái nào trước?</strong>
      <div className="mt-3 flex flex-wrap gap-1.5">
        {tags.map((t, i) => <span key={t} className={`rounded-full px-2 py-0.5 text-[11.5px] font-semibold ${i % 3 === 0 ? 'bg-accent-100 text-accent-700' : 'bg-mint text-ink-2'}`}>{t}</span>)}
      </div>
      <Emoji className="-right-4 -top-6">😟</Emoji>
    </div>
  );
}

function XIcon() {
  return (
    <svg width="22" height="22" viewBox="0 0 24 24" aria-hidden className="mt-0.5 shrink-0">
      <circle cx="12" cy="12" r="11" fill="#D92D20" />
      <path d="M8.5 8.5l7 7M15.5 8.5l-7 7" stroke="#fff" strokeWidth="2.4" strokeLinecap="round" />
    </svg>
  );
}

export function PainPoints() {
  return (
    <section className="section relative overflow-hidden">
      {/* Hình minh họa trôi hai bên (máy tính) */}
      <div className="pointer-events-none absolute inset-0 hidden xl:block" aria-hidden>
        <div className="float-y-slow absolute left-[3%] top-[12%] w-[300px] -rotate-2">
          <Image src="/images/noi-lo/menu-board.png" alt="" width={448} height={340} className="h-auto w-full" />
        </div>
        <div className="float-y-late absolute bottom-[10%] left-[6%] rotate-1"><CostCard /></div>
        <div className="float-y absolute right-[4%] top-[14%] rotate-2"><RevenueCard /></div>
        <div className="float-y-slow absolute bottom-[8%] right-[3%] w-[300px] rotate-1">
          <Image src="/images/noi-lo/stressed.png" alt="" width={465} height={366} className="h-auto w-full" />
        </div>
      </div>

      <div className="container-site relative flex flex-col items-center gap-8 md:gap-10">
        <h2 className="flex flex-col items-center gap-1 text-center text-[21px] font-extrabold uppercase leading-tight tracking-[-0.01em] [text-shadow:0_6px_24px_rgba(255,255,255,0.95)] md:text-[36px]">
          <span className="text-[#0A7D45]">Bạn đang có ý định khởi nghiệp</span>
          <span className="text-accent-500">mở quán cà phê, trà sữa nhưng…</span>
        </h2>

        <ul className="w-full max-w-[680px] rounded-2xl border-2 border-[#D92D20] bg-white px-5 py-2 shadow-[0_20px_50px_rgba(217,45,32,0.10)] md:px-7">
          {PAINS.map(([t, d]) => (
            <li key={t} className="flex gap-3 border-b border-[#ECE7E1] py-4 last:border-b-0 md:py-5">
              <XIcon />
              <div className="flex flex-col gap-1">
                <strong className="text-[15px] font-extrabold uppercase leading-snug text-[#D92D20] md:text-[17px]">{t}</strong>
                <span className="text-[14.5px] leading-6 text-ink-2 md:text-base">{d}</span>
              </div>
            </li>
          ))}
        </ul>

        {/* Ảnh minh họa dưới thẻ (điện thoại, máy tính bảng) */}
        <div className="grid w-full max-w-[680px] grid-cols-2 gap-3 xl:hidden" aria-hidden>
          <Image src="/images/noi-lo/menu-board.png" alt="" width={448} height={340} className="h-auto w-full" />
          <Image src="/images/noi-lo/stressed.png" alt="" width={465} height={366} className="h-auto w-full" />
        </div>

        <p className="max-w-[560px] text-center text-[15px] font-semibold leading-6 text-brand-600 md:text-base">Bạn không thiếu nội dung để học – bạn cần một lộ trình đúng mô hình. SaLy đã đóng gói sẵn lộ trình đó cho từng kiểu quán.</p>
      </div>
    </section>
  );
}
