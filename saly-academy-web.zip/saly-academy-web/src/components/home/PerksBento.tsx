import Image from 'next/image';
import { SITE } from '@/data/site';
import type { ReactNode } from 'react';
import { Icon, type IconName } from '@/components/ui/Icon';
import { SectionHead } from '@/components/shared/SectionHead';

/** Nhãn nổi trên ảnh – minh họa quyền lợi bằng hình thay vì chữ dài */
function Chip({ children, className = '' }: { children: ReactNode; className?: string }) {
  return <div className={`absolute rounded-2xl bg-white/95 px-3.5 py-2.5 text-[13px] leading-snug text-ink shadow-[0_10px_28px_rgba(0,0,0,0.18)] backdrop-blur ${className}`}>{children}</div>;
}

function Card({ img, alt, icon, title, text, className = '', imgClass = '', children }: {
  img: string; alt: string; icon: IconName; title: string; text: string; className?: string; imgClass?: string; children?: ReactNode;
}) {
  return (
    <figure className={`group relative isolate flex min-h-[300px] flex-col justify-end overflow-hidden rounded-[24px] bg-brand-700 ${className}`}>
      <Image src={img} alt={alt} fill sizes="(max-width: 768px) 100vw, 50vw" className={`-z-10 object-cover transition-transform duration-700 group-hover:scale-[1.04] ${imgClass}`} />
      <span className="absolute inset-0 -z-10 bg-gradient-to-t from-[#06301B]/95 via-[#06301B]/35 to-transparent" aria-hidden />
      {children}
      <figcaption className="flex flex-col gap-1.5 p-5 text-white md:p-6">
        <span className="flex items-center gap-2 text-[17px] font-extrabold md:text-[19px]">
          <span className="flex size-8 shrink-0 items-center justify-center rounded-lg bg-accent-500"><Icon name={icon} size={17} /></span>
          {title}
        </span>
        <span className="text-[14px] leading-[21px] text-white/85">{text}</span>
      </figcaption>
    </figure>
  );
}

/** Đặc quyền học viên – dạng ô ảnh (bento): mỗi quyền lợi là một hình ảnh thật */
export function PerksBento() {
  return (
    <section>
      <div className="section container-site flex flex-col gap-10 md:gap-12">
        <SectionHead eyebrow="ĐẶC QUYỀN HỌC VIÊN" title="Học xong vẫn có người đồng hành" sub="Không bỏ bạn lại sau khi mua khóa: có người trả lời, có cộng đồng, có công thức mới – đến khi quán chạy ổn." />
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4 lg:grid-rows-[300px_300px] md:gap-5">
          <Card img="/images/ho-tro/doi-tro-giang.jpg" alt="Đội trợ giảng SaLy đang gọi điện hỗ trợ học viên" icon="team"
            title="Trợ giảng hỗ trợ 1-1" text="Kẹt ở bước nào, hỏi ngay – đội trợ giảng gọi điện, nhắn tin, video call hướng dẫn tận nơi."
            className="min-h-[400px] lg:col-span-2 lg:row-span-2" imgClass="object-[28%_40%]">
            <Chip className="left-4 top-4 flex items-center gap-2 !py-2 md:left-6 md:top-6">
              <span className="relative flex size-2.5"><span className="absolute inline-flex size-full animate-ping rounded-full bg-[#22B573] opacity-70" /><span className="relative inline-flex size-2.5 rounded-full bg-[#22B573]" /></span>
              <strong className="text-[13px]">Đội trợ giảng SaLy</strong><span className="hidden text-[12px] text-muted sm:inline">đang hỗ trợ học viên</span>
            </Chip>
            <figure className="absolute bottom-[132px] left-4 hidden w-[46%] max-w-[260px] overflow-hidden rounded-2xl lg:block border-4 border-white shadow-[0_16px_36px_rgba(0,0,0,0.3)] md:bottom-[140px] md:left-6 lg:w-[38%]">
              <Image src="/images/ho-tro/video-call-ho-tro.jpg" alt="Trợ giảng video call hướng dẫn học viên thực hành" width={1200} height={680} sizes="300px" className="h-auto w-full" />
              <figcaption className="flex items-center gap-1.5 whitespace-nowrap bg-white px-2.5 py-1.5 text-[11px] font-bold text-ink sm:text-[11.5px]"><Icon name="video" size={13} className="shrink-0 text-brand-600" />Video call hướng dẫn<span className="hidden lg:inline"> trực tiếp</span></figcaption>
            </figure>
          </Card>

          <Card img="/images/ho-tro/hoc-tron-doi-tra-trai-cay.jpg" alt="Ly trà trái cây Phúc Sang cùng các khay trái cây trong bài học" icon="infinity"
            title="Học trọn đời" text="Xem lại không giới hạn trên điện thoại. Công thức mới được cập nhật, không trả thêm phí." imgClass="object-[30%_40%]">
            <Chip className="right-4 top-4 flex items-center gap-1.5 !px-3 !py-1.5 font-bold"><Icon name="play" size={12} className="text-accent-600" />{SITE.stats.videos} video</Chip>
            <Chip className="right-4 top-14 !bg-accent-500 !px-3 !py-1.5 font-bold !text-white">+ Món mới</Chip>
          </Card>

          <Card img="/images/blog/tra-quyt-tuoi/cong-thuc-tinh-gia-cost-1-ly-tra-quyt.jpg" alt="Bảng tính giá cost một ly trà quýt" icon="calc"
            title="Setup menu & giá bán" text="Được hỗ trợ lên menu, tính giá cost và giá bán có lãi cho từng món." imgClass="object-[50%_35%]">
            <Chip className="right-4 top-4 !px-3 !py-2"><span className="block text-[11px] text-muted">Giá cost 1 ly</span><strong className="text-[15px] text-brand-700">6.700đ</strong> <span className="text-[11px] text-muted">→ bán 25.000đ</span></Chip>
          </Card>

          <Card img="/images/ho-tro/cong-dong-k64.jpg" alt="Cô Ly cùng học viên khóa K64 Pha chế kinh doanh nhận chứng nhận" icon="comment"
            title="Cộng đồng chủ quán" text="Nhóm học viên riêng của Cô Ly – hỏi đáp, chia sẻ kinh nghiệm với người cùng mở quán."
            className="lg:col-span-2" imgClass="object-[50%_72%]">
            <Chip className="left-4 top-4 flex items-center gap-2.5 md:left-6">
              <span className="flex -space-x-2">
                {['hv-avatar-thuy', 'hv-avatar-tai', 'hv-avatar-truc-phuong', 'hv-avatar-thuy-vinh'].map((a) => <Image key={a} src={`/images/${a}.png`} alt="" width={28} height={28} className="size-7 rounded-full border-2 border-white object-cover" />)}
              </span>
              <span className="text-[12.5px]"><strong>{SITE.stats.students}</strong> học viên đã mở quán</span>
            </Chip>
          </Card>
        </div>
        <p className="text-center text-[13px] text-muted">Áp dụng cho học viên các gói khóa học. Quyền lợi chi tiết của từng gói xem tại trang Khóa học.</p>
      </div>
    </section>
  );
}
