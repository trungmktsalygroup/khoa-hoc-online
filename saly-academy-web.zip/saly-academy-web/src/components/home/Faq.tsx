'use client';
import { useState } from 'react';
import { FAQS } from '@/data/home';

/** Câu hỏi thường gặp – kiểu danh sách đánh số như saly.academy: câu đang mở màu cam, dấu − / + bên phải */
export function Faq() {
  const [open, setOpen] = useState(0);
  return (
    <div className="flex flex-col">
      {FAQS.map((f, i) => {
        const isOpen = i === open;
        return (
          <div key={f.q} className="border-b border-[#F3DDCD] last:border-b-0">
            <h3>
              <button type="button" onClick={() => setOpen(isOpen ? -1 : i)} aria-expanded={isOpen} aria-controls={`faq-${i}`}
                className={`flex min-h-[64px] w-full items-center justify-between gap-4 py-4 text-left text-[17px] font-semibold leading-snug transition-colors md:text-[21px] ${isOpen ? 'text-accent-500' : 'text-ink-2 hover:text-accent-600'}`}>
                <span>{i + 1}. {f.q}</span>
                <span className="relative size-5 shrink-0" aria-hidden>
                  <span className="absolute left-0 top-1/2 h-0.5 w-5 -translate-y-1/2 rounded bg-current" />
                  <span className={`absolute left-1/2 top-0 h-5 w-0.5 -translate-x-1/2 rounded bg-current transition-transform duration-300 ${isOpen ? 'scale-y-0' : 'scale-y-100'}`} />
                </span>
              </button>
            </h3>
            <div id={`faq-${i}`} role="region" className={`grid transition-[grid-template-rows] duration-300 ease-out ${isOpen ? 'grid-rows-[1fr]' : 'grid-rows-[0fr]'}`}>
              <p className="overflow-hidden text-[15px] leading-[26px] text-ink-2 md:text-base md:leading-7">
                <span className="block pb-5">{f.a}</span>
              </p>
            </div>
          </div>
        );
      })}
    </div>
  );
}
