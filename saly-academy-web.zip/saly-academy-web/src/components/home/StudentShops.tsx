'use client';
import Image from 'next/image';
import { useCallback, useEffect, useState, type CSSProperties } from 'react';
import { STUDENT_SHOPS } from '@/data/home';
import { SITE } from '@/data/site';
import { CountUp } from '@/components/ui/CountUp';
import { Icon } from '@/components/ui/Icon';
import { Reveal } from '@/components/ui/Reveal';
import { Wave } from '@/components/ui/Decor';

const SUCCESS = SITE.stats.students.replace('+', ''); // số học viên – dùng chung SITE.stats.students
const ALT = 'Quán của học viên SaLy Academy';

/** Số lớn kiểu lypham.vn: chữ số trắng, dấu + xanh, dòng chú thích cắt ngang chữ số */
function BigNumber({ className = '' }: { className?: string }) {
  const caption = <>Học viên thành công mở quán,<br />hiện thực hóa giấc mơ kinh doanh</>;
  return (
    <div className={`flex flex-col items-center sm:items-start ${className}`}>
      <div className="relative inline-flex select-none items-start font-display font-bold leading-[0.8] text-white tabular-nums text-[104px] sm:text-[150px] lg:text-[clamp(130px,12.6vw,186px)]">
        {/* Khung giữ chỗ: "2." + "000" – dải chữ cắt ngang trọn phần "000" */}
        <span className="invisible" aria-hidden>2.</span>
        <span className="invisible relative inline-block" aria-hidden>
          000
          <span className="visible absolute -inset-x-[0.03em] top-[37%] z-10 hidden bg-[#F29546] [container-type:inline-size] sm:block">
            <span className="block whitespace-nowrap px-[2.5cqw] py-[2cqw] font-sans text-[4.6cqw] font-bold uppercase leading-[1.32] text-white">{caption}</span>
          </span>
        </span>
        <CountUp value={SUCCESS} duration={2000} className="absolute left-0 top-0 z-0" />
        <span className="absolute -right-[0.32em] -top-[0.06em] text-[0.42em] font-bold text-[#0A7D45]" aria-hidden>+</span>
      </div>
      <p className="mt-2 text-center text-[13px] font-bold uppercase leading-snug text-white sm:hidden">{caption}</p>
    </div>
  );
}

function Lightbox({ index, onClose, onMove }: { index: number; onClose: () => void; onMove: (d: number) => void }) {
  const p = STUDENT_SHOPS[index];
  useEffect(() => {
    const k = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose(); if (e.key === 'ArrowRight') onMove(1); if (e.key === 'ArrowLeft') onMove(-1); };
    window.addEventListener('keydown', k); document.body.style.overflow = 'hidden';
    return () => { window.removeEventListener('keydown', k); document.body.style.overflow = ''; };
  }, [onClose, onMove]);
  return (
    <div role="dialog" aria-modal="true" aria-label="Xem ảnh quán học viên" className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 p-4" onClick={onClose}>
      <figure className="relative max-h-[86vh] max-w-[92vw]" onClick={(e) => e.stopPropagation()}>
        <Image src={p.src} alt={ALT} width={p.iw} height={p.ih} sizes="92vw" className="max-h-[80vh] w-auto rounded-lg bg-white object-contain" style={{ minWidth: 'min(560px, 92vw)' }} />
        <figcaption className="mt-2 text-center text-sm text-white/80">{index + 1} / {STUDENT_SHOPS.length}</figcaption>
      </figure>
      <button type="button" onClick={(e) => { e.stopPropagation(); onMove(-1); }} aria-label="Ảnh trước" className="absolute left-3 top-1/2 flex size-12 -translate-y-1/2 items-center justify-center rounded-full bg-white/15 text-white md:left-6"><Icon name="chevronLeft" size={24} /></button>
      <button type="button" onClick={(e) => { e.stopPropagation(); onMove(1); }} aria-label="Ảnh tiếp theo" className="absolute right-3 top-1/2 flex size-12 -translate-y-1/2 items-center justify-center rounded-full bg-white/15 text-white md:right-6"><Icon name="chevronRight" size={24} /></button>
      <button type="button" onClick={onClose} aria-label="Đóng" className="absolute right-3 top-3 flex size-11 items-center justify-center rounded-full bg-white/15 text-white md:right-6 md:top-6"><Icon name="close" size={22} /></button>
    </div>
  );
}

/** Khối nền cam "Trong suốt hơn X năm qua" – bố cục ảnh ghép theo lypham.vn */
export function StudentShops() {
  const years = SITE.stats.years.replace('+', '');
  const [open, setOpen] = useState(-1);
  const move = useCallback((d: number) => setOpen((o) => (o + d + STUDENT_SHOPS.length) % STUDENT_SHOPS.length), []);
  const close = useCallback(() => setOpen(-1), []);

  return (
    <section className="relative">
      <Wave color="#F29546" />
      <div className="overflow-hidden bg-[#F29546]">
        <div className="flex flex-col gap-8 py-14 md:gap-12 md:py-20">
          <div className="container-site flex flex-col items-center gap-2 text-center">
            <h2 className="title-sticker text-[28px] font-extrabold uppercase leading-tight md:text-[52px]">
              Trong suốt hơn {years} năm qua
            </h2>
            <p className="text-[17px] font-medium text-white md:text-[26px]">Chúng tôi tự hào đã đồng hành và giúp đỡ cho hơn</p>
          </div>

          {/* Máy tính: bố cục ghép đúng tỉ lệ lypham.vn */}
          <Reveal className="ss-collage relative mx-auto hidden w-full max-w-[1410px] px-4 lg:block" threshold={0.15}>
            <div className="relative w-full" style={{ aspectRatio: '1410 / 1015' }}>
              {STUDENT_SHOPS.map((p, i) => (
                <button key={p.src} type="button" onClick={() => setOpen(i)} aria-label={`Xem ảnh ${i + 1}`}
                  className="ss-item group absolute overflow-hidden rounded-md border-[3px] border-white bg-white shadow-[0_8px_22px_rgba(120,50,0,0.25)]"
                  style={{ left: `${p.x}%`, top: `${p.y}%`, width: `${p.w}%`, height: `${p.h}%`, '--i': i } as CSSProperties}>
                  <Image src={p.src} alt={ALT} fill sizes="22vw" className="object-cover transition-transform duration-500 group-hover:scale-110" />
                </button>
              ))}
              <div className="absolute flex items-start" style={{ left: '56.2%', top: '1%', width: '29.6%' }}>
                <BigNumber />
              </div>
            </div>
          </Reveal>

          {/* Điện thoại, máy tính bảng */}
          <div className="container-site flex flex-col items-center gap-8 lg:hidden">
            <BigNumber />
            <div className="columns-2 gap-2.5 sm:columns-3">
              {STUDENT_SHOPS.slice(0, 14).map((p, i) => (
                <button key={p.src} type="button" onClick={() => setOpen(i)} aria-label={`Xem ảnh ${i + 1}`} className="mb-2.5 block w-full break-inside-avoid overflow-hidden rounded-md border-[3px] border-white bg-white shadow-[0_8px_18px_rgba(120,50,0,0.22)]">
                  <Image src={p.src} alt={ALT} width={p.iw} height={p.ih} sizes="50vw" className="h-auto w-full" />
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
      <Wave color="#F29546" flip />
      {open >= 0 && <Lightbox index={open} onClose={close} onMove={move} />}
    </section>
  );
}
