'use client';
import Link from 'next/link';
import { SHORT_VIDEOS } from '@/data/activity';
import { spriteStyle } from '@/lib/format';
import { Icon } from '@/components/ui/Icon';
import { useVideoPlayer } from '@/components/activity/VideoShorts';

/** Hàng video ngắn của Cô Ly trên trang chủ – bấm mở trình xem dọc kiểu TikTok */
export function HomeShorts() {
  const { open, player } = useVideoPlayer();
  const list = SHORT_VIDEOS.slice(0, 7);
  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-center justify-between gap-3">
        <h3 className="flex items-center gap-2.5 text-[19px] font-bold text-ink-2 md:text-[22px]">
          <span className="flex size-8 items-center justify-center rounded-full bg-[#E4007C] text-white"><Icon name="video" size={17} /></span>
          SaLy Video
        </h3>
        <Link href="/hoat-dong#kho-video" className="flex items-center gap-1.5 py-2 text-[14px] font-bold text-brand-600">Xem tất cả <Icon name="arrowRight" size={15} /></Link>
      </div>
      <div className="no-scrollbar -mx-4 flex snap-x snap-mandatory gap-3 overflow-x-auto px-4 pb-1 lg:mx-0 lg:grid lg:grid-cols-7 lg:gap-4 lg:overflow-visible lg:px-0">
        {list.map((v, i) => (
          <button key={i} type="button" onClick={() => open(i)} aria-label={`Xem video: ${v.title}`}
            className="group flex w-[38%] shrink-0 snap-start flex-col gap-2 text-left sm:w-[24%] md:w-[19%] lg:w-auto">
            <span className="relative block aspect-[3/4] w-full overflow-hidden rounded-xl bg-line shadow-[0_8px_20px_rgba(20,67,42,0.10)]">
              <span className="absolute inset-0 transition-transform duration-500 group-hover:scale-[1.04]" style={spriteStyle(i)} />
              <span className="absolute inset-x-0 bottom-0 h-1/3 bg-gradient-to-t from-black/45 to-transparent" />
              <span className="absolute left-1/2 top-1/2 flex size-12 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full bg-black/40 text-white backdrop-blur-[2px] transition-transform group-hover:scale-110 md:size-14">
                <Icon name="play" size={22} className="translate-x-0.5" />
              </span>
              <span className="absolute bottom-2 left-2 flex items-center gap-1 text-[11px] font-semibold text-white"><Icon name="play" size={10} />{v.views}</span>
            </span>
            <span className="line-clamp-2 text-[13px] font-medium leading-[18px] text-ink-2">{v.title}</span>
          </button>
        ))}
      </div>
      {player}
    </div>
  );
}
