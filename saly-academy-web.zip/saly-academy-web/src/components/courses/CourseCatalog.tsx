'use client';
import { useMemo, useState } from 'react';
import { useSearchParams } from 'next/navigation';
import { COURSES, COURSE_FILTERS, SORTS } from '@/data/courses';
import { SITE } from '@/data/site';
import { CourseCard } from '@/components/shared/CourseCard';
import { Icon } from '@/components/ui/Icon';

export function CourseCatalog() {
  const [selected, setSelected] = useState<string[]>([]);
  const [sort, setSort] = useState<(typeof SORTS)[number]>('Mới nhất');
  const params = useSearchParams();
  const [q, setQ] = useState(params.get('tim') ?? '');
  const [sheet, setSheet] = useState(false);

  const toggle = (f: string) => setSelected((s) => (s.includes(f) ? s.filter((x) => x !== f) : [...s, f]));
  const list = useMemo(() => {
    let l = COURSES.filter((c) => (selected.length ? c.categories.some((x) => selected.includes(x)) : true) && c.title.toLowerCase().includes(q.trim().toLowerCase()));
    const price = (p: number | null) => p ?? Number.MAX_SAFE_INTEGER;
    if (sort === 'Giá thấp đến cao') l = [...l].sort((a, b) => price(a.price) - price(b.price));
    if (sort === 'Giá cao đến thấp') l = [...l].sort((a, b) => (b.price ?? 0) - (a.price ?? 0));
    if (sort === 'Giảm giá nhiều nhất') l = [...l].sort((a, b) => ((b.oldPrice ?? 0) - (b.price ?? 0)) - ((a.oldPrice ?? 0) - (a.price ?? 0)));
    return l;
  }, [selected, sort, q]);

  const filterList = (
    <div className="clear-both flex flex-col gap-0.5">
      {COURSE_FILTERS.map((f) => (
        <label key={f} className={`flex min-h-11 cursor-pointer items-center gap-3 rounded-[10px] px-2 text-[15px] ${selected.includes(f) ? 'bg-brand-100' : ''}`}>
          <input type="checkbox" checked={selected.includes(f)} onChange={() => toggle(f)} className="size-5 shrink-0 accent-brand-600" />
          <span className="leading-[21px]">{f}</span>
        </label>
      ))}
    </div>
  );

  return (
    <div className="flex flex-wrap items-start gap-7">
      <aside className="hidden min-w-0 max-w-[300px] flex-[1_1_260px] flex-col gap-4 md:flex">
        <label className="flex h-[46px] items-center gap-2 rounded-xl border border-line-2 bg-white px-3.5 text-muted">
          <Icon name="search" size={18} /><span className="sr-only">Tìm khóa học</span>
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Tìm khóa học" className="w-full bg-transparent text-sm text-ink outline-none" />
        </label>
        <fieldset className="card m-0 min-w-0 px-2.5 pb-2.5 pt-4">
          <legend className="float-left mb-2 w-full px-1.5 text-base font-extrabold text-brand-700">Loại khóa học</legend>
          {filterList}
          {selected.length > 0 && <button type="button" onClick={() => setSelected([])} className="btn btn-outline mx-2 mt-2 w-[calc(100%-16px)] text-sm">Xóa tất cả bộ lọc</button>}
        </fieldset>
        <div className="flex flex-col gap-2 rounded-2xl bg-accent-100 p-[18px]">
          <strong className="text-[15px] text-brand-700">Chưa biết chọn khóa nào?</strong>
          <span className="text-sm leading-[21px] text-ink-2">Gọi để được tư vấn lộ trình phù hợp với mô hình quán của bạn.</span>
          <a href={SITE.hotlineTel} className="btn btn-brand text-sm">Gọi {SITE.hotline}</a>
        </div>
      </aside>

      <div className="flex min-w-0 flex-[999_1_640px] flex-col gap-4">
        <label className="flex h-[46px] items-center gap-2 rounded-xl border border-line-2 bg-white px-3.5 text-muted md:hidden">
          <Icon name="search" size={18} /><span className="sr-only">Tìm khóa học</span>
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Tìm khóa học" className="w-full bg-transparent text-[15px] text-ink outline-none" />
        </label>
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex flex-wrap items-center gap-2">
            <button type="button" onClick={() => setSheet(true)} className="btn btn-outline text-sm md:hidden"><Icon name="filter" size={18} />{selected.length ? `Bộ lọc (${selected.length})` : 'Bộ lọc'}</button>
            <span className="mr-1 text-sm text-muted" aria-live="polite">Hiển thị <strong className="text-ink">{list.length}</strong> khóa học</span>
            {selected.map((f) => (
              <button key={f} type="button" onClick={() => toggle(f)} aria-label={`Bỏ lọc ${f}`} className="flex h-[34px] items-center gap-1.5 whitespace-nowrap rounded-full bg-brand-100 pl-3 pr-2.5 text-[13px] font-semibold text-brand-700">{f}<Icon name="close" size={14} strokeWidth={2.4} /></button>
            ))}
          </div>
          <label className="flex h-11 items-center gap-2 rounded-xl border border-line-2 bg-white px-3 text-sm text-muted">Sắp xếp
            <select value={sort} onChange={(e) => setSort(e.target.value as (typeof SORTS)[number])} className="bg-transparent font-semibold text-ink outline-none">
              {SORTS.map((s) => <option key={s}>{s}</option>)}
            </select>
          </label>
        </div>
        <div className="grid grid-cols-[repeat(auto-fill,minmax(290px,1fr))] gap-4 md:gap-5">
          {list.map((c) => <CourseCard key={c.slug} course={c} />)}
          {list.length === 0 && (
            <div className="col-span-full flex flex-col items-center gap-3 rounded-[18px] border border-dashed border-[#CBD8CF] bg-white px-5 py-10 text-center">
              <strong className="text-[17px]">Chưa có khóa học phù hợp bộ lọc</strong>
              <span className="text-sm text-muted">Thử bỏ bớt bộ lọc hoặc gọi {SITE.hotline} để được tư vấn.</span>
              <button type="button" onClick={() => { setSelected([]); setQ(''); }} className="btn btn-outline text-sm">Xóa tất cả bộ lọc</button>
            </div>
          )}
        </div>
      </div>

      {sheet && (
        <div className="fixed inset-0 z-50 flex flex-col justify-end bg-[rgba(20,24,22,0.45)] md:hidden">
          <button type="button" aria-label="Đóng bộ lọc" onClick={() => setSheet(false)} className="flex-1" />
          <div role="dialog" aria-modal="true" aria-label="Bộ lọc khóa học" className="flex flex-col gap-1.5 rounded-t-[22px] bg-white px-4 pb-4 pt-2.5">
            <span className="mx-auto h-1 w-10 rounded bg-[#D5DDD8]" aria-hidden />
            <div className="flex items-center justify-between py-1.5">
              <strong className="text-lg text-brand-700">Loại khóa học</strong>
              <button type="button" onClick={() => setSelected([])} className="h-10 px-2 text-sm font-bold text-brand-600">Xóa lọc</button>
            </div>
            {filterList}
            <button type="button" onClick={() => setSheet(false)} className="btn btn-brand btn-lg mt-2">Xem {list.length} khóa học</button>
          </div>
        </div>
      )}
    </div>
  );
}
