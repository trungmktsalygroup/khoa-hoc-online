'use client';
import { useSearchParams } from 'next/navigation';
import { useEffect } from 'react';
import { PACKAGES } from '@/data/packages';
import { PackageCard } from './PackageCard';

/** Lưới 4 gói theo mô hình. ?goi=<slug> sẽ cuộn tới và làm nổi bật gói tương ứng. */
export function PackageGrid() {
  const goi = useSearchParams().get('goi');
  useEffect(() => {
    if (goi) setTimeout(() => document.getElementById(`goi-${goi}`)?.scrollIntoView({ behavior: 'smooth', block: 'center' }), 150);
  }, [goi]);
  return (
    <div className="grid items-stretch gap-6 md:grid-cols-2 xl:grid-cols-4">
      {PACKAGES.map((p, i) => <PackageCard key={p.slug} p={p} highlight={goi === p.slug} last={i === PACKAGES.length - 1} />)}
    </div>
  );
}
