'use client';
import Image from 'next/image';
import Link from 'next/link';
import type { ModelPackage, Perk } from '@/data/packages';
import { DEAL } from '@/data/packages';
import { vnd } from '@/lib/format';
import { CheckCircle, Icon } from '@/components/ui/Icon';
import { useCart } from '@/components/shared/CartProvider';

function PerkList({ items }: { items: Perk[] }) {
  return (
    <ul className="flex flex-col gap-2 text-[14.5px]">
      {items.map((g) => (
        <li key={g.text} className="flex gap-2">
          <CheckCircle size={16} bg={g.special ? '#F29546' : '#0D824B'} />
          <span className="flex-1">{g.text}{g.special && <span className="ml-1.5 whitespace-nowrap rounded bg-accent-100 px-1.5 py-0.5 text-[11px] font-bold text-accent-700">Nổi bật</span>}</span>
        </li>
      ))}
    </ul>
  );
}

function CartButton({ p, size = 'lg', tone }: { p: ModelPackage; size?: 'lg' | 'md'; tone?: string }) {
  const { add, has } = useCart();
  const cls = size === 'lg' ? 'btn btn-lg w-full rounded-full' : 'btn w-full rounded-full';
  const color = tone ?? (p.popular ? 'btn-accent shadow-[0_10px_22px_rgba(242,149,70,0.35)]' : 'btn-brand shadow-[0_10px_22px_rgba(13,130,75,0.25)]');
  return has(p.slug)
    ? <Link href="/thanh-toan" className={`${cls} border-2 border-brand-600 bg-white text-brand-600`}><Icon name="check" size={18} />Đã thêm – Thanh toán</Link>
    : <button type="button" onClick={() => add(p.slug)} className={`${cls} ${color}`}><Icon name="cart" size={18} />Chọn gói này<Icon name="arrowRight" size={16} strokeWidth={2.4} /></button>;
}

function Price({ p }: { p: ModelPackage }) {
  const warm = p.popular;
  return (
    <div className={`flex flex-col gap-1 rounded-2xl p-4 ${warm ? 'bg-[#FFF3E6]' : 'bg-[#EEF7F1]'}`}>
      <span className={`text-[12.5px] font-extrabold uppercase tracking-wide ${p.dealPrice ? 'text-accent-600' : 'text-brand-700'}`}>{p.dealPrice ? `Giá mở bán ${DEAL.label}` : 'Học phí trọn gói'}</span>
      <strong className={`text-[30px] font-extrabold leading-tight tracking-tight ${warm ? 'text-accent-600' : 'text-brand-700'}`}>{vnd(p.dealPrice ?? p.price)}</strong>
      {p.dealPrice && <s className="text-[14px] font-semibold text-muted">{vnd(p.price)}</s>}
      {p.dealGift && (
        <span className="my-1 flex items-center gap-2 self-start rounded-xl bg-accent-500 px-3 py-1.5 text-[12.5px] font-bold leading-tight text-white">
          <Icon name="gift" size={18} className="shrink-0" /><span>{p.dealGift}<span className="block font-semibold text-white/90">({DEAL.label})</span></span>
        </span>
      )}
      <span className="text-[12.5px] text-muted">Học online trọn đời · có trợ giảng hỗ trợ</span>
    </div>
  );
}

/** Thẻ gói khóa học theo mô hình quán – theo mẫu thiết kế anh Sang */
export function PackageCard({ p, highlight = false, last = false }: { p: ModelPackage; highlight?: boolean; last?: boolean }) {
  const warm = p.popular;
  const accentText = warm ? 'text-accent-600' : 'text-brand-600';
  return (
    <article id={`goi-${p.slug}`}
      className={`relative flex scroll-mt-28 flex-col overflow-hidden rounded-[22px] bg-white transition-[box-shadow,translate] duration-300 hover:-translate-y-1 ${highlight ? 'shadow-[0_0_0_3px_#F29546,0_24px_50px_rgba(20,67,42,0.16)]' : warm ? 'shadow-[0_0_0_2px_rgba(242,149,70,0.55),0_22px_48px_rgba(242,149,70,0.18)]' : 'shadow-[0_14px_40px_rgba(20,67,42,0.10)]'}`}>
      <div className="relative aspect-[16/10]">
        <Image src={p.image} alt={`Mô hình ${p.short}`} fill sizes="(max-width: 768px) 100vw, 25vw" className="object-cover" />
                {p.popular && (
          <span className="absolute right-0 top-0 z-10 flex items-center gap-1.5 rounded-bl-2xl bg-accent-500 px-3.5 py-1.5 text-[12px] font-extrabold text-white shadow">
            Được chọn nhiều nhất <Icon name="crown" size={14} />
          </span>
        )}
      </div>

      <div className="flex flex-1 flex-col gap-4 p-5">
        <div className="flex flex-col gap-1.5">
          <h2 className="flex items-start justify-between gap-3 text-[19px] font-extrabold capitalize leading-snug text-brand-700">
            <Link href={`/khoa-hoc/${p.slug}`} className="hover:underline">{p.name}</Link>
            <Icon name={p.cardIcon} size={24} className={`mt-0.5 shrink-0 ${p.cardIcon === 'leaf' ? 'text-brand-600' : p.cardIcon === 'crown' ? 'text-accent-500' : warm ? 'text-accent-500' : 'text-brand-600'}`} />
          </h2>
          <p className="text-[14.5px] font-bold leading-[21px] text-accent-600">{p.tagline}</p>
          <p className="text-[14px] leading-[22px] text-ink-2">{p.focus}</p>
        </div>
        <Price p={p} />
        <div className="flex flex-col gap-2">
          <span className={`text-[13.5px] font-extrabold uppercase tracking-wide ${warm ? 'text-accent-600' : 'text-brand-700'}`}>Học xong, bạn làm được</span>
          <ul className="flex flex-col gap-2 text-[14px] leading-[21px]">
            {p.outcomes.slice(0, 4).map((o) => <li key={o} className="flex gap-2.5"><CheckCircle size={17} bg={warm ? '#F29546' : '#0D824B'} />{o}</li>)}
          </ul>
        </div>
        <div className="flex flex-wrap gap-1.5 text-[12px] font-semibold">
          <span className="flex items-center gap-1 rounded-full border border-line bg-white px-2.5 py-1 text-brand-700"><Icon name="team" size={13} />{p.topics.length} khóa học</span>
          <span className="flex items-center gap-1 rounded-full border border-line bg-white px-2.5 py-1 text-brand-700"><Icon name="star" size={13} className="text-accent-500" />{p.benefits.length} quyền lợi</span>
          {p.gifts.length > 0 && <span className="flex items-center gap-1 rounded-full bg-accent-100 px-2.5 py-1 text-accent-700"><Icon name="gift" size={13} />{p.gifts.length} quà tặng</span>}
        </div>
        <div className="mt-auto flex flex-col gap-2 pt-1">
          <CartButton p={p} tone={last && !warm ? 'bg-brand-700 text-white shadow-[0_10px_22px_rgba(10,125,69,0.3)]' : undefined} />
          <Link href={`/khoa-hoc/${p.slug}`} className={`flex h-10 items-center justify-center gap-1.5 text-[14px] font-bold hover:underline ${accentText}`}>Xem chi tiết khóa học <Icon name="arrowRight" size={15} /></Link>
        </div>
      </div>
    </article>
  );
}
