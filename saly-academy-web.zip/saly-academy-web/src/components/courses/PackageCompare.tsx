import { Fragment } from 'react';
import { COMPARE, PACKAGES, DEAL } from '@/data/packages';
import { vnd } from '@/lib/format';
import { Icon } from '@/components/ui/Icon';

function Cell({ v }: { v: boolean | string }) {
  if (v === true) return <span className="inline-flex size-6 items-center justify-center rounded-full bg-brand-600 text-white" aria-label="Có"><Icon name="check" size={14} strokeWidth={3} /></span>;
  if (v === false) return <span className="text-line-2" aria-label="Không">—</span>;
  return <span className="text-[13px] font-semibold text-accent-700">{v}</span>;
}

/** Bảng so sánh 4 gói theo mô hình */
export function PackageCompare() {
  return (
    <section className="flex flex-col gap-5" aria-labelledby="so-sanh">
      <div className="flex flex-col gap-1.5">
        <span className="eyebrow">SO SÁNH CÁC GÓI</span>
        <h2 id="so-sanh" className="scroll-mt-28 text-[22px] font-extrabold text-brand-700 md:text-[26px]">Gói nào có gì – xem một lần là rõ</h2>
      </div>
      <div className="overflow-x-auto rounded-[20px] border border-line bg-white">
        <table className="w-full min-w-[760px] border-collapse text-left text-[14px]">
          <thead>
            <tr className="bg-brand-700 text-white">
              <th className="sticky left-0 z-10 w-[26%] bg-brand-700 px-4 py-3.5 font-bold">Mô hình</th>
              {PACKAGES.map((p) => <th key={p.slug} className="px-3 py-3.5 text-center"><span className="block text-[15px] font-extrabold">{p.short}</span><span className="text-[12px] font-medium text-white/80">{p.tagline}</span></th>)}
            </tr>
          </thead>
          <tbody>
            <tr className="border-b border-line bg-mint/60">
              <th className="sticky left-0 z-10 bg-[#EEF5F0] px-4 py-3 font-bold">Học phí</th>
              {PACKAGES.map((p) => (
                <td key={p.slug} className="px-3 py-3 text-center">
                  <strong className="block text-[16px] text-accent-600">{vnd(p.dealPrice ?? p.price)}</strong>
                  {p.dealPrice ? <span className="text-[11.5px] text-muted">mở bán {DEAL.label} · <s>{vnd(p.price)}</s></span> : p.dealGift ? <span className="text-[11.5px] font-semibold text-accent-700">🎁 {p.dealGift}</span> : null}
                </td>
              ))}
            </tr>
            {COMPARE.map((g) => (
              <Fragment key={g.group}>
                <tr className="bg-[#FFF4E8]"><th colSpan={5} className="px-4 py-2.5 text-[13px] font-extrabold uppercase tracking-wide text-accent-700">{g.group}</th></tr>
                {g.rows.map((r) => (
                  <tr key={g.group + r.label} className="border-b border-line last:border-b-0">
                    <th className="sticky left-0 z-10 bg-white px-4 py-2.5 font-medium text-ink-2">{r.label}</th>
                    {r.values.map((v, i) => <td key={i} className="px-3 py-2.5 text-center"><Cell v={v} /></td>)}
                  </tr>
                ))}
              </Fragment>
            ))}
          </tbody>
        </table>
      </div>
      <p className="text-[12.5px] text-muted">Vuốt ngang để xem đủ 4 gói trên điện thoại.</p>
    </section>
  );
}
