'use client';
import type { ReactNode } from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { useState } from 'react';
import type { ModelPackage, Perk } from '@/data/packages';
import { DEAL, PACKAGES, TOPIC_INFO, topicKey } from '@/data/packages';
import { LESSONS } from '@/data/lessons';
import { INTRO_VIDEO, TESTIMONIALS } from '@/data/home';
import { SITE } from '@/data/site';
import { vnd } from '@/lib/format';
import { Faq } from '@/components/home/Faq';
import { YouTubeLite } from '@/components/shared/YouTubeLite';
import { Breadcrumb } from '@/components/shared/SectionHead';
import { useCart } from '@/components/shared/CartProvider';
import { CheckCircle, Icon } from '@/components/ui/Icon';

const H2 = 'text-[22px] font-extrabold leading-tight text-brand-700 md:text-[28px]';

function BuyButton({ p, className = '' }: { p: ModelPackage; className?: string }) {
  const { add, has } = useCart();
  return has(p.slug)
    ? <Link href="/thanh-toan" className={`btn btn-lg border-2 border-brand-600 bg-white text-brand-600 ${className}`}><Icon name="check" size={18} />Đã thêm – Thanh toán</Link>
    : <button type="button" onClick={() => add(p.slug)} className={`btn btn-accent btn-lg ${className}`}><Icon name="cart" size={18} />Đăng ký gói này</button>;
}

function PriceLine({ p, big = false }: { p: ModelPackage; big?: boolean }) {
  return (
    <div className="flex flex-col leading-tight">
      <div className="flex flex-wrap items-baseline gap-x-2">
        <strong className={`${big ? 'text-[32px] md:text-[38px]' : 'text-[22px]'} font-extrabold tracking-tight text-accent-600`}>{vnd(p.dealPrice ?? p.price)}</strong>
        {p.dealPrice && <s className={`${big ? 'text-[16px]' : 'text-[13px]'} text-muted`}>{vnd(p.price)}</s>}
      </div>
      {p.dealPrice && <span className="text-[12.5px] font-semibold text-accent-700">Giá mở bán {DEAL.label}</span>}
      {p.dealGift && <span className="text-[12.5px] font-semibold text-accent-700">🎁 {p.dealGift} ({DEAL.label})</span>}
    </div>
  );
}

function Perks({ title, icon, items, empty }: { title: string; icon: ReactNode; items: Perk[]; empty?: string }) {
  return (
    <div className="card flex flex-col gap-4 rounded-[22px] p-5 md:p-7">
      <h3 className="flex items-center gap-2.5 text-[19px] font-extrabold text-brand-700">{icon}{title}</h3>
      {items.length ? (
        <ul className="flex flex-col gap-2.5 text-[15px]">
          {items.map((g) => (
            <li key={g.text} className="flex gap-2.5">
              <CheckCircle size={18} bg={g.special ? '#F29546' : '#0D824B'} />
              <span>{g.text}{g.special && <span className="ml-1.5 whitespace-nowrap rounded bg-accent-100 px-1.5 py-0.5 text-[11px] font-bold text-accent-700">Nổi bật</span>}</span>
            </li>
          ))}
        </ul>
      ) : <p className="text-[14.5px] text-muted">{empty}</p>}
    </div>
  );
}

export function PackageDetail({ p }: { p: ModelPackage }) {
  const [open, setOpen] = useState(0);
  const others = PACKAGES.filter((x) => x.slug !== p.slug);
  const stories = TESTIMONIALS.slice(0, 2);

  return (
    <>
      {/* ───── Phần đầu ───── */}
      <section className="bg-mint">
        <div className="container-site flex flex-col gap-6 pb-12 pt-6 md:pb-16 md:pt-8">
          <Breadcrumb items={[{ label: 'Trang chủ', href: '/' }, { label: 'Khóa học', href: '/khoa-hoc' }, { label: p.short }]} />
          <div className="grid items-start gap-8 lg:grid-cols-[1.05fr_0.95fr] lg:gap-12">
            <div className="flex flex-col gap-5">
              <div className="flex flex-wrap gap-2">
                <span className="rounded-full bg-brand-600 px-3 py-1 text-[12.5px] font-bold text-white">{p.tagline}</span>
                {p.popular && <span className="rounded-full bg-accent-500 px-3 py-1 text-[12.5px] font-bold text-white">Được chọn nhiều nhất</span>}
              </div>
              <h1 className="text-[28px] font-extrabold leading-[1.2] tracking-[-0.02em] text-brand-700 md:text-[40px]" style={{ textWrap: 'balance' }}>{p.name}</h1>
              <p className="lead max-w-[560px]">{p.focus}</p>
              <ul className="grid gap-2 text-[14.5px] sm:grid-cols-2">
                {[`${p.topics.length} chuyên đề trong gói`, 'Học online trọn đời', 'Hỗ trợ 1-1 từ đội trợ giảng', 'Lộ trình đóng gói sẵn, không cần tự ghép khóa'].map((t) => <li key={t} className="flex gap-2"><CheckCircle size={17} />{t}</li>)}
              </ul>
              <div className="flex flex-col gap-4 rounded-[20px] bg-white p-5 shadow-[0_16px_40px_rgba(20,67,42,0.08)] sm:flex-row sm:items-center sm:justify-between">
                <PriceLine p={p} big />
                <div className="flex flex-col gap-2 sm:w-[240px]">
                  <BuyButton p={p} className="w-full" />
                  <Link href="/dang-nhap?che-do=dang-ky" className="text-center text-[13.5px] font-bold text-brand-600 hover:underline">Học thử miễn phí trước</Link>
                </div>
              </div>
            </div>
            <div className="flex flex-col gap-3">
              <div className="relative overflow-hidden rounded-[22px]">
                <Image src={p.image} alt={`Mô hình ${p.short} của học viên SaLy Academy`} width={560} height={420} priority sizes="(max-width: 1024px) 100vw, 560px" className="aspect-[4/3] w-full object-cover" />
                <span className="absolute bottom-3 left-3 rounded-full bg-white/95 px-3 py-1 text-[12.5px] font-bold text-brand-700">Quán của học viên SaLy</span>
              </div>
              <YouTubeLite {...INTRO_VIDEO} />
            </div>
          </div>
        </div>
      </section>

      <div className="container-site flex flex-col gap-16 py-14 md:gap-20 md:py-20">
        {/* ───── Học xong làm được ───── */}
        <section className="flex flex-col gap-6">
          <div className="flex flex-col gap-2"><span className="eyebrow">KẾT QUẢ SAU KHÓA HỌC</span><h2 className={H2}>Học xong, bạn làm được</h2></div>
          <ol className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {p.outcomes.map((o, i) => (
              <li key={o} className="card flex gap-3.5 rounded-[18px] p-4 md:p-5">
                <span className="flex size-9 shrink-0 items-center justify-center rounded-full bg-accent-500 text-[15px] font-extrabold text-white">{i + 1}</span>
                <span className="pt-1 text-[15px] font-semibold leading-[23px] text-ink">{o}</span>
              </li>
            ))}
          </ol>
        </section>

        {/* ───── Chương trình học ───── */}
        <section className="grid gap-8 lg:grid-cols-[1.2fr_0.8fr] lg:gap-12">
          <div className="flex flex-col gap-6">
            <div className="flex flex-col gap-2"><span className="eyebrow">CHƯƠNG TRÌNH HỌC</span><h2 className={H2}>{p.topics.length} chuyên đề trong gói</h2></div>
            <div className="flex flex-col gap-2.5">
              {p.topics.map((t, i) => {
                const isOpen = open === i;
                const info = TOPIC_INFO[topicKey(t)];
                return (
                  <div key={t} className={`overflow-hidden rounded-2xl border bg-white ${isOpen ? 'border-brand-600' : 'border-line'}`}>
                    <h3>
                      <button type="button" onClick={() => setOpen(isOpen ? -1 : i)} aria-expanded={isOpen}
                        className="flex min-h-[60px] w-full items-center gap-3 px-4 py-3 text-left md:px-5">
                        <span className="flex size-8 shrink-0 items-center justify-center rounded-lg bg-brand-100 text-[13px] font-extrabold text-brand-600">{String(i + 1).padStart(2, '0')}</span>
                        <span className="flex-1 text-[16px] font-bold text-ink">{t}</span>
                        <Icon name="chevronDown" size={18} className={`shrink-0 text-muted transition-transform ${isOpen ? 'rotate-180' : ''}`} />
                      </button>
                    </h3>
                    {isOpen && (
                      <div className="flex flex-col gap-3 px-4 pb-4 md:px-5">
                        {info && <p className="text-[14.5px] leading-6 text-ink-2">{info}</p>}
                        {topicKey(t) === 'Trà trái cây' && (
                          <ul className="flex flex-col divide-y divide-line rounded-xl border border-line">
                            {LESSONS.map((l, k) => (
                              <li key={l.title} className="flex items-center gap-3 px-3 py-2.5 text-[14px]">
                                <Icon name="play" size={14} className="shrink-0 text-brand-600" />
                                <span className="line-clamp-1 flex-1">{k + 1}. {l.title}</span>
                                {l.tag === 'FREE'
                                  ? <Link href="/hoc/tra-trai-cay" className="shrink-0 rounded bg-brand-100 px-2 py-0.5 text-[11.5px] font-bold text-brand-600">Học thử</Link>
                                  : <span className="shrink-0 text-[12.5px] text-muted">{l.duration}</span>}
                              </li>
                            ))}
                            <li className="px-3 py-2.5 text-[13px] text-muted">… và các bài học khác trong chuyên đề</li>
                          </ul>
                        )}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
          <aside className="flex flex-col gap-4 lg:sticky lg:top-24 lg:self-start">
            <div className="card flex flex-col gap-3 rounded-[22px] p-5">
              <span className="text-[13px] font-bold uppercase tracking-wide text-muted">Phù hợp với bạn nếu</span>
              <ul className="flex flex-col gap-2 text-[14.5px]">
                {p.fitFor.map((f) => <li key={f} className="flex gap-2"><CheckCircle size={17} />{f}</li>)}
              </ul>
              {p.examples && <p className="rounded-xl bg-mint px-3.5 py-2.5 text-[13.5px] text-ink-2">Quán tham khảo: <strong>{p.examples}</strong></p>}
            </div>
            <div className="card flex flex-col gap-3 rounded-[22px] p-5">
              <PriceLine p={p} />
              <BuyButton p={p} className="w-full" />
              <a href={SITE.hotlineTel} className="flex items-center justify-center gap-2 text-[13.5px] font-bold text-brand-600"><Icon name="phone" size={16} />Tư vấn {SITE.hotline}</a>
            </div>
          </aside>
        </section>

        {/* ───── Quyền lợi & quà tặng ───── */}
        <section className="flex flex-col gap-6">
          <div className="flex flex-col gap-2"><span className="eyebrow">ĐI KÈM KHÓA HỌC</span><h2 className={H2}>Quyền lợi và quà tặng</h2></div>
          <div className="grid gap-5 lg:grid-cols-2">
            <Perks title="Quyền lợi học viên" icon={<Icon name="star" size={20} className="text-accent-500" />} items={p.benefits} />
            <Perks title="Quà tặng kèm" icon={<span aria-hidden>🎁</span>} items={p.gifts} empty={p.dealGift ? `${p.dealGift} (${DEAL.label}).` : 'Đang cập nhật.'} />
          </div>
        </section>

        {/* ───── Giảng viên ───── */}
        <section className="bg-brand-h grid items-end overflow-hidden rounded-[28px] text-white md:grid-cols-[0.7fr_1.3fr]">
          <Image src="/images/ly-pham-tach-nen-1.png" alt="Giảng viên Ly Phạm" width={760} height={1045} sizes="(max-width: 768px) 60vw, 320px" className="mx-auto mt-6 h-auto w-[60%] md:w-[85%]" />
          <div className="flex flex-col gap-3.5 p-6 md:p-10">
            <span className="eyebrow" style={{ color: '#F9E7A6' }}>GIẢNG VIÊN</span>
            <h2 className="text-[24px] font-extrabold leading-tight md:text-[30px]">Ly Phạm – người đã tự mở quán từ năm 2017</h2>
            <p className="text-[15px] leading-6 text-[#E3F1E8]">Hơn {SITE.stats.years.replace('+', '')} năm pha chế và kinh doanh F&amp;B, chủ chuỗi Lục Coffee &amp; Tea, đã đào tạo {SITE.stats.students} học viên. Mỗi bài học là kinh nghiệm thật từ quán thật.</p>
            <Link href="/author/ly-pham" className="btn self-start bg-white text-brand-600">Tìm hiểu về Cô Ly <Icon name="arrowRight" size={16} /></Link>
          </div>
        </section>

        {/* ───── Học viên ───── */}
        <section className="flex flex-col gap-6">
          <div className="flex flex-col gap-2"><span className="eyebrow">HỌC VIÊN ĐÃ MỞ QUÁN</span><h2 className={H2}>Họ đã làm được, bạn cũng vậy</h2></div>
          <div className="grid gap-5 md:grid-cols-2">
            {stories.map((t) => (
              <figure key={t.name} className="card flex flex-col overflow-hidden rounded-[22px]">
                <div className="relative aspect-[16/9]"><Image src={t.photo} alt={`Quán ${t.store}`} fill sizes="(max-width: 768px) 100vw, 50vw" className="object-cover" /></div>
                <div className="flex flex-col gap-3 p-5">
                  <blockquote className="text-[15px] leading-6 text-ink-2">“{t.quote}”</blockquote>
                  <figcaption className="flex items-center gap-3">
                    <Image src={t.avatar} alt="" width={44} height={44} className="size-11 rounded-full object-cover" />
                    <span className="flex flex-col leading-tight"><strong className="text-brand-700">{t.name} · {t.cohort}</strong><span className="text-[13px] text-muted">{t.store} · {t.place}</span></span>
                    <strong className="ml-auto text-right text-[15px] text-accent-600">{t.stats[0][0]}<span className="block text-[11.5px] font-normal text-muted">{t.stats[0][1]}</span></strong>
                  </figcaption>
                </div>
              </figure>
            ))}
          </div>
        </section>

        {/* ───── Câu hỏi ───── */}
        <section className="mx-auto flex w-full max-w-[880px] flex-col gap-6">
          <h2 className={`${H2} text-center`}>Câu hỏi thường gặp</h2>
          <Faq />
        </section>

        {/* ───── Gói khác ───── */}
        <section className="flex flex-col gap-6">
          <div className="flex flex-wrap items-end justify-between gap-3">
            <div className="flex flex-col gap-2"><span className="eyebrow">MÔ HÌNH KHÁC</span><h2 className={H2}>Hình dung quán khác? Xem mô hình khác</h2></div>
            <Link href="/khoa-hoc#so-sanh" className="flex items-center gap-1.5 py-2 text-[15px] font-bold text-brand-600">So sánh tất cả các gói <Icon name="arrowRight" size={16} /></Link>
          </div>
          <div className="grid gap-4 sm:grid-cols-3">
            {others.map((o) => (
              <Link key={o.slug} href={`/khoa-hoc/${o.slug}`} className="group card flex flex-col overflow-hidden rounded-[18px]">
                <div className="relative aspect-[16/9] overflow-hidden"><Image src={o.image} alt="" fill sizes="33vw" className="object-cover transition-transform duration-500 group-hover:scale-105" /></div>
                <div className="flex flex-col gap-1 p-4">
                  <span className="text-[12.5px] font-bold text-accent-600">{o.tagline}</span>
                  <strong className="text-[15.5px] leading-snug text-ink group-hover:text-brand-600">{o.name}</strong>
                  <span className="text-[14px] font-bold text-brand-600">{vnd(o.dealPrice ?? o.price)}</span>
                </div>
              </Link>
            ))}
          </div>
        </section>
      </div>

      {/* Thanh đăng ký cố định (điện thoại) */}
      <div className="mobile-cta fixed inset-x-0 bottom-0 z-30 flex items-center gap-3 border-t border-line bg-white px-4 pb-3.5 pt-2.5 shadow-[0_-6px_20px_rgba(20,67,42,0.08)] lg:hidden">
        <div className="flex flex-col leading-tight">
          <strong className="text-[18px] font-extrabold text-accent-600">{vnd(p.dealPrice ?? p.price)}</strong>
          <span className="text-[11.5px] text-muted">{p.short}</span>
        </div>
        <BuyButton p={p} className="ml-auto flex-1" />
      </div>
    </>
  );
}
