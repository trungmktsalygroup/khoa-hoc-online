'use client';
import { useState } from 'react';
import { Icon } from '@/components/ui/Icon';
import { vnd } from '@/lib/format';

const num = (v: string) => { const n = parseInt(v.replace(/\D/g, ''), 10); return Number.isNaN(n) ? 0 : n; };

export function CostCalculator() {
  const [ing, setIng] = useState('');
  const [pack, setPack] = useState('');
  const [price, setPrice] = useState('');
  const cost = num(ing) + num(pack);
  const p = num(price);
  const ready = cost > 0 && p > 0;
  const pct = ready ? Math.round((cost / p) * 100) : 0;

  const field = (id: string, label: string, value: string, set: (v: string) => void, ph: string) => (
    <div className="flex flex-col gap-1.5">
      <label htmlFor={id} className="text-[13px] font-semibold text-[#E3F1E8]">{label}</label>
      <div className="flex h-[46px] items-center rounded-xl bg-white px-3">
        <input id={id} inputMode="numeric" value={value} onChange={(e) => set(e.target.value)} placeholder={ph} className="min-w-0 flex-1 bg-transparent text-base font-semibold text-ink outline-none" />
        <span className="text-sm font-semibold text-muted">đ</span>
      </div>
    </div>
  );

  return (
    <section id="tinh-gia-von" aria-labelledby="calc-title" className="bg-brand-corner flex flex-col flex-wrap gap-4 rounded-[20px] p-[18px] text-white md:flex-row md:gap-8 md:p-7">
      <div className="flex min-w-0 flex-[1_1_280px] flex-col gap-3.5">
        <span className="self-start rounded-full bg-white/16 px-2.5 py-1 text-xs font-extrabold tracking-wider">DÙNG THỬ NGAY</span>
        <h2 id="calc-title" className="text-[21px] font-extrabold leading-tight md:text-[26px]">Tính nhanh giá vốn 1 ly</h2>
        <p className="text-sm leading-[22px] text-[#E3F1E8]">Bản rút gọn của công cụ Tính cost đồ uống. Nhập số liệu quán bạn để xem lãi gộp mỗi ly.</p>
        <div className="grid gap-3 md:grid-cols-3">
          {field('ing', 'Nguyên liệu / ly', ing, setIng, 'Ví dụ: 12000')}
          {field('pack', 'Ly, nắp, ống hút', pack, setPack, 'Ví dụ: 2500')}
          {field('price', 'Giá bán', price, setPrice, 'Ví dụ: 35000')}
        </div>
      </div>
      <div className="flex min-w-0 flex-[1_1_240px] flex-col gap-3 rounded-2xl bg-white p-[18px] text-ink md:max-w-[360px]" aria-live="polite">
        <div className="flex justify-between text-sm"><span className="text-muted">Giá vốn / ly</span><strong>{cost > 0 ? vnd(cost) : '—'}</strong></div>
        <div className="flex justify-between text-sm"><span className="text-muted">Lãi gộp / ly</span><strong className="text-lg text-brand-600">{ready ? vnd(p - cost) : '—'}</strong></div>
        <div className="flex flex-col gap-1.5">
          <div className="flex justify-between text-sm"><span className="text-muted">Tỷ lệ giá vốn trên giá bán</span><strong>{ready ? `${pct}%` : '—'}</strong></div>
          <div className="h-2 overflow-hidden rounded bg-[#ECEFEC]"><div className="h-full" style={{ width: `${Math.min(pct, 100)}%`, background: pct > 40 ? '#E5761F' : '#0D824B' }} /></div>
        </div>
        <a href="#" className="btn btn-accent mt-auto text-sm">Mở bản đầy đủ <Icon name="arrowRight" size={16} strokeWidth={2.4} /></a>
      </div>
    </section>
  );
}
