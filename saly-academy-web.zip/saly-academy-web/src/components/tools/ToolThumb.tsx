import type { ReactNode } from 'react';
import type { ToolIcon } from '@/data/tools';

const Bar = ({ w, c = '#D5DDD8', h = 8 }: { w: string; c?: string; h?: number }) => <span className="block rounded" style={{ width: w, height: h, background: c }} />;
const L = ({ t, c = '#0A7D45' }: { t: string; c?: string }) => <span className="text-[11px] font-extrabold" style={{ color: c }}>{t}</span>;

/** Minh họa màn hình app thu nhỏ – thay bằng ảnh chụp app thật khi có */
export function ToolThumb({ icon }: { icon: ToolIcon }) {
  let inner: ReactNode = null;
  if (icon === 'map') inner = (<><L t="Bạn có bao nhiêu vốn?" /><span className="flex h-6 items-center rounded-md border border-line-2 px-2 text-[10px] text-muted">Nhập số vốn</span><div className="grid grid-cols-4 gap-1.5">{['#0D824B', '#0C864A', '#F29546', '#0A7D45'].map((c) => <div key={c} className="flex h-10 flex-col gap-1 rounded-md p-1.5" style={{ background: c }}><Bar w="70%" c="rgba(255,255,255,.8)" h={5} /><Bar w="45%" c="rgba(255,255,255,.6)" h={5} /></div>)}</div></>);
  if (icon === 'calc') inner = (<><L t="Giá vốn 1 ly" />{['22%', '14%', '18%'].map((w) => <div key={w} className="flex items-center gap-2"><Bar w="38%" c="#E4ECE6" h={7} /><span className="flex-1" /><Bar w={w} c="#F29546" h={7} /></div>)}<div className="mt-0.5 flex items-center justify-between border-t border-dashed border-line-2 pt-2"><L t="Lãi gộp" c="#0D824B" /><Bar w="30%" c="#0D824B" h={9} /></div></>);
  if (icon === 'chart') inner = (<><L t="Điểm hòa vốn" /><svg viewBox="0 0 200 70" className="min-h-0 w-full flex-1" fill="none" aria-hidden><path d="M0 60 L200 20" stroke="#F29546" strokeWidth="3" strokeLinecap="round" /><path d="M0 40 L200 40" stroke="#0D824B" strokeWidth="3" strokeDasharray="6 5" strokeLinecap="round" /><circle cx="100" cy="40" r="6" fill="#0A7D45" /></svg></>);
  if (icon === 'wallet') inner = (<><L t="Hạng mục setup quán" />{[['#0D824B', '46%'], ['#0D824B', '34%'], ['#DCE5DF', '40%'], ['#DCE5DF', '28%']].map(([c, w], k) => <div key={k} className="flex items-center gap-2"><span className="size-3 shrink-0 rounded-[3px]" style={{ background: c }} /><Bar w={w} c="#E4ECE6" h={7} /><span className="flex-1" /><Bar w="16%" c="#C9621A" h={7} /></div>)}</>);
  if (icon === 'scale') inner = (<><div className="flex items-center justify-between"><L t="1 ly" /><svg width="22" height="12" viewBox="0 0 22 12" fill="none" aria-hidden><path d="M1 6h19M15 1l5 5-5 5" stroke="#F29546" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" /></svg><L t="Mẻ lớn" c="#0D824B" /></div>{[['16%', '34%'], ['12%', '28%'], ['20%', '40%']].map(([a, b]) => <div key={a} className="flex items-center gap-2.5"><Bar w={a} c="#E4ECE6" h={7} /><span className="flex-1" /><Bar w={b} c="#0D824B" h={7} /></div>)}</>);
  if (icon === 'cal') inner = (<><L t="Lịch đăng tuần này" /><div className="grid grid-cols-7 gap-1.5">{['#E4ECE6', '#F29546', '#E4ECE6', '#E4ECE6', '#0D824B', '#E4ECE6', '#E4ECE6', '#E4ECE6', '#E4ECE6', '#0D824B', '#E4ECE6', '#F29546', '#E4ECE6', '#E4ECE6'].map((c, k) => <span key={k} className="aspect-square rounded" style={{ background: c }} />)}</div></>);
  return (
    <div aria-hidden className="absolute inset-x-[12%] bottom-0 top-[16%] flex flex-col gap-2 overflow-hidden rounded-t-xl bg-white px-3.5 py-3 shadow-[0_8px_24px_rgba(20,67,42,0.14)]">{inner}</div>
  );
}
