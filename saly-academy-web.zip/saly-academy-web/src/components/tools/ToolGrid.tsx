'use client';
import { useState } from 'react';
import { TOOLS, TOOL_GROUPS } from '@/data/tools';
import { Icon } from '@/components/ui/Icon';
import { ToolThumb } from './ToolThumb';

export function ToolGrid() {
  const [group, setGroup] = useState(0);
  const [notified, setNotified] = useState<string[]>([]);
  const list = group === 0 ? TOOLS : TOOLS.filter((t) => t.group === TOOL_GROUPS[group]);
  return (
    <div className="flex flex-col gap-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <nav aria-label="Nhóm công cụ" className="no-scrollbar -mx-4 flex gap-2 overflow-x-auto px-4 md:mx-0 md:flex-wrap md:px-0">
          {TOOL_GROUPS.map((g, i) => <button key={g} type="button" aria-pressed={i === group} onClick={() => setGroup(i)} className="chip shrink-0">{g}</button>)}
        </nav>
        <span className="text-sm text-muted"><strong className="text-ink">{list.length}</strong> công cụ</span>
      </div>
      <div className="grid grid-cols-[repeat(auto-fill,minmax(280px,1fr))] gap-4 md:gap-5">
        {list.map((t) => {
          const asked = notified.includes(t.name);
          return (
            <article key={t.name} className="card flex flex-col overflow-hidden">
              <a href={t.href} aria-label={t.name} className="relative block aspect-video overflow-hidden" style={{ background: t.thumbBg }}>
                <ToolThumb icon={t.icon} />
                <span className={`absolute right-2.5 top-2.5 rounded-full px-2.5 py-1 text-xs font-bold shadow-sm ${t.live ? 'bg-brand-100 text-brand-600' : 'bg-white text-muted'}`}>{t.live ? 'Đang hoạt động' : 'Sắp ra mắt'}</span>
              </a>
              <div className="flex flex-1 flex-col gap-3.5 px-4 pb-4 md:px-[22px] md:pb-[22px]">
                <span className="relative -mt-10 flex size-12 items-center justify-center rounded-[14px] border-[3px] border-white text-white" style={{ background: t.tile }}><Icon name={t.icon} size={24} /></span>
                <div className="flex flex-1 flex-col gap-1.5">
                  <h3 className="text-[17px] font-extrabold leading-[26px] text-brand-700 md:text-[19px]">{t.name}</h3>
                  <p className="text-sm leading-[22px] text-ink-2">{t.desc}</p>
                </div>
                <div className="flex flex-wrap gap-1.5 text-xs">
                  <span className="rounded-[7px] bg-[#F3F0EC] px-2.5 py-1 font-semibold text-ink-2">{t.group}</span>
                  <span className="rounded-[7px] bg-accent-100 px-2.5 py-1 font-bold text-accent-700">{t.price}</span>
                  <span className="rounded-[7px] bg-[#F3F0EC] px-2.5 py-1 font-semibold text-ink-2">Web · Điện thoại</span>
                </div>
                {t.live ? (
                  <a href={t.href} className="btn btn-accent">Dùng ngay <Icon name="arrowRight" size={16} strokeWidth={2.4} /></a>
                ) : (
                  <button type="button" onClick={() => setNotified((n) => (n.includes(t.name) ? n : [...n, t.name]))} disabled={asked}
                    className={`btn border bg-white text-sm ${asked ? 'border-brand-600 text-brand-600' : 'border-line-2 text-ink'}`}>
                    <Icon name={asked ? 'check' : 'bell'} size={16} />{asked ? 'Đã đăng ký nhận tin' : 'Báo tôi khi ra mắt'}
                  </button>
                )}
              </div>
            </article>
          );
        })}
      </div>
    </div>
  );
}
