'use client';
import Image from 'next/image';
import { useState } from 'react';
import { Icon } from '@/components/ui/Icon';
import { embedBlocked } from '@/lib/embed';

/**
 * Video YouTube nhúng & phát ngay trên trang.
 * Chỉ tải trình phát khi khách bấm (trang nhẹ, nhanh hơn); bấm là phát luôn tại chỗ.
 */
export function YouTubeLite({ id, title, thumb }: { id: string; title: string; thumb: string }) {
  const [play, setPlay] = useState(false);
  const frame = 'relative aspect-video w-full overflow-hidden rounded-[24px] bg-black shadow-[0_24px_60px_rgba(20,67,42,0.22)]';

  if (play && !embedBlocked()) {
    return (
      <div className="flex flex-col gap-2">
        <div className={frame}>
          <iframe className="absolute inset-0 size-full" src={`https://www.youtube.com/embed/${id}?autoplay=1&rel=0&playsinline=1`} title={title}
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
            referrerPolicy="strict-origin-when-cross-origin" allowFullScreen />
        </div>
        <a href={`https://www.youtube.com/watch?v=${id}`} target="_blank" rel="noopener" className="self-end text-[12.5px] font-semibold text-muted hover:text-brand-600">Video không phát? Xem trên YouTube ↗</a>
      </div>
    );
  }
  return (
    <button type="button" onClick={() => (embedBlocked() ? window.open(`https://www.youtube.com/watch?v=${id}`, '_blank', 'noopener') : setPlay(true))} aria-label={`Phát video: ${title}`} className={`group block ${frame}`}>
      <Image src={thumb} alt={title} fill sizes="(max-width: 768px) 100vw, 640px" className="object-cover transition-transform duration-500 group-hover:scale-[1.02]" />
      <span className="absolute inset-0 bg-gradient-to-t from-black/45 via-transparent to-transparent" aria-hidden />
      <span className="absolute left-1/2 top-1/2 flex size-[68px] -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full bg-accent-500 text-white shadow-[0_10px_30px_rgba(242,149,70,0.55)] ring-8 ring-white/25 transition-transform group-hover:scale-105 md:size-20">
        <Icon name="play" size={30} className="translate-x-0.5" />
      </span>
      <span className="absolute bottom-3 left-3 flex items-center gap-1.5 rounded-full bg-black/60 px-3 py-1.5 text-xs font-semibold text-white"><Icon name="youtube" size={15} />Bấm để xem ngay</span>
    </button>
  );
}
