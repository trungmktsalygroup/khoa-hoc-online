'use client';
import Image from 'next/image';
import Link from 'next/link';
import { useState } from 'react';
import type { Course } from '@/data/courses';
import { discountPercent, vnd } from '@/lib/format';
import { Icon } from '@/components/ui/Icon';
import { useCart } from './CartProvider';

export function CourseCard({ course, compact = false }: { course: Course; compact?: boolean }) {
  const { add, has } = useCart();
  const [saved, setSaved] = useState(false);
  const inCart = has(course.slug);
  const off = course.price && course.oldPrice ? discountPercent(course.price, course.oldPrice) : null;
  return (
    <article className="card flex flex-col overflow-hidden">
      <div className="relative aspect-video bg-line">
        <Link href={`/hoc/${course.slug}`} aria-label={course.title}><Image src={course.image} alt={course.title} fill sizes="(max-width: 768px) 100vw, 33vw" className="object-cover" /></Link>
        {off !== null && <span className="absolute left-3 top-3 rounded-full bg-accent-500 px-2.5 py-1 text-xs font-extrabold text-white">-{off}%</span>}
        {!compact && (
          <button type="button" onClick={() => setSaved((s) => !s)} aria-pressed={saved} aria-label={saved ? 'Bỏ lưu khóa học' : 'Lưu khóa học'}
            className="absolute right-2.5 top-2.5 flex size-10 items-center justify-center rounded-full bg-white text-brand-600 shadow-md">
            <Icon name="bookmark" size={18} fill={saved ? 'currentColor' : 'none'} />
          </button>
        )}
      </div>
      <div className="flex flex-1 flex-col gap-2.5 px-4 pt-4 md:px-[18px]">
        <h3 className="text-[17px] font-bold leading-6 md:text-lg"><Link href={`/hoc/${course.slug}`}>{course.title}</Link></h3>
        {!compact && (
          <div className="flex items-center gap-2.5">
            <Image src="/images/ly-pham-tach-nen-nho.png" alt="" width={32} height={32} className="size-8 rounded-full bg-brand-100 object-cover object-top" />
            <div className="flex min-w-0 flex-col"><span className="text-[13px] font-semibold">Giảng viên Ly Phạm</span><span className="truncate text-xs text-muted">Trong {course.categories.join(', ')}</span></div>
          </div>
        )}
      </div>
      <div className="mt-3.5 flex items-end justify-between gap-2 border-t border-[#ECEFEC] px-4 py-3.5 md:px-[18px]">
        <div className="flex flex-col">
          {course.oldPrice && <s className="text-[13px] text-muted">{vnd(course.oldPrice)}</s>}
          <strong className="text-xl text-brand-600">{course.price ? vnd(course.price) : '[Giá]'}</strong>
        </div>
        {inCart ? (
          <Link href="/thanh-toan" className="inline-flex h-9 shrink-0 items-center gap-1.5 rounded-full border border-brand-600 bg-white px-3.5 text-[13px] font-bold text-brand-600"><Icon name="check" size={15} />Thanh toán</Link>
        ) : (
          <button type="button" onClick={() => add(course.slug)} className="inline-flex h-9 shrink-0 items-center gap-1.5 rounded-full bg-accent-500 px-3.5 text-[13px] font-bold text-white transition-[filter] hover:brightness-95"><Icon name="cart" size={15} />Thêm vào giỏ</button>
        )}
      </div>
    </article>
  );
}
