import Link from 'next/link';
import { Sparkle } from '@/components/ui/Decor';
import type { ReactNode } from 'react';

export function SectionHead({ eyebrow, title, sub, center = true, light = false }: { eyebrow?: string; title: ReactNode; sub?: ReactNode; center?: boolean; light?: boolean }) {
  return (
    <div className={`flex flex-col gap-2.5 ${center ? 'md:mx-auto md:max-w-3xl md:items-center md:text-center' : ''}`}>
      {eyebrow && <span className="eyebrow" style={light ? { color: '#F9E7A6' } : undefined}><Sparkle size={14} color={light ? '#F9E7A6' : '#F29546'} />{eyebrow}</span>}
      <h2 className="h2" style={light ? { color: '#fff' } : undefined}>{title}</h2>
      {sub && <p className={`lead max-w-[620px] ${light ? 'text-[#DCEFE3]' : 'text-muted'}`}>{sub}</p>}
    </div>
  );
}

export function Breadcrumb({ items }: { items: { label: string; href?: string }[] }) {
  return (
    <nav aria-label="Đường dẫn" className="flex flex-wrap gap-2 text-[13px] text-muted">
      {items.map((it, i) => (
        <span key={it.label} className="flex gap-2">
          {i > 0 && <span aria-hidden>/</span>}
          {it.href ? <Link href={it.href} className="hover:text-brand-600">{it.label}</Link> : <span aria-current="page" className="font-semibold text-ink">{it.label}</span>}
        </span>
      ))}
    </nav>
  );
}

export function PageTitle({ crumbs, title, sub, children }: { crumbs: { label: string; href?: string }[]; title: string; sub?: string; children?: ReactNode }) {
  return (
    <div className="flex flex-wrap items-end justify-between gap-4">
      <div className="flex flex-col gap-1.5">
        <Breadcrumb items={crumbs} />
        <h1 className="text-[24px] font-extrabold leading-tight tracking-tight text-brand-700 md:text-[30px]">{title}</h1>
        {sub && <p className="text-[15px] text-muted">{sub}</p>}
      </div>
      {children}
    </div>
  );
}
