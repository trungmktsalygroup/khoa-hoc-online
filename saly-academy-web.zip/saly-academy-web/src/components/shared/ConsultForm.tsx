'use client';
import { useState, type FormEvent } from 'react';
import { CONSULT_TOPICS } from '@/data/home';
import { PACKAGES } from '@/data/packages';
import { SITE } from '@/data/site';
import { Icon } from '@/components/ui/Icon';

/** Form tư vấn dùng chung. variant="topic": chọn nhu cầu; "capital": chọn mô hình quan tâm (giữ tên biến cũ). Gửi về /api/lead. */
export function ConsultForm({ variant = 'topic', source, title }: { variant?: 'topic' | 'capital'; source: string; title?: string }) {
  const [topic, setTopic] = useState(0);
  const [state, setState] = useState<'idle' | 'sending' | 'sent' | 'error'>('idle');
  const [error, setError] = useState('');

  async function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const f = new FormData(e.currentTarget);
    setState('sending');
    const res = await fetch('/api/lead', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name: f.get('name'), phone: f.get('phone'), model: f.get('model') ?? undefined, topic: variant === 'topic' ? CONSULT_TOPICS[topic] : undefined, source }),
    }).catch(() => null);
    const data = await res?.json().catch(() => null);
    if (res?.ok && data?.ok) setState('sent');
    else { setState('error'); setError(data?.error ?? `Chưa gửi được. Vui lòng gọi ${SITE.hotline}.`); }
  }

  if (state === 'sent') {
    return (
      <div className="flex flex-col items-center gap-2.5 px-2 py-6 text-center" role="status">
        <span className="flex size-14 items-center justify-center rounded-full bg-brand-100 text-brand-600"><Icon name="check" size={28} strokeWidth={2.6} /></span>
        <strong className="text-[19px] text-brand-700">Đã nhận thông tin của bạn</strong>
        <span className="text-sm text-ink-2">Đội ngũ SaLy sẽ gọi lại sớm{variant === 'topic' ? ` để tư vấn ${CONSULT_TOPICS[topic].toLowerCase()}` : ''}.</span>
      </div>
    );
  }

  return (
    <form onSubmit={onSubmit} className="flex flex-col gap-3.5" noValidate>
      {title && <span className="text-xl font-extrabold text-brand-700">{title}</span>}
      <label className="flex flex-col gap-1.5 text-[13px] font-semibold">Họ và tên<input name="name" required className="input font-normal" placeholder="Nguyễn Văn A" autoComplete="name" /></label>
      <label className="flex flex-col gap-1.5 text-[13px] font-semibold">Số điện thoại<input name="phone" type="tel" required className="input font-normal" placeholder="09xx xxx xxx" autoComplete="tel" /></label>
      {variant === 'capital' ? (
        <label className="flex flex-col gap-1.5 text-[13px] font-semibold">Mô hình bạn đang quan tâm
          <select name="model" className="input font-normal">{PACKAGES.map((c) => <option key={c.slug}>{c.choice}</option>)}<option>Chưa xác định – cần tư vấn</option></select>
        </label>
      ) : (
        <fieldset className="m-0 min-w-0 border-0 p-0">
          <legend className="float-left mb-2 w-full text-[13px] font-semibold">Bạn cần tư vấn về</legend>
          <div className="clear-both flex flex-wrap gap-2">
            {CONSULT_TOPICS.map((t, i) => <button key={t} type="button" aria-pressed={i === topic} onClick={() => setTopic(i)} className="chip">{t}</button>)}
          </div>
        </fieldset>
      )}
      {state === 'error' && <p role="alert" className="text-sm font-semibold text-[#B42318]">{error}</p>}
      <button type="submit" disabled={state === 'sending'} className="btn btn-accent btn-lg disabled:opacity-60">{state === 'sending' ? 'Đang gửi…' : variant === 'capital' ? 'Nhận tư vấn miễn phí' : 'Gửi đăng ký tư vấn'}</button>
      <span className="text-center text-[13px] text-muted">Hoặc gọi ngay <a href={SITE.hotlineTel} className="font-bold text-accent-600">{SITE.hotline}</a></span>
    </form>
  );
}
