'use client';
import { createContext, useContext, useEffect, useState, type ReactNode } from 'react';

type CartCtx = { items: string[]; add: (slug: string) => void; remove: (slug: string) => void; clear: () => void; has: (slug: string) => boolean };
const Ctx = createContext<CartCtx>({ items: [], add: () => {}, remove: () => {}, clear: () => {}, has: () => false });
const KEY = 'saly-cart';

/** Giỏ hàng tạm lưu trên trình duyệt. Dev thay bằng giỏ hàng thật (API) khi nối hệ thống thanh toán. */
export function CartProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<string[]>([]);
  useEffect(() => {
    try { setItems(JSON.parse(localStorage.getItem(KEY) ?? '[]')); } catch {}
  }, []);
  const save = (next: string[]) => { try { localStorage.setItem(KEY, JSON.stringify(next)); } catch {} return next; };
  const add = (slug: string) => setItems((p) => (p.includes(slug) ? p : save([...p, slug])));
  const remove = (slug: string) => setItems((p) => save(p.filter((s) => s !== slug)));
  const clear = () => setItems(save([]));
  return <Ctx.Provider value={{ items, add, remove, clear, has: (s) => items.includes(s) }}>{children}</Ctx.Provider>;
}

export const useCart = () => useContext(Ctx);
