'use client';
import Image from 'next/image';
import Link from 'next/link';
import { useMemo, useState, type FormEvent } from 'react';
import { getProducts } from '@/data/courses';
import { PAYMENT, SITE } from '@/data/site';
import { vnd } from '@/lib/format';
import { CheckCircle, Icon, type IconName } from '@/components/ui/Icon';
import { useCart } from '@/components/shared/CartProvider';

type Method = 'bank' | 'momo' | 'vnpay';
const METHODS: { id: Method; title: string; sub: string; icon: IconName }[] = [
  { id: 'bank', title: 'Chuyển khoản ngân hàng', sub: 'Quét mã QR, kích hoạt khóa học sau khi nhận tiền', icon: 'wallet' },
  { id: 'momo', title: 'Ví MoMo', sub: 'Thanh toán bằng ứng dụng MoMo', icon: 'phone' },
  { id: 'vnpay', title: 'Thẻ ATM / Visa / Mastercard', sub: 'Qua cổng thanh toán VNPay', icon: 'calc' },
];
const STEPS = ['Giỏ hàng', 'Thanh toán', 'Hoàn tất'];

function Steps({ done }: { done: boolean }) {
  return (
    <ol className="flex items-center gap-2 text-[13px] font-semibold md:gap-3 md:text-sm" aria-label="Các bước đặt hàng">
      {STEPS.map((t, i) => {
        const finished = done ? i < 2 : i < 1;
        const current = done ? i === 2 : i === 1;
        const on = finished || current;
        return (
          <li key={t} className="flex items-center gap-2 md:gap-3" aria-current={current ? 'step' : undefined}>
            {i > 0 && <span className={`h-0.5 w-5 rounded md:w-12 ${on ? 'bg-brand-600' : 'bg-line-2'}`} aria-hidden />}
            <span className={`flex size-6 items-center justify-center rounded-full text-xs ${finished ? 'bg-brand-600 text-white' : current ? 'bg-accent-500 text-white' : 'bg-line text-muted'}`}>
              {finished ? <Icon name="check" size={13} strokeWidth={3} /> : i + 1}
            </span>
            <span className={`whitespace-nowrap ${on ? 'text-ink' : 'text-muted'} ${current ? '' : 'hidden sm:inline'}`}>{t}</span>
          </li>
        );
      })}
    </ol>
  );
}

/** Giỏ hàng + thanh toán + hoàn tất. TODO: nối API tạo đơn và cổng thanh toán (VietQR / MoMo / VNPay). */
export function Checkout() {
  const { items, remove, clear } = useCart();
  const [method, setMethod] = useState<Method>('bank');
  const [code, setCode] = useState('');
  const [coupon, setCoupon] = useState<{ code: string; rate: number } | null>(null);
  const [couponMsg, setCouponMsg] = useState('');
  const [sending, setSending] = useState(false);
  const [error, setError] = useState('');
  const [order, setOrder] = useState<{ id: string; total: number; name: string; method: Method; titles: string[] } | null>(null);

  const list = useMemo(() => getProducts().filter((c) => items.includes(c.slug)), [items]);
  const priced = list.filter((c) => c.price);
  const unpriced = list.length - priced.length;
  const original = priced.reduce((t, c) => t + (c.oldPrice ?? c.price!), 0);
  const subtotal = priced.reduce((t, c) => t + c.price!, 0);
  const saleOff = original - subtotal;
  const couponOff = coupon ? Math.round((subtotal * coupon.rate) / 1000) * 1000 : 0;
  const total = subtotal - couponOff;

  function applyCoupon() {
    const c = code.trim().toUpperCase();
    if (!c) return;
    const rate = PAYMENT.demoCoupons[c];
    if (rate) { setCoupon({ code: c, rate }); setCouponMsg(`Đã áp dụng mã ${c}: giảm ${Math.round(rate * 100)}%`); }
    else { setCoupon(null); setCouponMsg('Mã giảm giá không đúng hoặc đã hết hạn.'); }
  }

  async function submit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const f = new FormData(e.currentTarget);
    const name = String(f.get('name') ?? '').trim();
    const phone = String(f.get('phone') ?? '').replace(/\s/g, '');
    if (!name) return setError('Vui lòng nhập họ và tên.');
    if (!/^0\d{9}$/.test(phone)) return setError('Số điện thoại chưa đúng (10 số, bắt đầu bằng 0).');
    if (!f.get('agree')) return setError('Vui lòng đồng ý với điều khoản trước khi đặt hàng.');
    setError(''); setSending(true);
    const id = 'SA' + Date.now().toString().slice(-6);
    // Tạm gửi về /api/lead để đội Sale xử lý – Dev thay bằng API tạo đơn hàng
    const res = await fetch('/api/lead', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ source: 'thanh-toan', orderId: id, name, phone, email: f.get('email'), note: f.get('note'), method, coupon: coupon?.code, total, items: list.map((c) => c.slug) }),
    }).catch(() => null);
    setSending(false);
    if (!res?.ok) { setError(`Chưa gửi được đơn hàng. Vui lòng gọi ${SITE.hotline}.`); return; }
    setOrder({ id, total, name, method, titles: list.map((c) => c.title) });
    clear(); window.scrollTo(0, 0);
  }

  /* ───── Hoàn tất ───── */
  if (order) {
    return (
      <div className="flex flex-col items-center gap-6">
        <Steps done />
        <div className="card flex w-full max-w-[720px] flex-col gap-6 rounded-[24px] p-6 md:p-10">
          <div className="flex flex-col items-center gap-3 text-center">
            <span className="flex size-16 items-center justify-center rounded-full bg-brand-100 text-brand-600"><Icon name="check" size={32} strokeWidth={2.6} /></span>
            <h1 className="text-[24px] font-extrabold text-brand-700 md:text-[28px]">Đặt hàng thành công!</h1>
            <p className="text-[15px] text-ink-2">Cảm ơn {order.name}. Mã đơn hàng của bạn là <strong className="text-accent-600">{order.id}</strong>.</p>
          </div>
          {order.method === 'bank' ? (
            <div className="grid gap-5 rounded-2xl bg-mint p-5 md:grid-cols-[180px_1fr] md:items-center">
              {/* TODO: ảnh VietQR thật theo số tài khoản + số tiền + nội dung */}
              <div className="mx-auto flex size-[180px] flex-col items-center justify-center gap-2 rounded-xl border-2 border-dashed border-brand-600/40 bg-white text-center text-xs text-muted"><Icon name="calc" size={28} />Mã QR chuyển khoản</div>
              <dl className="grid grid-cols-[auto_1fr] gap-x-4 gap-y-2 text-[14.5px]">
                <dt className="text-muted">Ngân hàng</dt><dd className="font-semibold">{PAYMENT.bank}</dd>
                <dt className="text-muted">Số tài khoản</dt><dd className="font-semibold">{PAYMENT.accountNo}</dd>
                <dt className="text-muted">Chủ tài khoản</dt><dd className="font-semibold">{PAYMENT.accountName}</dd>
                <dt className="text-muted">Số tiền</dt><dd className="text-lg font-extrabold text-accent-600">{vnd(order.total)}</dd>
                <dt className="text-muted">Nội dung</dt><dd className="font-semibold">{order.id}</dd>
              </dl>
            </div>
          ) : (
            <p className="rounded-2xl bg-mint p-5 text-center text-[15px] text-ink-2">
              Đang chuyển bạn tới cổng thanh toán {order.method === 'momo' ? 'MoMo' : 'VNPay'}…
              <span className="block text-xs text-muted">(Bản xem thử – Dev nối cổng thanh toán thật)</span>
            </p>
          )}
          <ul className="flex flex-col gap-2 text-[14.5px]">
            {order.titles.map((t) => <li key={t} className="flex gap-2"><CheckCircle size={17} />{t}</li>)}
          </ul>
          <p className="text-center text-[13.5px] text-muted">Khóa học được kích hoạt ngay khi SaLy nhận được thanh toán. Cần hỗ trợ, gọi <a href={SITE.hotlineTel} className="font-bold text-accent-600">{SITE.hotline}</a>.</p>
          <div className="flex flex-wrap justify-center gap-3">
            <Link href="/hoc/tra-trai-cay" className="btn btn-accent">Vào học ngay</Link>
            <Link href="/khoa-hoc" className="btn btn-outline">Xem thêm khóa học</Link>
          </div>
        </div>
      </div>
    );
  }

  /* ───── Giỏ trống ───── */
  if (list.length === 0) {
    return (
      <div className="flex flex-col items-center gap-6">
        <Steps done={false} />
        <div className="card flex w-full max-w-[560px] flex-col items-center gap-4 rounded-[24px] px-6 py-12 text-center">
          <span className="flex size-16 items-center justify-center rounded-full bg-accent-50 text-accent-600"><Icon name="cart" size={30} /></span>
          <h1 className="text-[22px] font-extrabold text-brand-700">Giỏ hàng đang trống</h1>
          <p className="text-[15px] text-muted">Chọn khóa học phù hợp với mô hình quán của bạn rồi quay lại đây để thanh toán.</p>
          <Link href="/khoa-hoc" className="btn btn-accent btn-lg">Xem khóa học <Icon name="arrowRight" size={16} strokeWidth={2.4} /></Link>
        </div>
      </div>
    );
  }

  /* ───── Giỏ hàng + thanh toán ───── */
  return (
    <form onSubmit={submit} noValidate className="flex flex-col gap-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <h1 className="text-[24px] font-extrabold text-brand-700 md:text-[30px]">Thanh toán</h1>
        <Steps done={false} />
      </div>
      <div className="grid items-start gap-6 lg:grid-cols-[1fr_400px] lg:gap-8">
        <div className="flex min-w-0 flex-col gap-6">
          <section className="card rounded-[20px] p-4 md:p-6" aria-labelledby="gio-hang">
            <h2 id="gio-hang" className="mb-3 text-[17px] font-extrabold text-brand-700">Khóa học trong giỏ ({list.length})</h2>
            <ul className="flex flex-col divide-y divide-line">
              {list.map((c) => (
                <li key={c.slug} className="flex gap-3 py-3.5 md:gap-4">
                  <Image src={c.image} alt="" width={160} height={90} className="h-[62px] w-[110px] shrink-0 rounded-lg object-cover md:h-[76px] md:w-[136px]" />
                  <div className="flex min-w-0 flex-1 flex-col gap-1">
                    <span className="line-clamp-2 text-[14.5px] font-bold leading-snug md:text-[15.5px]">{c.title}</span>
                    <span className="text-[12.5px] text-muted">{c.kind === 'package' ? 'Gói theo mô hình' : 'Khóa lẻ'} · Giảng viên Ly Phạm · Học online trọn đời</span>
                    {c.gift && <span className="self-start rounded-full bg-accent-100 px-2 py-0.5 text-[12px] font-bold text-accent-700">🎁 {c.gift}</span>}
                    <span className="flex items-baseline gap-2 sm:hidden">{c.price ? <strong className="text-[15px] text-brand-600">{vnd(c.price)}</strong> : <strong className="text-[14px] text-accent-600">Liên hệ</strong>}{c.oldPrice && <s className="text-[12px] text-muted">{vnd(c.oldPrice)}</s>}</span>
                    <button type="button" onClick={() => remove(c.slug)} className="mt-auto self-start text-[13px] font-semibold text-[#B42318] hover:underline">Xóa</button>
                  </div>
                  <div className="hidden shrink-0 flex-col items-end gap-0.5 text-right sm:flex">
                    {c.price ? <strong className="text-[15.5px] text-brand-600">{vnd(c.price)}</strong> : <strong className="text-[14px] text-accent-600">Liên hệ</strong>}
                    {c.oldPrice && <s className="text-[12.5px] text-muted">{vnd(c.oldPrice)}</s>}
                  </div>
                </li>
              ))}
            </ul>
            {unpriced > 0 && <p className="mt-2 rounded-xl bg-accent-100 px-3.5 py-2.5 text-[13px] text-ink-2">Khóa học “Liên hệ” chưa tính vào tổng tiền. Tư vấn viên sẽ gọi báo giá sau khi bạn đặt hàng.</p>}
          </section>

          <section className="card rounded-[20px] p-4 md:p-6" aria-labelledby="thong-tin">
            <h2 id="thong-tin" className="mb-4 text-[17px] font-extrabold text-brand-700">Thông tin người học</h2>
            <div className="grid gap-3.5 md:grid-cols-2">
              <label className="flex flex-col gap-1.5 text-[13px] font-semibold">Họ và tên *<input name="name" className="input font-normal" placeholder="Nguyễn Văn A" autoComplete="name" required /></label>
              <label className="flex flex-col gap-1.5 text-[13px] font-semibold">Số điện thoại *<input name="phone" type="tel" className="input font-normal" placeholder="09xx xxx xxx" autoComplete="tel" required /></label>
              <label className="flex flex-col gap-1.5 text-[13px] font-semibold md:col-span-2">Email nhận tài khoản học<input name="email" type="email" className="input font-normal" placeholder="ban@email.com" autoComplete="email" /></label>
              <label className="flex flex-col gap-1.5 text-[13px] font-semibold md:col-span-2">Ghi chú<textarea name="note" rows={2} className="rounded-xl border border-[#D9D3CB] p-3 text-[15px] font-normal" placeholder="Ví dụ: gọi sau 18h" /></label>
            </div>
          </section>

          <section className="card rounded-[20px] p-4 md:p-6" aria-labelledby="phuong-thuc">
            <h2 id="phuong-thuc" className="mb-4 text-[17px] font-extrabold text-brand-700">Phương thức thanh toán</h2>
            <div role="radiogroup" aria-labelledby="phuong-thuc" className="flex flex-col gap-2.5">
              {METHODS.map((m) => (
                <label key={m.id} className={`flex cursor-pointer items-center gap-3.5 rounded-2xl border-2 p-3.5 transition-colors ${method === m.id ? 'border-brand-600 bg-brand-100/50' : 'border-line hover:border-line-2'}`}>
                  <input type="radio" name="method" value={m.id} checked={method === m.id} onChange={() => setMethod(m.id)} className="size-5 accent-brand-600" />
                  <span className={`flex size-10 shrink-0 items-center justify-center rounded-xl ${method === m.id ? 'bg-brand-600 text-white' : 'bg-mint text-brand-600'}`}><Icon name={m.icon} size={20} /></span>
                  <span className="flex flex-col"><strong className="text-[15px]">{m.title}</strong><span className="text-[12.5px] text-muted">{m.sub}</span></span>
                </label>
              ))}
            </div>
          </section>
        </div>

        <aside className="card flex flex-col gap-4 rounded-[20px] p-5 md:p-6 lg:sticky lg:top-24" aria-labelledby="tom-tat">
          <h2 id="tom-tat" className="text-[17px] font-extrabold text-brand-700">Tóm tắt đơn hàng</h2>
          <div className="flex gap-2">
            <label htmlFor="ma-giam" className="sr-only">Mã giảm giá</label>
            <input id="ma-giam" value={code} onChange={(e) => setCode(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); applyCoupon(); } }} className="input h-11 flex-1 uppercase" placeholder="Mã giảm giá" />
            <button type="button" onClick={applyCoupon} className="btn btn-outline h-11 text-sm">Áp dụng</button>
          </div>
          {couponMsg && <p role="status" className={`-mt-2 text-[13px] font-semibold ${coupon ? 'text-brand-600' : 'text-[#B42318]'}`}>{couponMsg}</p>}
          <dl className="flex flex-col gap-2.5 border-t border-line pt-4 text-[14.5px]">
            <div className="flex justify-between"><dt className="text-muted">Giá gốc</dt><dd>{vnd(original)}</dd></div>
            {saleOff > 0 && <div className="flex justify-between"><dt className="text-muted">Ưu đãi khóa học</dt><dd className="font-semibold text-brand-600">−{vnd(saleOff)}</dd></div>}
            {couponOff > 0 && <div className="flex justify-between"><dt className="text-muted">Mã {coupon?.code}</dt><dd className="font-semibold text-brand-600">−{vnd(couponOff)}</dd></div>}
            <div className="flex items-baseline justify-between border-t border-line pt-3"><dt className="font-bold">Tổng thanh toán</dt><dd className="text-[24px] font-extrabold text-accent-600">{vnd(total)}</dd></div>
          </dl>
          <label className="flex cursor-pointer items-start gap-2.5 text-[13px] leading-5 text-ink-2">
            <input type="checkbox" name="agree" className="mt-0.5 size-[18px] shrink-0 accent-brand-600" />
            <span>Tôi đồng ý với <a href="#" className="font-semibold text-brand-600 underline">điều khoản sử dụng</a> và <a href="#" className="font-semibold text-brand-600 underline">chính sách thanh toán</a> của SaLy Academy.</span>
          </label>
          {error && <p role="alert" className="text-[13.5px] font-semibold text-[#B42318]">{error}</p>}
          <button type="submit" disabled={sending} className="btn btn-accent btn-lg w-full disabled:opacity-60">{sending ? 'Đang gửi đơn…' : 'Đặt hàng & thanh toán'}</button>
          <ul className="flex flex-col gap-2 text-[12.5px] text-muted">
            <li className="flex items-center gap-2"><CheckCircle size={14} />Học trọn đời, xem lại không giới hạn</li>
            <li className="flex items-center gap-2"><CheckCircle size={14} />Kích hoạt khóa học ngay khi nhận thanh toán</li>
            <li className="flex items-center gap-2"><CheckCircle size={14} />Hỗ trợ qua hotline {SITE.hotline}</li>
          </ul>
        </aside>
      </div>
    </form>
  );
}
