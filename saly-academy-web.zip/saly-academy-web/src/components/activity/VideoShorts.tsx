'use client';
import { useCallback, useEffect, useState } from 'react';
import { SHORT_VIDEOS } from '@/data/activity';
import { SITE } from '@/data/site';
import { spriteStyle } from '@/lib/format';
import { Icon } from '@/components/ui/Icon';

function VideoCard({ i, onOpen, width }: { i: number; onOpen: (i: number) => void; width?: number }) {
  const v = SHORT_VIDEOS[i];
  return (
    <button type="button" onClick={() => onOpen(i)} aria-label={`Xem video: ${v.title}`} className="flex min-w-0 shrink-0 flex-col gap-2 text-left" style={width ? { width } : undefined}>
      <span className="block aspect-[3/4] w-full overflow-hidden rounded-[14px] bg-line" style={spriteStyle(i)} />
      <span className="line-clamp-2 text-[13px] font-semibold leading-[18px]">{v.title}</span>
      <span className="-mt-1 text-xs text-muted">{v.views} lượt xem</span>
    </button>
  );
}

/** Trình xem video dọc kiểu TikTok (bản demo – nhúng video thật khi có link) */
function Player({ index, onClose, onMove }: { index: number; onClose: () => void; onMove: (d: number) => void }) {
  const [liked, setLiked] = useState<number[]>([]);
  const v = SHORT_VIDEOS[index];
  const isLiked = liked.includes(index);
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose(); if (e.key === 'ArrowDown') onMove(1); if (e.key === 'ArrowUp') onMove(-1); };
    window.addEventListener('keydown', onKey); document.body.style.overflow = 'hidden';
    return () => { window.removeEventListener('keydown', onKey); document.body.style.overflow = ''; };
  }, [onClose, onMove]);

  const act = (icon: 'comment' | 'share', label: string, count: string) => (
    <button type="button" aria-label={label} className="flex flex-col items-center gap-1 text-white">
      <span className="flex size-11 items-center justify-center rounded-full bg-white/16 md:size-12"><Icon name={icon} size={24} /></span>
      <span className="text-xs font-bold">{count}</span>
    </button>
  );

  return (
    <div role="dialog" aria-modal="true" aria-label="Xem video" className="fixed inset-0 z-50 flex flex-col items-center justify-center gap-4 bg-black md:flex-row md:gap-6 md:bg-[rgba(10,14,12,0.92)]">
      <button type="button" onClick={onClose} aria-label="Đóng video" className="absolute right-3 top-3.5 z-10 flex size-11 items-center justify-center rounded-full bg-white/16 text-white md:right-5 md:top-5"><Icon name="close" size={22} /></button>
      <div className="relative w-full md:w-auto">
        <div className="relative aspect-[3/4] w-full overflow-hidden bg-[#111] md:h-[min(84vh,720px)] md:w-auto md:rounded-[18px]" style={spriteStyle(index)}>
          <span className="absolute left-1/2 top-1/2 flex size-[72px] -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full bg-black/45 text-white"><Icon name="play" size={30} /></span>
          <span className="absolute left-3 top-3 rounded-full bg-black/55 px-2.5 py-1 text-[11px] font-bold text-white">Bản demo – video thật phát tại đây</span>
          <div className="absolute inset-x-0 bottom-0 flex flex-col gap-1.5 bg-gradient-to-t from-black/80 to-transparent pb-4.5 pl-4 pr-[70px] pt-15 text-white md:pr-4">
            <strong className="text-[15px]">@lyphamdayphache</strong>
            <span className="text-sm leading-5">{v.title}</span>
            <span className="flex items-center gap-1.5 text-xs text-[#E5E5E5]"><Icon name="play" size={12} />{v.views} lượt xem · {index + 1}/{SHORT_VIDEOS.length}</span>
          </div>
        </div>
        <div className="absolute bottom-[110px] right-2.5 flex flex-col items-center gap-4 md:static md:hidden">
          <button type="button" onClick={() => setLiked((l) => (isLiked ? l.filter((x) => x !== index) : [...l, index]))} aria-pressed={isLiked} aria-label="Thích" className="flex flex-col items-center gap-1 text-white">
            <span className="flex size-11 items-center justify-center rounded-full bg-white/16"><Icon name="heart" size={26} fill={isLiked ? '#FE2C55' : 'none'} stroke={isLiked ? '#FE2C55' : 'currentColor'} /></span>
            <span className="text-xs font-bold">[số]</span>
          </button>
          {act('comment', 'Bình luận', '[số]')}{act('share', 'Chia sẻ', 'Chia sẻ')}
        </div>
      </div>
      <div className="hidden flex-col items-center gap-4 md:flex">
        <button type="button" onClick={() => setLiked((l) => (isLiked ? l.filter((x) => x !== index) : [...l, index]))} aria-pressed={isLiked} aria-label="Thích" className="flex flex-col items-center gap-1 text-white">
          <span className="flex size-12 items-center justify-center rounded-full bg-white/16"><Icon name="heart" size={26} fill={isLiked ? '#FE2C55' : 'none'} stroke={isLiked ? '#FE2C55' : 'currentColor'} /></span>
          <span className="text-xs font-bold">[số]</span>
        </button>
        {act('comment', 'Bình luận', '[số]')}{act('share', 'Chia sẻ', 'Chia sẻ')}
      </div>
      <div className="flex gap-4 md:flex-col md:gap-3">
        <button type="button" onClick={() => onMove(-1)} aria-label="Video trước" className="flex size-12 items-center justify-center rounded-full bg-white/16 text-white"><Icon name="chevronUp" size={24} /></button>
        <button type="button" onClick={() => onMove(1)} aria-label="Video tiếp theo" className="flex size-12 items-center justify-center rounded-full bg-white/16 text-white"><Icon name="chevronDown" size={24} /></button>
      </div>
      <a href={SITE.links.tiktok} className="flex items-center gap-2 rounded-xl px-4 py-2.5 text-sm font-bold text-white md:absolute md:bottom-6 md:left-6 md:bg-white/14"><Icon name="tiktok" size={18} />Xem kênh TikTok của Cô Ly</a>
    </div>
  );
}

export function useVideoPlayer() {
  const [open, setOpen] = useState(-1);
  const move = useCallback((d: number) => setOpen((o) => (o + d + SHORT_VIDEOS.length) % SHORT_VIDEOS.length), []);
  const close = useCallback(() => setOpen(-1), []);
  const player = open >= 0 ? <Player index={open} onClose={close} onMove={move} /> : null;
  return { open: setOpen, player };
}

export function ShortsCarousel({ onOpen }: { onOpen: (i: number) => void }) {
  return (
    <div className="no-scrollbar -mx-4 flex gap-2.5 overflow-x-auto px-4 pb-1 md:mx-0 md:gap-3.5 md:px-0">
      {SHORT_VIDEOS.slice(0, 8).map((_, i) => <VideoCard key={i} i={i} onOpen={onOpen} width={150} />)}
    </div>
  );
}

export function ShortsGrid({ onOpen }: { onOpen: (i: number) => void }) {
  return (
    <div className="grid grid-cols-3 gap-x-2 gap-y-3 md:grid-cols-[repeat(auto-fill,minmax(180px,1fr))] md:gap-x-4 md:gap-y-[18px]">
      {SHORT_VIDEOS.map((_, i) => <VideoCard key={i} i={i} onOpen={onOpen} />)}
    </div>
  );
}
