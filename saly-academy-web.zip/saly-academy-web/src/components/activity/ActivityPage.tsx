'use client';
import type { ReactNode } from 'react';
import Image from 'next/image';
import { useState } from 'react';
import { ACTIVITY_CATEGORIES, ACTIVITY_POSTS, QUICK_NEWS } from '@/data/activity';
import { SITE } from '@/data/site';
import { spriteCoverStyle } from '@/lib/format';
import { Icon, VerifiedBadge, type IconName } from '@/components/ui/Icon';
import { ShortsCarousel, ShortsGrid, useVideoPlayer } from './VideoShorts';

const SecTitle = ({ icon, bg, children }: { icon: IconName; bg: string; children: ReactNode }) => (
  <h2 className="flex items-center gap-2.5 text-[19px] font-extrabold text-brand-700 md:text-[22px]">
    <span className="flex size-8 items-center justify-center rounded-[10px] text-white" style={{ background: bg }}><Icon name={icon} size={18} /></span>{children}
  </h2>
);
const Author = () => (
  <div className="flex min-w-0 flex-1 flex-col"><span className="flex items-center gap-1.5 text-sm font-bold">SaLy Academy <VerifiedBadge /></span><span className="text-xs text-muted">[x] ngày trước</span></div>
);

export function ActivityPage() {
  const [cat, setCat] = useState(0);
  const { open, player } = useVideoPlayer();
  const posts = cat === 0 ? ACTIVITY_POSTS : ACTIVITY_POSTS.filter((p) => p.category === ACTIVITY_CATEGORIES[cat]);

  return (
    <>
      <div className="flex flex-wrap items-start gap-7">
        <aside className="order-2 min-w-0 flex-[1_1_280px] rounded-[20px] border border-line bg-white px-5 pb-2 pt-5 md:order-1 md:max-w-[320px]">
          <SecTitle icon="news" bg="#0D824B">Tin nhanh</SecTitle>
          <ul className="flex flex-col">
            {QUICK_NEWS.map((n) => (
              <li key={n.text} className="flex flex-col gap-2 border-b border-[#ECEFEC] py-3.5">
                <span className="self-start rounded-md bg-brand-100 px-2 py-0.5 text-[11px] font-extrabold uppercase tracking-wide text-brand-600">{n.tag}</span>
                <span className="text-sm font-bold leading-[21px] text-brand-700">{n.text}</span>
                <span className="flex items-center gap-1.5 text-xs text-muted"><strong className="text-ink">SaLy Academy</strong><VerifiedBadge /><span className="ml-auto">[x] ngày trước</span></span>
              </li>
            ))}
          </ul>
          <a href="#" className="block py-2.5 text-sm font-bold text-brand-600">Xem tất cả thông báo</a>
        </aside>

        <div className="order-1 flex min-w-0 flex-[999_1_640px] flex-col gap-8 md:order-2">
          <section className="flex flex-col gap-3.5">
            <div className="flex items-center justify-between gap-3"><SecTitle icon="video" bg="#FE2C55">Video ngắn</SecTitle><a href="#kho-video" className="py-2.5 text-sm font-bold text-brand-600">Xem tất cả video</a></div>
            <ShortsCarousel onOpen={open} />
          </section>

          <section className="flex flex-col gap-3.5">
            <SecTitle icon="pen" bg="#F29546">Hoạt động mới nhất</SecTitle>
            <nav aria-label="Lọc hoạt động" className="no-scrollbar -mx-4 flex gap-2 overflow-x-auto px-4 md:mx-0 md:flex-wrap md:px-0">
              {ACTIVITY_CATEGORIES.map((c, i) => <button key={c} type="button" aria-pressed={i === cat} onClick={() => setCat(i)} className="chip shrink-0">{c}</button>)}
            </nav>
            <div className="grid grid-cols-[repeat(auto-fill,minmax(300px,1fr))] gap-3 md:gap-[18px]">
              {posts.map((p) => (
                <article key={p.title} className="card flex flex-col gap-3 p-3.5 md:p-[18px]">
                  <div className="flex items-center gap-2.5">
                    <span className="flex size-9 shrink-0 items-center justify-center rounded-full bg-brand-600 text-[11px] font-extrabold text-white">SaLy</span>
                    <Author />
                    <span className="whitespace-nowrap rounded-full bg-accent-50 px-2.5 py-1 text-xs font-bold text-accent-700">{p.category}</span>
                  </div>
                  <h3 className="text-base font-extrabold leading-6 text-brand-700 md:text-[17px]">{p.title}</h3>
                  <p className="text-sm leading-[22px] text-ink-2">{p.body}</p>
                  <div className="relative aspect-video overflow-hidden rounded-xl bg-line">
                    {p.image ? <Image src={p.image} alt={p.title} fill sizes="(max-width: 768px) 100vw, 40vw" className="object-cover" />
                      : <button type="button" onClick={() => open(p.videoIndex ?? 0)} aria-label={`Xem video: ${p.title}`} className="absolute inset-0" style={spriteCoverStyle(p.videoIndex ?? 0)} />}
                  </div>
                  <div className="flex gap-1.5 border-t border-[#ECEFEC] pt-2 text-[13px] font-semibold text-ink-2">
                    {([['heart', 'Thích'], ['comment', 'Bình luận'], ['share', 'Chia sẻ']] as const).map(([ic, t]) => (
                      <button key={t} type="button" className="flex h-10 flex-1 items-center justify-center gap-1.5 rounded-[10px] hover:bg-mint"><Icon name={ic} size={18} />{t}</button>
                    ))}
                  </div>
                </article>
              ))}
              {posts.length === 0 && <p className="col-span-full rounded-[18px] border border-dashed border-[#CBD8CF] p-8 text-center text-sm text-muted">Chưa có bài trong mục này.</p>}
            </div>
            <button type="button" className="btn btn-outline self-center rounded-full text-sm">Xem thêm hoạt động</button>
          </section>
        </div>
      </div>

      <section id="kho-video" className="flex scroll-mt-24 flex-col gap-4 pt-3">
        <div className="flex items-center justify-between gap-3"><SecTitle icon="video" bg="#FE2C55">Kho video của Cô Ly</SecTitle><a href={SITE.links.tiktok} className="py-2.5 text-sm font-bold text-brand-600">Xem kênh TikTok</a></div>
        <ShortsGrid onOpen={open} />
      </section>
      {player}
    </>
  );
}
