import { NextResponse } from 'next/server';

/**
 * Nhận form tư vấn / đăng ký và chuyển tiếp về webhook n8n (LEAD_WEBHOOK_URL).
 * Body JSON: { name, phone, topic?, model?, source }
 */
export async function POST(req: Request) {
  const body = await req.json().catch(() => null);
  if (!body?.phone || !/^0\d{9}$/.test(String(body.phone).replace(/\s/g, ''))) {
    return NextResponse.json({ ok: false, error: 'Số điện thoại chưa đúng (10 số, bắt đầu bằng 0).' }, { status: 400 });
  }
  const url = process.env.LEAD_WEBHOOK_URL;
  if (url) {
    const r = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ...body, receivedAt: new Date().toISOString() }) });
    if (!r.ok) return NextResponse.json({ ok: false, error: 'Chưa gửi được, vui lòng gọi hotline.' }, { status: 502 });
  }
  return NextResponse.json({ ok: true });
}
