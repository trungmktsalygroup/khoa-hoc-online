import type { Metadata, Viewport } from 'next';
import { Be_Vietnam_Pro, Oswald, Pacifico } from 'next/font/google';
import { CartProvider } from '@/components/shared/CartProvider';
import { SITE } from '@/data/site';
import { JsonLd } from '@/components/shared/JsonLd';
import { organization } from '@/lib/schema';
import './globals.css';

const font = Be_Vietnam_Pro({ subsets: ['latin', 'vietnamese'], weight: ['400', '500', '600', '700', '800'], variable: '--font-be-vietnam', display: 'swap' });
/** Font chữ số cao, hẹp – dùng cho số liệu lớn (vd. 6.000+) */
/** Font viết tay – tên mô hình, nhãn trang trí */
const script = Pacifico({ subsets: ['latin', 'vietnamese'], weight: '400', variable: '--font-pacifico', display: 'swap' });
const display = Oswald({ subsets: ['latin', 'vietnamese'], weight: ['600', '700'], variable: '--font-oswald', display: 'swap' });

export const metadata: Metadata = {
  metadataBase: new URL(SITE.url),
  title: { default: 'SaLy Academy – Học mở quán từ người đã tự mở quán', template: '%s | SaLy Academy' },
  description: `Khóa học pha chế và kinh doanh quán của Cô Ly Phạm – ${SITE.stats.years} năm kinh nghiệm, ${SITE.stats.students} học viên đã được đào tạo.`,
  icons: { icon: '/images/logo-saly-academy.png' },
  openGraph: { siteName: SITE.name, locale: 'vi_VN', type: 'website', images: ['/images/giang-vien-pha-che.jpg'] },
};

export const viewport: Viewport = { themeColor: '#0D824B', width: 'device-width', initialScale: 1 };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="vi" className={`${font.variable} ${display.variable} ${script.variable}`}>
      <body className="font-sans antialiased">
        <JsonLd data={organization()} />
        <CartProvider>{children}</CartProvider>
      </body>
    </html>
  );
}
