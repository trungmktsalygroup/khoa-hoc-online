import type { Metadata } from 'next';
import Image from 'next/image';
import { Suspense } from 'react';
import { AuthCard } from '@/components/auth/AuthCard';
import { CheckCircle } from '@/components/ui/Icon';
import { SITE } from '@/data/site';

export const metadata: Metadata = { title: 'Đăng nhập / Đăng ký', robots: { index: false } };

function Intro({ compact = false }: { compact?: boolean }) {
  return (
    <div className="flex flex-col gap-3.5">
      <div className="grid grid-cols-3 gap-2 md:gap-3">
        {([[SITE.stats.videos, 'video bài giảng', 'text-brand-700'], [SITE.stats.freeLessons, 'bài học miễn phí', 'text-accent-600'], [SITE.stats.years, 'năm kinh nghiệm', 'text-brand-700']] as const).map(([n, d, c]) => (
          <div key={d} className="flex flex-col rounded-xl bg-white p-3 md:rounded-[14px] md:p-4"><span className={`text-[22px] font-extrabold md:text-[28px] ${c}`}>{n}</span><span className="text-xs text-muted md:text-[13px]">{d}</span></div>
        ))}
      </div>
      {/* Thẻ giảng viên: ảnh tách nền đặt trên MỘT lớp gradient */}
      <div className={`overflow-hidden rounded-xl text-white ${compact ? 'bg-[linear-gradient(120deg,#E8E15A_0%,#7FB24F_9%,#0D824B_19%,#0D824B_100%)]' : 'bg-brand-h flex min-h-[243px] gap-5 pr-7'}`}>
        <div className={compact ? 'flex gap-2.5 pr-3.5' : 'contents'}>
          <Image src="/images/ly-pham-tach-nen-nho.png" alt="Giảng viên Ly Phạm" width={153} height={243} className={`shrink-0 self-end object-contain object-bottom ${compact ? 'h-[124px] w-[78px]' : 'h-[243px] w-[153px]'}`} />
          <p className={`self-center ${compact ? 'py-3 text-[13px] leading-[19px]' : 'hidden'}`}>Trong khóa học này, Ly sẽ chia sẻ những <strong className="underline underline-offset-2">bí quyết để mở quán thành công</strong> mà Ly đã tích lũy trong suốt {SITE.stats.years.replace('+', '')} năm qua:</p>
          <div className={compact ? 'hidden' : 'flex min-w-0 flex-col gap-3 py-5.5 text-[15px] leading-[23px]'}>
            <p>Trong khóa học này, Ly sẽ chia sẻ những <strong className="underline decoration-[1.5px] underline-offset-[3px]">bí quyết để mở quán thành công</strong> mà Ly đã tích lũy trong suốt {SITE.stats.years.replace('+', '')} năm qua:</p>
            <Points />
          </div>
        </div>
        {compact && <div className="flex flex-col gap-2 px-3.5 pb-3.5 pt-2.5 text-[13px] leading-[19px]"><Points /></div>}
      </div>
    </div>
  );
}
function Points() {
  return (<>
    <div className="flex gap-2"><CheckCircle bg="#FFF" fg="#0D824B" size={16} /><span><strong className="underline underline-offset-2">Chia sẻ kiến thức</strong>, từ kỹ năng pha chế đồ uống cho đến kinh nghiệm kinh doanh lĩnh vực F&amp;B</span></div>
    <div className="flex gap-2"><CheckCircle bg="#FFF" fg="#0D824B" size={16} /><span><strong className="underline underline-offset-2">Đào tạo bài bản bởi Giảng viên Ly Phạm - Co-Founder SaLy Academy với hơn {SITE.stats.years} năm kinh nghiệm</strong> về pha chế và vận hành thương hiệu F&amp;B</span></div>
  </>);
}

export default function LoginPage() {
  return (
    <div className="min-h-screen bg-mint">
      <section className="container-site flex flex-wrap items-start gap-6 pb-10 pt-6 md:gap-12 md:pb-18 md:pt-14">
        <div className="flex min-w-0 flex-[1_1_300px] flex-col gap-3 md:flex-[1_1_520px] md:gap-6">
          <span className="self-start rounded-full border border-[#D7E5DB] bg-white px-3 py-1.5 text-xs font-semibold text-brand-600 md:text-[13px]">{SITE.stats.videos} video bài giảng · Cập nhật liên tục</span>
          <h1 className="text-[27px] font-extrabold leading-[1.25] tracking-tight text-brand-700 md:text-[40px] md:leading-[1.2]">Khóa học Pha chế toàn diện <span className="text-accent-600">dành cho người khởi nghiệp</span></h1>
          <p className="max-w-[560px] text-[15px] leading-6 text-ink-2 md:text-lg md:leading-7">Bài giảng chi tiết cho những ai đang nung nấu ý định mở quán: từ kỹ năng pha chế đồ uống đến kinh nghiệm kinh doanh F&amp;B.</p>
          <div className="hidden max-w-[620px] md:block"><Intro /></div>
        </div>
        <div className="w-full min-w-0 flex-[1_1_300px] md:max-w-[460px] md:flex-[1_1_400px]">
          <Suspense><AuthCard /></Suspense>
        </div>
        <div className="w-full md:hidden"><Intro compact /></div>
      </section>
    </div>
  );
}
