import { Header } from '@/components/site/Header';

export default function AuthLayout({ children }: { children: React.ReactNode }) {
  return (<><Header /><main id="noi-dung">{children}</main></>);
}
