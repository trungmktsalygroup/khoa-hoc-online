import Link from 'next/link';
import { Header } from '@/components/site/Header';

export default function NotFound() {
  return (
    <>
      <Header />
      <main className="container-site flex min-h-[60vh] flex-col items-center justify-center gap-4 py-20 text-center">
        <span className="text-6xl font-extrabold text-brand-600">404</span>
        <h1 className="text-2xl font-extrabold text-brand-700">Không tìm thấy trang này</h1>
        <p className="text-muted">Trang có thể đã đổi địa chỉ. Quay về trang chủ hoặc xem các khóa học.</p>
        <div className="flex gap-2.5"><Link href="/" className="btn btn-outline">Về trang chủ</Link><Link href="/khoa-hoc" className="btn btn-accent">Xem khóa học</Link></div>
      </main>
    </>
  );
}
