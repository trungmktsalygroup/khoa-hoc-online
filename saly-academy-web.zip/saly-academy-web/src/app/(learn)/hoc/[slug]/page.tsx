import type { Metadata } from 'next';
import { LessonView } from '@/components/learn/LessonView';
import { COURSES } from '@/data/courses';
import { PACKAGES } from '@/data/packages';

export const metadata: Metadata = { title: 'Trang học Online', robots: { index: false } };
export function generateStaticParams() { return [...PACKAGES, ...COURSES].map((c) => ({ slug: c.slug })); }

export default function LearnPage() {
  return <LessonView />;
}
