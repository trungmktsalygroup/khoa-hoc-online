import { LearnHeader } from '@/components/learn/LearnHeader';

export default function LearnLayout({ children }: { children: React.ReactNode }) {
  return (<div className="min-h-screen bg-[#F7F5F2]"><LearnHeader /><main id="noi-dung">{children}</main></div>);
}
