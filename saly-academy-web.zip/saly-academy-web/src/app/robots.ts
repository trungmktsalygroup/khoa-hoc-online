import type { MetadataRoute } from 'next';
import { SITE } from '@/data/site';

export default function robots(): MetadataRoute.Robots {
  return { rules: [{ userAgent: '*', allow: '/', disallow: ['/hoc/', '/dang-nhap', '/thanh-toan', '/api/'] }], sitemap: `${SITE.url}/sitemap.xml` };
}
