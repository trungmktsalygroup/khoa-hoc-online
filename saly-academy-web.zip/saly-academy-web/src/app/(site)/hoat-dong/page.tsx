import type { Metadata } from 'next';
import { ActivityPage } from '@/components/activity/ActivityPage';
import { PageTitle } from '@/components/shared/SectionHead';
import { Icon } from '@/components/ui/Icon';
import { SITE } from '@/data/site';

export const metadata: Metadata = { title: 'Hoạt động', description: 'Thăm học viên, món mới, lớp học và tin tức mới nhất từ Cô Ly và đội ngũ SaLy.' };

export default function Page() {
  return (
    <div className="container-site flex flex-col gap-7 pb-18 pt-7">
      <PageTitle crumbs={[{ label: 'Trang chủ', href: '/' }, { label: 'Hoạt động' }]} title="Hoạt động SaLy Academy" sub="Thăm học viên, món mới, lớp học và tin tức mới nhất từ Cô Ly và đội ngũ SaLy.">
        <a href={SITE.links.tiktok} className="btn bg-black text-sm text-white"><Icon name="tiktok" size={18} />Theo dõi trên TikTok</a>
      </PageTitle>
      <ActivityPage />
    </div>
  );
}
