import type { Metadata } from 'next';
import { CostCalculator } from '@/components/tools/CostCalculator';
import { ToolGrid } from '@/components/tools/ToolGrid';
import { PageTitle } from '@/components/shared/SectionHead';

export const metadata: Metadata = { title: 'Công cụ cho chủ quán', description: 'Ứng dụng web miễn phí giúp chủ quán tính giá vốn, lập kế hoạch mở quán và vận hành.' };

export default function ToolsPage() {
  return (
    <div className="container-site flex flex-col gap-7 pb-18 pt-7">
      <PageTitle crumbs={[{ label: 'Trang chủ', href: '/' }, { label: 'Công cụ' }]} title="Công cụ cho chủ quán" sub="Ứng dụng web do SaLy phát triển, giúp bạn tính toán và vận hành quán nhanh hơn. Dùng được trên máy tính và điện thoại." />
      <CostCalculator />
      <ToolGrid />
      <section className="flex flex-wrap items-center justify-between gap-4 rounded-[18px] bg-accent-100 p-[18px] md:px-7 md:py-6">
        <div className="flex flex-[1_1_260px] flex-col gap-1"><strong className="text-[17px] text-brand-700 md:text-[19px]">Quán bạn cần công cụ gì?</strong><span className="text-sm leading-[21px] text-ink-2">Gửi đề xuất, SaLy sẽ ưu tiên làm công cụ được nhiều chủ quán cần nhất.</span></div>
        {/* TODO: nối form đề xuất về /api/lead với source="de-xuat-cong-cu" */}
        <form className="flex flex-[1_1_320px] flex-wrap gap-2 md:flex-nowrap">
          <label htmlFor="de-xuat" className="sr-only">Công cụ bạn cần</label>
          <input id="de-xuat" className="input min-w-0 flex-[1_1_200px] border-[#E8D5C2]" placeholder="Ví dụ: chấm công nhân viên" />
          <button type="submit" className="btn btn-brand w-full md:w-auto">Gửi đề xuất</button>
        </form>
      </section>
    </div>
  );
}
