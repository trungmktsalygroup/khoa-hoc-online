import type { Metadata } from 'next';
import Image from 'next/image';
import Link from 'next/link';
import { ConsultForm } from '@/components/shared/ConsultForm';
import { SectionHead } from '@/components/shared/SectionHead';
import { Icon, type IconName } from '@/components/ui/Icon';
import { SITE } from '@/data/site';
import { ALL_POSTS } from '@/data/blog';
import { JsonLd } from '@/components/shared/JsonLd';
import { abs, breadcrumb, ORG_ID, PERSON_ID } from '@/lib/schema';

export const metadata: Metadata = {
  title: 'Ly Phạm – Tác giả & Giảng viên SaLy Academy',
  alternates: { canonical: '/author/ly-pham' },
  description: `Ly Phạm – Co-Founder & Giảng viên SaLy Academy, ${SITE.stats.years} năm kinh nghiệm pha chế và kinh doanh F&B, đã đào tạo ${SITE.stats.students} học viên.`,
  openGraph: { images: ['/images/ly-pham-tach-nen-1.png'], type: 'profile' },
};

const STATS = [
  [SITE.stats.years, 'năm kinh nghiệm pha chế và kinh doanh F&B'],
  ['2017', 'khai trương Lục Coffee & Tea khi còn là sinh viên'],
  [SITE.stats.students, 'học viên đã được Cô Ly đào tạo'],
  ['1', 'cuốn sách “Làm Chủ Từ Đam Mê Pha Chế”'],
] as const;
const JOURNEY = [
  ['Khởi đầu', 'Khát vọng khởi nghiệp từ giảng đường', 'Ngay từ thời sinh viên, Ly cùng chồng là anh Hồ Đăng Sang (nay là Nhà sáng lập và CEO SaLy Group) đã ấp ủ ước mơ có quán cà phê riêng. Hai anh chị tích cóp vốn nhỏ, vay thêm từ ba mẹ.', '/images/giang-vien-pha-che.jpg'],
  ['07/2017', 'Khai trương Lục Coffee & Tea', 'Cửa hàng đầu tiên ra đời khi Ly vẫn đang học năm cuối đại học. Khởi nghiệp với kinh nghiệm gần như bằng 0: từ chọn mô hình, giấy tờ pháp lý, kiểm soát chi phí đến chọn khách hàng, cập nhật món mới.', '/images/khat-vong-khoi-nghiep.jpg'],
  ['Hôm nay', 'Giảng viên và người truyền cảm hứng', 'Từ trải nghiệm thực tế, Ly nhận ra kiến thức kinh doanh F&B là chìa khóa thành công. SaLy Academy ra đời để Ly chia sẻ lại kinh nghiệm, đồng hành cùng hàng ngàn học viên trên con đường mở quán.', '/images/nguoi-truyen-cam-hung.jpg'],
] as const;
const ADVICE: [IconName, string, string, string][] = [
  ['cup', 'Nắm vững kiến thức pha chế', 'Trước khi sáng tạo, hãy vững nền tảng: nguyên liệu, cách kết hợp hương vị và quy trình pha chế chuẩn.', '#0D824B'],
  ['user', 'Khách hàng là trọng tâm', 'Hiểu khẩu vị, thói quen và sở thích của khách hàng mục tiêu để tạo ra sản phẩm và dịch vụ phù hợp.', '#F29546'],
  ['team', 'Quản lý nhân sự', 'Tuyển đúng người, đào tạo kỹ năng và tạo môi trường tích cực: đội ngũ chính là người giữ chân khách hàng.', '#0A7D45'],
];
const EVENTS = [
  ['/images/sat-thu-ban-hang.jpg', 'Khóa học Sát thủ bán hàng'],
  ['/images/mapk01.jpg', 'Lớp MAP – Lên kế hoạch mở quán'],
  ['/images/lop-hoc-map.jpg', 'Hội trường lớp học MAP'],
  ['/images/lop-hoc-pha-che-saly-academy.jpg', 'Lớp pha chế tại SaLy Academy'],
  ['/images/vi-the-lanh-dao.jpg', 'Chương trình Vị thế lãnh đạo'],
] as const;
const SOCIAL = [['facebook', SITE.links.facebook, 'Facebook'], ['linkedin', SITE.links.linkedin, 'LinkedIn'], ['youtube', SITE.links.youtube, 'YouTube'], ['tiktok', SITE.links.tiktok, 'TikTok']] as const;

export default function AboutPage() {
  /** Trang tác giả: ProfilePage + Person (cùng @id với tác giả trong các bài blog) */
  const ld = [
    {
      '@context': 'https://schema.org', '@type': 'ProfilePage', url: abs('/author/ly-pham'), inLanguage: 'vi',
      mainEntity: {
        '@type': 'Person', '@id': PERSON_ID, name: 'Ly Phạm', alternateName: 'Phạm Thị Mai Ly',
        jobTitle: 'Đồng sáng lập & Giảng viên chính SaLy Academy', image: abs('/images/ly-pham-tach-nen-1.png'),
        worksFor: { '@type': 'EducationalOrganization', '@id': ORG_ID, name: SITE.name },
        knowsAbout: ['Pha chế đồ uống', 'Trà trái cây', 'Cà phê', 'Kinh doanh quán F&B', 'Mở quán cà phê'],
        sameAs: SOCIAL.map((x) => x[1]),
      },
      hasPart: ALL_POSTS.map((p) => ({ '@type': 'BlogPosting', headline: p.title, url: abs(`/blog/${p.slug}`) })),
    },
    breadcrumb([{ name: 'Trang chủ', path: '/' }, { name: 'Tác giả Ly Phạm', path: '/author/ly-pham' }]),
  ];
  return (
    <>
      <JsonLd data={ld} />
      <section className="bg-brand-hero overflow-hidden text-white">
        <div className="container-site flex max-w-[1200px] flex-wrap items-end md:gap-6">
          <div className="flex min-w-0 flex-[1_1_300px] flex-col gap-3.5 pb-2 pt-7 md:flex-[1_1_480px] md:gap-4.5 md:py-18">
            <span className="self-start rounded-full bg-white/16 px-3 py-1.5 text-xs font-extrabold tracking-[0.08em]">TÁC GIẢ · CO-FOUNDER &amp; GIẢNG VIÊN SALY ACADEMY</span>
            <h1 className="text-[32px] font-extrabold leading-[1.18] tracking-[-0.02em] md:text-[46px]">Giảng viên Ly Phạm</h1>
            <p className="max-w-[520px] text-base leading-[25px] text-[#E3F1E8] md:text-[19px] md:leading-[30px]">Hơn {SITE.stats.years.replace('+', '')} năm kinh nghiệm pha chế và kinh doanh F&amp;B. Người đồng hành cùng bạn trên hành trình Làm Chủ Quán.</p>
            <div className="mt-1 flex flex-wrap gap-2.5">
              <Link href="/khoa-hoc" className="btn btn-accent btn-lg">Học cùng Ly <Icon name="arrowRight" size={16} strokeWidth={2.4} /></Link>
              <a href="#tu-van" className="btn btn-lg border border-white/60 text-white">Tư vấn miễn phí</a>
            </div>
            <div className="mt-1.5 flex flex-wrap items-center gap-3">
              <span className="text-[13px] text-[#E3F1E8]">Kết nối với Ly</span>
              <div className="flex gap-2">{SOCIAL.map(([ic, href, n]) => <a key={n} href={href} aria-label={`${n} của Ly Phạm`} className="flex size-11 items-center justify-center rounded-xl border border-white/45"><Icon name={ic} size={19} /></a>)}</div>
            </div>
          </div>
          <div className="flex min-w-0 flex-[1_1_300px] justify-center md:flex-[1_1_380px]">
            <Image src="/images/ly-pham-tach-nen-1.png" alt="Giảng viên Ly Phạm" width={760} height={1045} priority sizes="(max-width: 768px) 86vw, 520px" className="h-auto w-[86%] max-w-[520px] md:w-full" />
          </div>
        </div>
      </section>

      <section className="container-site relative max-w-[1200px] pt-4 md:-mt-9 md:pt-0">
        <div className="grid grid-cols-2 gap-2.5 md:grid-cols-4 md:gap-4">
          {STATS.map(([n, d], i) => (
            <div key={d} className="card flex flex-col gap-1 rounded-2xl p-3.5 shadow-[0_10px_30px_rgba(20,67,42,0.08)] md:p-5.5">
              <span className={`text-[24px] font-extrabold leading-tight md:text-[28px] lg:text-[34px] ${i === 2 ? 'text-accent-600' : 'text-brand-600'}`}>{n}</span>
              <span className="text-xs leading-[17px] text-ink-2 md:text-sm md:leading-5">{d}</span>
            </div>
          ))}
        </div>
      </section>

      <section className="container-site flex max-w-[1200px] flex-wrap items-center gap-5 pt-10 md:gap-14 md:pt-22">
        <div className="relative min-w-0 flex-[1_1_300px] md:flex-[1_1_380px]">
          <Image src="/images/giang-vien-ly-pham.jpg" alt="Chân dung giảng viên Ly Phạm" width={528} height={681} sizes="(max-width: 768px) 100vw, 40vw" className="aspect-[4/5] w-full rounded-3xl bg-brand-100 object-cover" />
          <div className="absolute bottom-3 left-3 flex flex-col rounded-[14px] bg-white px-4 py-3 shadow-[0_10px_30px_rgba(20,67,42,0.16)] md:-left-5 md:bottom-7"><span className="text-xs text-muted">Tên đầy đủ</span><span className="text-[15px] font-extrabold text-brand-700">Phạm Thị Mai Ly</span></div>
        </div>
        <div className="flex min-w-0 flex-[1.2_1_300px] flex-col gap-4 md:flex-[1.2_1_460px]">
          <SectionHead eyebrow="LY PHẠM LÀ AI?" title="Từ chủ quán khởi nghiệp đến giảng viên của hàng ngàn học viên" center={false} />
          <p className="text-[15px] leading-[25px] text-ink-2 md:text-[17px] md:leading-7">Ly Phạm, còn được biết đến với tên gọi <strong>Ly Phạm – Dạy Pha Chế</strong>, là nhà đồng sáng lập và giảng viên tại Học viện SaLy Academy, trực thuộc SaLy Group, đồng thời là chủ sở hữu chuỗi cửa hàng Lục Coffee &amp; Tea.</p>
          <p className="text-[15px] leading-[25px] text-ink-2 md:text-[17px] md:leading-7">Các khóa học thực chiến của Ly không chỉ dạy pha chế mà còn hướng dẫn chiến lược kinh doanh, marketing và quản lý nhân sự, giúp học viên biến đam mê thành quán của riêng mình.</p>
          <div className="flex flex-wrap gap-2">{['Co-Founder SaLy Academy', 'Chủ chuỗi Lục Coffee & Tea', 'Tác giả sách', 'Diễn giả'].map((t) => <span key={t} className="rounded-[10px] bg-brand-100 px-3 py-1.5 text-[13px] font-bold text-brand-700">{t}</span>)}</div>
        </div>
      </section>

      <section className="container-site flex max-w-[1200px] flex-col gap-6 pt-12 md:gap-12 md:pt-26">
        <SectionHead eyebrow="HÀNH TRÌNH" title="Hành trình của Ly Phạm" />
        <ol className="flex flex-col gap-8 md:gap-12">
          {JOURNEY.map(([tag, title, text, img], i) => (
            <li key={title} className={`flex flex-wrap items-center gap-4 md:gap-12 ${i % 2 ? 'md:flex-row-reverse' : ''}`}>
              <Image src={img} alt={title} width={824} height={786} sizes="(max-width: 768px) 100vw, 50vw" className="aspect-[16/11] w-full min-w-0 flex-[1_1_300px] rounded-[20px] object-cover md:flex-[1_1_400px]" />
              <div className="flex min-w-0 flex-[1_1_300px] flex-col gap-3 md:flex-[1_1_400px]">
                <div className="flex items-center gap-3"><span className="flex size-10 shrink-0 items-center justify-center rounded-full bg-brand-600 font-extrabold text-white">{i + 1}</span><span className="rounded-full bg-accent-50 px-3 py-1 text-[13px] font-extrabold text-accent-700">{tag}</span></div>
                <h3 className="text-[21px] font-extrabold leading-7 text-brand-700 md:text-[26px] md:leading-[34px]">{title}</h3>
                <p className="text-[15px] leading-6 text-ink-2 md:text-base md:leading-[26px]">{text}</p>
              </div>
            </li>
          ))}
        </ol>
      </section>

      <section className="container-site max-w-[1200px] pt-12 md:pt-26">
        <figure className="flex flex-col gap-4.5 rounded-3xl bg-brand-700 p-6 text-white md:items-center md:p-14 md:text-center">
          <Icon name="quote" size={40} className="text-accent-500" />
          <blockquote className="max-w-[860px] text-[21px] font-bold leading-[31px] md:text-[30px] md:leading-[42px]">Hãy biến đam mê thành hành động, và bạn sẽ sớm thấy được thành công đến từ sự kiên trì và học hỏi.</blockquote>
          <figcaption className="text-[15px] text-[#CFE3D6]">— Ly Phạm</figcaption>
        </figure>
      </section>

      <section className="container-site flex max-w-[1200px] flex-col gap-5 pt-12 md:gap-8 md:pt-26">
        <SectionHead eyebrow="GỬI GẮM CỦA LY" title="3 điều Ly muốn bạn nhớ khi làm chủ quán" />
        <div className="grid gap-3 md:grid-cols-3 md:gap-5">
          {ADVICE.map(([ic, t, d, c]) => (
            <div key={t} className="card flex flex-col gap-3 rounded-[20px] p-5 md:p-7">
              <span className="flex size-13 items-center justify-center rounded-2xl text-white" style={{ background: c }}><Icon name={ic} size={26} /></span>
              <h3 className="text-[19px] font-extrabold leading-[26px] text-brand-700">{t}</h3>
              <p className="text-[15px] leading-6 text-ink-2">{d}</p>
            </div>
          ))}
        </div>
      </section>

      <section id="sach" className="container-site max-w-[1200px] pt-12 md:pt-26">
        <div className="flex flex-wrap items-center gap-3 rounded-[28px] border border-[#F0E6D2] bg-cream px-4.5 py-5 md:gap-14 md:px-14 md:py-12">
          <div className="relative flex w-full justify-center md:w-[380px] md:flex-none">
            <span className="absolute left-1/2 top-1/2 size-60 -translate-x-1/2 -translate-y-1/2 rounded-full bg-[#F6E7A8] md:size-[340px]" aria-hidden />
            <Image src="/images/sach-lam-chu-tu-dam-me-pha-che.png" alt="Sách Làm Chủ Từ Đam Mê Pha Chế – tái bản 2026, tác giả Ly Phạm" width={480} height={633} sizes="(max-width: 768px) 62vw, 340px" className="relative h-auto w-[62%] max-w-[340px] drop-shadow-[0_24px_30px_rgba(60,40,0,0.22)] md:w-full" />
          </div>
          <div className="flex min-w-0 flex-[1_1_300px] flex-col gap-3 md:flex-[1_1_440px] md:gap-4">
            <div className="flex flex-wrap items-center gap-2"><span className="eyebrow">SÁCH CỦA LY PHẠM</span><span className="rounded-full bg-brand-600 px-2.5 py-0.5 text-[11px] font-extrabold text-white">TÁI BẢN 2026</span></div>
            <h2 className="text-[27px] font-extrabold leading-tight tracking-tight text-brand-700 md:text-[38px]">Làm Chủ Từ Đam Mê Pha Chế</h2>
            <p className="text-[15px] leading-6 text-ink-2 md:text-[17px] md:leading-[27px]">Bộ công thức khởi nghiệp hoàn chỉnh: 12 chương, giá cost từng món, hướng dẫn xây menu và kinh nghiệm vận hành quán.</p>
            <div className="flex flex-wrap gap-2">{['Bìa cứng', '200 trang', '130+ công thức có giá cost', '12 chương', 'NXB Phụ Nữ'].map((t) => <span key={t} className="rounded-[9px] border border-[#EADFC9] bg-white px-3 py-1.5 text-[13px] font-semibold text-ink-2">{t}</span>)}</div>
            <div className="flex flex-wrap items-center gap-2.5 text-sm text-ink-2 md:gap-4">
              <span className="flex items-center gap-0.5 text-[#F2A900]">{[0, 1, 2, 3, 4].map((k) => <Icon key={k} name="star" size={16} />)}<strong className="ml-1.5 text-ink">4.9/5</strong></span>
              <span>1.847 đánh giá</span><span><strong className="text-ink">3.253</strong> cuốn đã bán</span>
            </div>
            <div className="flex flex-wrap items-baseline gap-2.5"><strong className="text-[28px] tracking-tight text-brand-600 md:text-[34px]">499.000đ</strong><s className="text-base text-muted">860.000đ</s><span className="rounded-full bg-accent-500 px-2.5 py-0.5 text-[13px] font-extrabold text-white">-42%</span></div>
            <div className="flex flex-wrap gap-2.5">
              <a href={SITE.links.book} className="btn btn-accent btn-lg w-full md:w-auto">Mua sách <Icon name="arrowRight" size={16} strokeWidth={2.4} /></a>
              <a href={SITE.links.book} className="btn btn-outline btn-lg h-auto w-full whitespace-normal py-2.5 text-center text-[15px] md:w-auto">Combo sách + Ebook trợ lý AI · 999.000đ</a>
            </div>
            <span className="text-[13px] text-muted">Giao hàng toàn quốc · Chuyển khoản miễn phí giao hàng</span>
          </div>
        </div>
      </section>

      <section className="container-site flex max-w-[1200px] flex-col gap-5 pt-12 md:gap-8 md:pt-26">
        <SectionHead eyebrow="DIỄN GIẢ" title="Ly Phạm tại các sự kiện" center={false} />
        <div className="grid grid-cols-2 gap-2.5 md:grid-cols-3 md:gap-4">
          {EVENTS.map(([src, cap], i) => (
            <figure key={src} className={`relative overflow-hidden rounded-2xl bg-line ${i === 0 ? 'md:row-span-2' : ''}`}>
              <Image src={src} alt={`Ly Phạm làm diễn giả – ${cap}`} width={750} height={500} sizes="(max-width: 768px) 50vw, 33vw" className={`size-full object-cover ${i === 0 ? 'aspect-[3/2] md:aspect-auto' : 'aspect-[3/2]'}`} />
              <figcaption className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/70 to-transparent px-2 pb-2 pt-5 text-[11px] font-semibold text-white md:px-3 md:pb-2.5 md:pt-6 md:text-[13px]">{cap}</figcaption>
            </figure>
          ))}
        </div>
      </section>

      <section id="bai-viet" aria-labelledby="bai-viet-title" className="container-site flex max-w-[1200px] scroll-mt-24 flex-col gap-5 pt-12 md:gap-8 md:pt-26">
        <div className="flex flex-wrap items-end justify-between gap-3">
          <div className="flex flex-col gap-2">
            <span className="eyebrow">TÁC GIẢ</span>
            <h2 id="bai-viet-title" className="text-[24px] font-extrabold leading-tight tracking-tight text-brand-700 md:text-[34px]">Bài viết của Ly Phạm</h2>
            <p className="text-[15px] text-muted">{ALL_POSTS.length} bài về pha chế, công thức và kinh doanh quán.</p>
          </div>
          <Link href="/blog" className="flex items-center gap-1.5 py-2 text-[15px] font-bold text-brand-600">Xem tất cả trên Blog <Icon name="arrowRight" size={16} /></Link>
        </div>
        <ul className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 md:gap-6">
          {ALL_POSTS.slice(0, 6).map((p) => (
            <li key={p.slug}>
              <Link href={`/blog/${p.slug}`} className="group card flex h-full flex-col overflow-hidden rounded-[18px]">
                <span className="relative block aspect-[16/10] overflow-hidden">
                  <Image src={p.image} alt="" fill sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw" className="object-cover transition-transform duration-500 group-hover:scale-[1.03]" />
                </span>
                <span className="flex flex-1 flex-col gap-2 p-4 md:p-5">
                  <span className="text-[12px] font-bold text-brand-600">{p.category}{p.date ? ` · ${p.date}` : ''}</span>
                  <h3 className="text-[16.5px] font-bold leading-snug text-ink group-hover:text-brand-600">{p.title}</h3>
                  {p.excerpt && <p className="line-clamp-2 text-[14px] leading-[22px] text-muted">{p.excerpt}</p>}
                </span>
              </Link>
            </li>
          ))}
        </ul>
      </section>

      <section id="tu-van" className="container-site max-w-[1200px] pb-8 pt-12 md:pb-22 md:pt-26">
        <div className="bg-brand-corner flex flex-wrap overflow-hidden rounded-[28px]">
          <div className="flex min-w-0 flex-[1_1_300px] flex-col gap-3.5 px-5 pt-6 text-white md:flex-[1_1_380px] md:px-12 md:pt-12">
            <span className="eyebrow" style={{ color: '#F9E7A6' }}>HỌC CÙNG LY</span>
            <h2 className="text-[26px] font-extrabold leading-tight tracking-tight md:text-4xl">Hãy để Ly đồng hành cùng bạn trên hành trình Làm Chủ Quán</h2>
            <p className="text-[15px] leading-6 text-[#E3F1E8]">Để lại thông tin, đội ngũ SaLy sẽ gọi tư vấn miễn phí khóa học phù hợp với bạn.</p>
            <Image src="/images/ly-pham-tach-nen-2.png" alt="Ly Phạm" width={640} height={1092} sizes="360px" className="mt-2 h-auto w-[70%] max-w-[360px] self-center md:w-[78%]" />
          </div>
          <div className="flex min-w-0 flex-[1_1_300px] items-center p-4 md:flex-[1_1_400px] md:p-10">
            <div className="w-full rounded-[20px] bg-white p-5 md:p-7"><ConsultForm variant="topic" source="author-ly-pham" title="Nhận tư vấn miễn phí" /></div>
          </div>
        </div>
      </section>
    </>
  );
}
