import type { Metadata } from 'next';
import Image from 'next/image';
import Link from 'next/link';
import { notFound } from 'next/navigation';
import { CourseCta } from '@/components/blog/BlogSidebar';
import { Breadcrumb } from '@/components/shared/SectionHead';
import { CheckCircle, Icon } from '@/components/ui/Icon';
import { ALL_POSTS, POSTS } from '@/data/blog';
import { SITE } from '@/data/site';
import { ARTICLES } from '@/content/blog';
import { PACKAGES } from '@/data/packages';
import { vnd } from '@/lib/format';
import { JsonLd } from '@/components/shared/JsonLd';
import { abs, breadcrumb, faqPage, isoDate, ORG_ID, PERSON_ID } from '@/lib/schema';

export function generateStaticParams() { return ALL_POSTS.map((p) => ({ slug: p.slug })); }

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params;
  const p = ALL_POSTS.find((x) => x.slug === slug);
  return p ? { title: p.title, description: p.excerpt, alternates: { canonical: `/blog/${p.slug}` }, openGraph: { images: [p.image], type: 'article' } } : {};
}

const DEFAULT_TOC: [string, string][] = [['s1', '1. Chuẩn bị trước giờ mở bán'], ['s2', '2. Bố trí quầy theo thứ tự pha chế'], ['s3', '3. Chuẩn hóa công thức bằng định lượng'], ['s4', '4. Tổng kết']];
const SOCIAL = [['facebook', SITE.links.facebook, 'Facebook'], ['youtube', SITE.links.youtube, 'YouTube'], ['tiktok', SITE.links.tiktok, 'TikTok']] as const;

function Share() {
  return (
    <div className="flex items-center gap-2">
      <span className="mr-1 text-[13px] font-semibold text-muted">Chia sẻ</span>
      <a href="#" aria-label="Chia sẻ lên Facebook" className="flex size-10 items-center justify-center rounded-xl border border-line-2 bg-white text-brand-700"><Icon name="facebook" size={18} /></a>
      <a href="#" aria-label="Sao chép liên kết" className="flex size-10 items-center justify-center rounded-xl border border-line-2 bg-white text-brand-700"><Icon name="link" size={18} /></a>
    </div>
  );
}

export default async function ArticlePage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const post = ALL_POSTS.find((p) => p.slug === slug);
  if (!post) notFound();
  const related = POSTS.filter((p) => p.slug !== slug).slice(0, 3);
  const content = ARTICLES[slug];
  const TOC = content?.toc ?? DEFAULT_TOC;
  const meta = `${content?.updated ? `Cập nhật ${content.updated}` : (post.date ?? '[Ngày đăng]')} · ${post.readMinutes ?? '[x]'} phút đọc`;
  // TODO: nội dung bài viết lấy từ CMS (Markdown/rich text). Phần dưới là khung trình bày mẫu.
  const P = 'text-base leading-[27px] text-[#2E2A26] md:text-[17px] md:leading-[29px]';
  const H2 = 'scroll-mt-24 pt-3 text-[21px] font-extrabold leading-7 tracking-tight text-brand-700 md:text-2xl md:leading-8';

  const pkg = content?.packageSlug ? PACKAGES.find((x) => x.slug === content.packageSlug) : undefined;
  const jsonLd = [
    {
      '@context': 'https://schema.org', '@type': 'BlogPosting', headline: post.title, description: post.excerpt, image: abs(post.image),
      url: abs(`/blog/${post.slug}`), mainEntityOfPage: abs(`/blog/${post.slug}`), inLanguage: 'vi',
      datePublished: isoDate(post.date), dateModified: isoDate(content?.updated ?? post.date),
      articleSection: post.category, keywords: content?.tags?.join(', '),
      author: { '@type': 'Person', '@id': PERSON_ID, name: 'Ly Phạm', url: abs('/author/ly-pham'), jobTitle: 'Đồng sáng lập & Giảng viên chính SaLy Academy' },
      publisher: { '@type': 'EducationalOrganization', '@id': ORG_ID, name: SITE.name, logo: abs('/images/logo-saly-academy.png') },
    },
    breadcrumb([{ name: 'Trang chủ', path: '/' }, { name: 'Blog', path: '/blog' }, { name: post.title, path: `/blog/${post.slug}` }]),
    ...(content?.faq?.length ? [faqPage(content.faq.map(([q, a]) => ({ q, a })))] : []),
  ];

  return (
    <div className="container-site flex max-w-[1200px] flex-col gap-6 pb-18 pt-4 md:pt-6">
      <JsonLd data={jsonLd} />
      <Breadcrumb items={[{ label: 'Trang chủ', href: '/' }, { label: 'Blog', href: '/blog' }, { label: post.category }]} />
      <div className="flex flex-wrap items-start gap-10">
        <article className="flex min-w-0 max-w-[780px] flex-[999_1_640px] flex-col gap-5.5">
          <span className="self-start rounded-full bg-brand-100 px-3 py-1 text-xs font-extrabold tracking-[0.06em] text-brand-600">{post.category.toUpperCase()}</span>
          <h1 className="text-[27px] font-extrabold leading-[1.3] tracking-tight text-brand-700 md:text-[40px] md:leading-[1.25]">{post.title}</h1>
          <p className="text-[17px] leading-[28px] text-muted md:text-[19px] md:leading-[30px]">{content?.lead ?? post.excerpt ?? '[Đoạn mở bài tóm tắt 1–2 câu]'}</p>
          {content?.quickAnswer && (
            <section aria-label="Trả lời nhanh" className="flex flex-col gap-2.5 rounded-[16px] border-l-4 border-brand-600 bg-mint px-5 py-4">
              <p className="text-[13px] font-extrabold uppercase tracking-[0.06em] text-brand-700" aria-hidden>Trả lời nhanh</p>
              <ul className="flex flex-col gap-2">{content.quickAnswer.map((t) => <li key={t} className="flex gap-2.5 text-[15.5px] leading-[25px] text-ink"><CheckCircle size={17} />{t}</li>)}</ul>
            </section>
          )}
          <div className="flex flex-wrap items-center justify-between gap-4 border-y border-line py-3.5">
            <div className="flex items-center gap-3">
              <Image src="/images/ly-pham-tach-nen-nho.png" alt="" width={46} height={46} className="size-10 rounded-full border-2 border-brand-600 bg-brand-100 object-cover object-top md:size-[46px]" />
              <div className="flex flex-col"><Link href="/author/ly-pham" rel="author" className="text-[15px] font-bold hover:text-brand-600">Ly Phạm</Link><span className="text-[13px] text-muted">{meta}</span></div>
            </div>
            <Share />
          </div>
          <Image src={post.image} alt={post.title} width={content ? 800 : 1112} height={content ? 600 : 513} priority sizes="(max-width: 768px) 100vw, 780px" className={`-mx-4 w-[calc(100%+32px)] max-w-none object-cover md:mx-0 md:w-full md:rounded-[18px] ${content ? 'h-auto' : 'aspect-video'}`} />

          <details className="card rounded-[14px] px-3.5 py-1 lg:hidden">
            <summary className="flex min-h-11 cursor-pointer items-center text-[15px] font-extrabold text-brand-700">Mục lục bài viết</summary>
            <nav className="pb-2">{TOC.map(([id, t]) => <a key={id} href={`#${id}`} className="block rounded-lg px-2.5 py-2 text-sm text-ink-2">{t}</a>)}</nav>
          </details>

          {content ? <><content.Body />
            {pkg && (
              <aside aria-label="Khóa học phù hợp" className="flex flex-wrap items-center gap-4 rounded-[18px] border border-line bg-white p-4 md:p-5">
                <Image src={pkg.thumb} alt="" width={120} height={80} className="h-20 w-[120px] shrink-0 rounded-xl object-cover" />
                <div className="flex min-w-0 flex-[1_1_220px] flex-col gap-1">
                  <span className="text-[12px] font-extrabold uppercase tracking-wide text-accent-600">Áp dụng vào quán của bạn</span>
                  <strong className="text-[16px] leading-snug text-brand-700">{pkg.name}</strong>
                  <span className="text-[13.5px] text-muted">{pkg.tagline} · {vnd(pkg.dealPrice ?? pkg.price)}</span>
                </div>
                <Link href={`/khoa-hoc/${pkg.slug}`} className="btn btn-accent shrink-0">Xem khóa học <Icon name="arrowRight" size={16} /></Link>
              </aside>
            )}
            {content.source && <p className="text-[13px] text-muted">Nguồn bài viết: <a href={content.source} className="underline">lypham.vn</a></p>}</> : (<>
          <p className={P}>Giờ cao điểm là lúc quán dễ “vỡ trận” nhất: khách chờ lâu, nhân viên chạy qua chạy lại, đồ uống ra không đều tay. Phần lớn nguyên nhân không nằm ở tay nghề mà ở cách sắp xếp quầy và quy trình chuẩn bị.</p>
          <h2 id="s1" className={H2}>1. Chuẩn bị trước giờ mở bán</h2>
          <p className={P}>Ủ trà nền, sơ chế trái cây và pha sẵn siro theo định lượng ngay từ đầu ca. Mọi thứ cần dùng trong giờ cao điểm phải nằm sẵn trong tầm tay, có nhãn tên và giờ chuẩn bị.</p>
          <aside className="flex gap-3 rounded-[14px] bg-accent-100 px-5 py-4.5">
            <Icon name="bulb" size={22} className="mt-0.5 shrink-0 text-accent-700" />
            <div className="flex flex-col gap-1"><strong className="text-[15px] text-accent-700">Mẹo từ Cô Ly</strong><span className="text-[15px] leading-6 text-ink-2">[Mẹo thực tế từ Cô Ly cho phần này]</span></div>
          </aside>
          <h2 id="s2" className={H2}>2. Bố trí quầy theo thứ tự pha chế</h2>
          <p className={P}>Sắp xếp nguyên liệu và dụng cụ theo đúng trình tự làm một ly: ly và đá, trà nền, siro, trái cây, topping, đóng nắp. Người pha chỉ đi theo một chiều, không phải quay lại lấy đồ.</p>
          <figure className="flex flex-col gap-2">
            <Image src="/images/video-bai-hoc.jpg" alt="Quầy pha chế trà trái cây được bố trí theo thứ tự" width={1112} height={513} sizes="(max-width: 768px) 100vw, 780px" className="aspect-video w-full rounded-[14px] object-cover" />
            <figcaption className="text-center text-[13px] text-muted">[Chú thích ảnh: sơ đồ bố trí quầy pha chế]</figcaption>
          </figure>
          <h2 id="s3" className={H2}>3. Chuẩn hóa công thức bằng định lượng</h2>
          <p className={P}>Mỗi món có một thẻ công thức ghi rõ định lượng từng thành phần. Dùng dụng cụ đong cố định thay vì ước lượng bằng mắt để ly nào cũng giống ly nào, ai pha cũng ra cùng một vị.</p>
          <ul className="flex flex-col gap-2.5">{['[Ý chính 1 của bài]', '[Ý chính 2 của bài]', '[Ý chính 3 của bài]'].map((t) => <li key={t} className="flex gap-2.5 text-base leading-[26px] md:text-[17px]"><CheckCircle />{t}</li>)}</ul>
          <div className="bg-brand-corner flex flex-wrap items-center justify-between gap-4 rounded-2xl px-5.5 py-5 text-white">
            <div className="flex flex-[1_1_260px] flex-col gap-1"><strong className="text-[17px]">Xem Cô Ly làm mẫu trong video bài học</strong><span className="text-sm text-[#E3F1E8]">Chuyên đề Trà Trái Cây · 54 video</span></div>
            <Link href="/dang-nhap?che-do=dang-ky" className="btn btn-accent">Học thử miễn phí <Icon name="arrowRight" size={16} strokeWidth={2.4} /></Link>
          </div>
          <h2 id="s4" className={H2}>4. Tổng kết</h2>
          <p className={P}>[Đoạn tổng kết bài viết]</p>

          </>)}
          <div className="flex flex-wrap items-center justify-between gap-4 border-t border-line py-4.5">
            <div className="flex flex-wrap gap-2">{(content?.tags ?? ['trà trái cây', 'bố trí quầy', 'kinh doanh quán']).map((t) => <Link key={t} href="/blog" className="rounded-full border border-line-2 bg-white px-3 py-1.5 text-[13px] text-ink-2">#{t}</Link>)}</div>
            <Share />
          </div>

          {/* Author bio */}
          <section id="tac-gia" aria-labelledby="bio-title" className="card flex flex-col gap-4 rounded-[20px] p-5 md:flex-row md:gap-6 md:p-7">
            <div className="flex items-center gap-3.5">
              <span className="block size-[78px] shrink-0 overflow-hidden rounded-full md:size-[120px]" style={{ background: 'linear-gradient(135deg,#E8E15A 0%,#0D824B 70%)' }}>
                <Image src="/images/ly-pham-tach-nen-2.png" alt="Giảng viên Ly Phạm" width={120} height={120} className="size-full object-cover object-top" />
              </span>
              <div className="flex flex-col gap-0.5 md:hidden"><span className="text-[11px] font-extrabold tracking-[0.08em] text-accent-700">VỀ TÁC GIẢ</span><span className="text-xl font-extrabold text-brand-700">Ly Phạm</span><span className="text-[13px] text-muted">Đồng sáng lập &amp; Giảng viên chính SaLy Academy</span></div>
            </div>
            <div className="flex min-w-0 flex-1 flex-col gap-3">
              <div className="hidden flex-col gap-0.5 md:flex"><span className="text-xs font-extrabold tracking-[0.08em] text-accent-700">VỀ TÁC GIẢ</span><span id="bio-title" className="text-2xl font-extrabold text-brand-700">Ly Phạm</span><span className="text-sm text-muted">Đồng sáng lập &amp; Giảng viên chính SaLy Academy</span></div>
              <p className="text-sm leading-[22px] text-ink-2 md:text-[15px] md:leading-6">Hơn {SITE.stats.years.replace('+', '')} năm pha chế và vận hành thương hiệu F&amp;B, đã đào tạo hơn {SITE.stats.students.replace('+', '')} học viên. Cô Ly chia sẻ những bí quyết để mở quán thành công, từ kỹ năng pha chế đồ uống đến kinh nghiệm kinh doanh, qua hơn 150 video bài giảng tại SaLy Academy.</p>
              <div className="flex flex-wrap gap-2 text-xs font-bold text-brand-700">{[`${SITE.stats.years} năm kinh nghiệm`, `${SITE.stats.students} học viên`, 'Pha chế & Kinh doanh F&B'].map((t) => <span key={t} className="rounded-lg bg-brand-100 px-2.5 py-1.5">{t}</span>)}</div>
              <div className="flex flex-wrap items-center justify-between gap-2.5">
                <div className="flex gap-2">{SOCIAL.map(([ic, href, n]) => <a key={n} href={href} aria-label={`${n} của Ly Phạm`} className="flex size-11 items-center justify-center rounded-xl border border-line-2 bg-white text-brand-700"><Icon name={ic} size={18} /></a>)}</div>
                <Link href="/author/ly-pham#bai-viet" className="flex items-center gap-1.5 py-2.5 text-sm font-bold text-brand-600">Xem tất cả bài viết của Ly Phạm <Icon name="arrowRight" size={16} /></Link>
              </div>
            </div>
          </section>
        </article>

        <aside className="hidden min-w-0 max-w-[340px] flex-[1_1_300px] flex-col gap-5 lg:sticky lg:top-24 lg:flex">
          <nav aria-label="Mục lục" className="card flex flex-col gap-0.5 rounded-[18px] px-3.5 py-4.5">
            <span className="px-2.5 pb-2 text-[15px] font-extrabold text-brand-700">Mục lục bài viết</span>
            {TOC.map(([id, t]) => <a key={id} href={`#${id}`} className="rounded-lg px-2.5 py-2 text-sm leading-5 text-ink-2 hover:bg-mint">{t}</a>)}
          </nav>
          <CourseCta />
        </aside>
      </div>

      <section className="flex flex-col gap-4.5 pt-4">
        <h2 className="text-[19px] font-extrabold text-brand-700 md:text-2xl">Bài viết liên quan</h2>
        <div className="flex flex-col gap-2.5 md:grid md:grid-cols-3 md:gap-6">
          {related.map((p) => (
            <Link key={p.slug} href={`/blog/${p.slug}`} className="card flex gap-3 p-3 md:flex-col md:border-0 md:bg-transparent md:p-0">
              <span className="relative block h-[74px] w-[104px] shrink-0 overflow-hidden rounded-[10px] md:aspect-[16/10] md:h-auto md:w-full md:rounded-[14px]"><Image src={p.image} alt="" fill sizes="(max-width: 768px) 104px, 33vw" className="object-cover" /></span>
              <span className="flex flex-col gap-1.5"><span className="text-[11px] font-bold text-brand-600 md:text-xs">{p.category}</span><h3 className="text-sm font-bold leading-5 md:text-base md:leading-[23px]">{p.title}</h3></span>
            </Link>
          ))}
        </div>
      </section>
    </div>
  );
}
