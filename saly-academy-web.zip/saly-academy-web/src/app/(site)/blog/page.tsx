import type { Metadata } from 'next';
import Image from 'next/image';
import Link from 'next/link';
import { BlogChipsAndList } from '@/components/blog/BlogIndex';
import { AuthorCard, CourseCta, PopularPosts } from '@/components/blog/BlogSidebar';
import { PageTitle } from '@/components/shared/SectionHead';
import { Icon } from '@/components/ui/Icon';
import { FEATURED_POST as F } from '@/data/blog';

export const metadata: Metadata = { title: 'Blog', description: 'Kiến thức pha chế và kinh nghiệm mở quán, chia sẻ từ đội ngũ SaLy.' };

export default function BlogPage() {
  return (
    <div className="container-site flex flex-col gap-7 pb-16 pt-7">
      <PageTitle crumbs={[{ label: 'Trang chủ', href: '/' }, { label: 'Blog' }]} title="Blog SaLy Academy" sub="Kiến thức pha chế và kinh nghiệm mở quán, chia sẻ từ đội ngũ SaLy." />
      <article className="card flex flex-wrap overflow-hidden rounded-[20px]">
        <Link href={`/blog/${F.slug}`} className="relative aspect-video min-w-0 flex-[1_1_300px] md:flex-[1_1_520px]">
          <Image src={F.image} alt={F.title} fill priority sizes="(max-width: 768px) 100vw, 55vw" className="object-cover" />
          <span className="absolute left-4 top-4 rounded-full bg-accent-500 px-3 py-1.5 text-xs font-extrabold tracking-wider text-white">BÀI VIẾT NỔI BẬT</span>
        </Link>
        <div className="flex min-w-0 flex-[1_1_300px] flex-col justify-center gap-3.5 p-5 md:flex-[1_1_420px] md:px-9 md:py-8">
          <span className="text-xs font-bold tracking-[0.08em] text-accent-600">{F.category.toUpperCase()}</span>
          <h2 className="text-xl font-extrabold leading-tight text-brand-700 md:text-[28px]"><Link href={`/blog/${F.slug}`}>{F.title}</Link></h2>
          <p className="line-clamp-3 text-[15px] leading-6 text-muted">{F.excerpt}</p>
          <div className="flex flex-wrap items-center justify-between gap-4 border-t border-[#ECEFEC] pt-4">
            <div className="flex items-center gap-3">
              <Image src="/images/ly-pham-tach-nen-nho.png" alt="" width={46} height={46} className="size-10 rounded-full border-2 border-brand-600 bg-brand-100 object-cover object-top md:size-[46px]" />
              <div className="flex flex-col"><span className="text-[15px] font-bold">Ly Phạm</span><span className="text-[13px] text-muted">{F.date ?? '[Ngày đăng]'} · {F.readMinutes ?? '[x]'} phút đọc</span></div>
            </div>
            <Link href={`/blog/${F.slug}`} className="btn btn-brand rounded-full text-sm">Đọc bài viết <Icon name="arrowRight" size={16} strokeWidth={2.4} /></Link>
          </div>
        </div>
      </article>
      <BlogChipsAndList sidebar={<><AuthorCard /><CourseCta /><PopularPosts /></>} />
    </div>
  );
}
