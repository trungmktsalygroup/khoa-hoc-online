import Image from 'next/image';
import Link from 'next/link';
import { CapitalPlanner } from '@/components/home/CapitalPlanner';
import { Faq } from '@/components/home/Faq';
import { FeedbackWall } from '@/components/home/FeedbackWall';
import { StudentShops } from '@/components/home/StudentShops';
import { PainPoints } from '@/components/home/PainPoints';
import { HeroSignup } from '@/components/home/HeroSignup';
import { HomeShorts } from '@/components/home/HomeShorts';
import { PerksBento } from '@/components/home/PerksBento';
import { JourneyTimeline } from '@/components/home/JourneyTimeline';
import { ConsultForm } from '@/components/shared/ConsultForm';
import { YouTubeLite } from '@/components/shared/YouTubeLite';
import { SectionHead } from '@/components/shared/SectionHead';
import { LeafMark, OrangeSlice, Sparkle, Wave } from '@/components/ui/Decor';
import { CheckCircle, Icon, type IconName } from '@/components/ui/Icon';
import { Reveal } from '@/components/ui/Reveal';
import { CountUp } from '@/components/ui/CountUp';
import type { CSSProperties } from 'react';
import { FAQS, INTRO_VIDEO, TESTIMONIALS } from '@/data/home';
import { JsonLd } from '@/components/shared/JsonLd';
import { faqPage } from '@/lib/schema';
import { SITE } from '@/data/site';

const STEPS = [
  ['Chọn đúng mô hình', 'Xác định kiểu quán phù hợp với bạn ngay bên dưới để có lộ trình học đúng.'],
  ['Học pha chế', `${SITE.stats.videos} video online hoặc lớp offline, từ kiến thức nền đến công thức bán chạy.`],
  ['Học kinh doanh & vận hành', 'Giá cost, giá bán, marketing, nhân sự – để quán có lãi.'],
  ['Khai trương', 'Nguyên liệu từ SaLy Shop và cộng đồng học viên đồng hành.'],
];

export default function HomePage() {
  return (
    <>
<JsonLd data={faqPage(FAQS)} />
      {/* ───── Màn hình đầu: lời giới thiệu + form đăng ký học thử ───── */}
      <section className="relative overflow-hidden bg-[radial-gradient(120%_90%_at_10%_0%,#109353_0%,#0B8148_45%,#0A7442_100%)] text-white">
        <div className="pointer-events-none absolute -left-24 top-24 size-[420px] rounded-full bg-[#E8E15A]/10 blur-3xl" aria-hidden />
        <div className="pointer-events-none absolute -right-20 bottom-0 size-[380px] rounded-full bg-accent-500/15 blur-3xl" aria-hidden />
        <Sparkle size={22} color="#FFD34E" className="absolute right-[44%] top-24 hidden lg:block" />
        <LeafMark size={140} className="absolute bottom-24 right-[44%] hidden opacity-10 xl:block" />

        <div className="container-site relative grid gap-8 pb-14 pt-8 md:pb-20 md:pt-12 lg:grid-cols-[1.08fr_0.92fr] lg:gap-x-12 lg:gap-y-8 [&>*]:min-w-0">
          {/* Tiêu đề */}
          <div className="flex flex-col gap-4 lg:col-start-1 lg:row-start-1">
            <span className="self-start rounded-md bg-accent-500 px-3 py-1 text-[13px] font-extrabold tracking-wide text-white shadow">{SITE.stats.videos} VIDEO BÀI GIẢNG</span>
            <h1 className="text-[30px] font-extrabold uppercase leading-[1.15] tracking-[-0.01em] text-[#FFD34E] md:text-[44px] lg:text-[40px] xl:text-[50px]" style={{ textWrap: 'balance' }}>
              Học mở quán từ người đã tự mở quán
            </h1>
            <p className="max-w-[600px] text-[15.5px] leading-[26px] text-[#E3F1E8] md:text-[18px] md:leading-[29px]">Khóa học pha chế toàn diện dành cho người khởi nghiệp: từ chọn đúng mô hình quán, công thức có sẵn giá cost đến vận hành và bán hàng.</p>
          </div>

          {/* Form đăng ký */}
          <div className="flex flex-col gap-4 lg:col-start-2 lg:row-span-2 lg:row-start-1">
            <div className="hidden flex-col items-center gap-2 text-center lg:flex">
              <p className="text-[24px] font-extrabold uppercase leading-tight xl:text-[28px]">Học thử miễn phí<br />{SITE.stats.freeLessons} bài học pha chế</p>
              <p className="text-[15px] font-semibold text-[#FFD34E] underline decoration-[#FFD34E]/60 underline-offset-4">Học online trọn đời – Công thức có giá cost – Có hỗ trợ trực tiếp</p>
            </div>
            <HeroSignup />
          </div>

          {/* Lời Cô Ly */}
          <figure className="relative grid overflow-hidden rounded-[22px] bg-white text-ink shadow-[0_24px_60px_rgba(4,40,22,0.3)] sm:grid-cols-[0.8fr_1.2fr] lg:col-start-1 lg:row-start-2">
            <div className="relative flex items-end justify-center overflow-hidden bg-gradient-to-b from-[#FFF4E8] to-[#FCE3C6] pt-6 sm:pt-0">
              <span className="absolute left-1/2 top-[18%] size-[78%] -translate-x-1/2 rounded-full border-[14px] border-accent-500/20" aria-hidden />
              <OrangeSlice size={46} className="float-y-slow absolute left-3 top-4" />
              <Image src="/images/ly-pham-nhan-vat.png" alt="Cô Ly Phạm" width={626} height={988} priority sizes="(max-width: 640px) 55vw, 260px" className="relative h-auto w-[55%] sm:w-[86%]" />
            </div>
            <div className="flex flex-col gap-3.5 p-5 md:p-7">
              <Icon name="quote" size={34} className="text-accent-500" />
              <blockquote className="flex flex-col gap-3 text-[15px] leading-[25px] text-ink-2 md:text-[16px] md:leading-[27px]">
                <p>Ly từng khởi nghiệp với kinh nghiệm gần như bằng 0, vấp đủ mọi sai lầm của người mở quán lần đầu.</p>
                <p className="font-bold uppercase leading-snug text-accent-600">Trong khóa học này, Ly chia sẻ những bí quyết mở quán thành công đã tích lũy suốt {SITE.stats.years.replace('+', '')} năm qua</p>
                <p><span className="font-semibold text-ink underline decoration-accent-500/50 underline-offset-4">Từ kỹ năng pha chế đến kinh nghiệm kinh doanh F&amp;B</span> – để bạn đi đường tắt, không phải trả giá như Ly đã từng.</p>
              </blockquote>
              <figcaption className="mt-1 flex flex-col gap-1 border-t border-line pt-3.5">
                <strong className="text-[16px] text-brand-700">Ly Phạm – Co-Founder SaLy Academy</strong>
                <span className="text-[13px] text-muted">Chủ chuỗi Lục Coffee &amp; Tea · Tác giả sách “Làm Chủ Từ Đam Mê Pha Chế”</span>
              </figcaption>
            </div>
          </figure>
        </div>
        <Wave color="#F6F8F6" />
      </section>

      {/* ───── Nỗi lo ───── */}
      <PainPoints />

      {/* ───── Lộ trình (nền xanh rừng) ───── */}
      <section className="relative">
        <Wave color="#0B8148" />
        <div className="bg-forest relative overflow-hidden text-white">
          <LeafMark size={120} className="absolute -right-6 top-10 opacity-15 md:right-10" />
          <div className="section container-site flex flex-col gap-12 md:gap-16">
            <SectionHead eyebrow="LỘ TRÌNH 4 BƯỚC" title="Từ chưa có gì đến ngày khai trương" sub="Đi đúng thứ tự giúp bạn không tốn tiền cho những thứ chưa cần." light />
            <Reveal as="ol" className="reveal-steps grid gap-8 md:grid-cols-2 md:gap-x-8 lg:grid-cols-4 lg:gap-6">
              {STEPS.map(([t, d], i) => (
                <li key={t} className="relative flex gap-4 lg:flex-col lg:gap-4" style={{ '--i': i } as CSSProperties}>
                  <span className="step-badge relative flex size-12 shrink-0 items-center justify-center">
                    <OrangeSlice size={48} className="step-slice absolute inset-0" />
                    <span className="relative flex size-7 items-center justify-center rounded-full bg-white text-sm font-extrabold text-accent-700">{i + 1}</span>
                  </span>
                  {i < 3 && <span className="step-line absolute left-[60px] right-0 top-6 hidden border-t-2 lg:block border-dashed border-white/25" aria-hidden />}
                  <div className="step-text flex flex-col gap-1.5">
                    <h3 className="step-title text-[17px] font-bold">{t}</h3>
                    <p className="step-desc text-[14.5px] leading-6 text-[#CFE6D8]">{d}</p>
                  </div>
                </li>
              ))}
            </Reveal>
            <Link href="#von" className="btn btn-accent btn-lg self-center">Bắt đầu: chọn mô hình của bạn <Icon name="arrowRight" size={16} strokeWidth={2.4} /></Link>
          </div>
        </div>
        <Wave color="#0B8148" flip />
      </section>

      {/* ───── Chọn mô hình (Bước đầu tiên) ───── */}
      <section id="von" className="container-site scroll-mt-24 pt-14 md:pt-20">
        <CapitalPlanner />
      </section>

      {/* ───── Đặc quyền học viên ───── */}
      <PerksBento />

      {/* ───── Số học viên + ảnh quán (nền cam) ───── */}
      <StudentShops />

      {/* ───── Học viên: câu chuyện + lời nhắn (nền xanh rừng) ───── */}
      <section className="relative">
        <Wave color="#0B8148" />
        <div className="bg-forest text-white">
          <div className="section container-site flex flex-col gap-12">
            <SectionHead eyebrow="TẤM GƯƠNG HỌC VIÊN" title="Họ cũng từng bắt đầu như bạn" sub="Những chủ quán đã học tại SaLy Academy và mở quán thành công." light />
            <div className="no-scrollbar -mx-4 flex snap-x snap-mandatory gap-5 overflow-x-auto px-4 pb-2 md:mx-0 md:grid md:grid-cols-2 md:gap-7 md:px-0">
              {TESTIMONIALS.map((t) => (
                <figure key={t.name} className="flex w-[86%] shrink-0 snap-start flex-col overflow-hidden rounded-[24px] bg-white text-ink md:w-auto xl:flex-row">
                  <div className="relative aspect-[16/10] xl:aspect-auto xl:w-[42%] xl:shrink-0">
                    <Image src={t.photo} alt={`Quán ${t.store}`} fill sizes="(max-width: 768px) 86vw, 25vw" className="object-cover" />
                  </div>
                  <div className="flex flex-1 flex-col gap-4 p-5 md:p-6">
                    <div className="flex items-center gap-3">
                      <Image src={t.avatar} alt="" width={48} height={48} className="size-12 rounded-full object-cover" />
                      <figcaption className="flex flex-col leading-tight"><strong className="text-[15.5px] text-brand-700">{t.name}</strong><span className="text-[13px] text-muted">{t.store} · {t.place}</span></figcaption>
                      <span className="ml-auto rounded-md bg-brand-500 px-2 py-0.5 text-[11px] font-bold text-white">{t.cohort}</span>
                    </div>
                    <blockquote className="text-[14.5px] leading-6 text-ink-2">“{t.quote}”</blockquote>
                    <div className="mt-auto grid grid-cols-2 gap-3 border-t border-[#ECEFEC] pt-4">
                      {t.stats.map(([n, l]) => <div key={l} className="flex flex-col"><strong className="text-[17px] text-accent-600">{n}</strong><span className="text-xs text-muted">{l}</span></div>)}
                    </div>
                  </div>
                </figure>
              ))}
            </div>
            <div className="flex flex-col gap-6 pt-4 md:gap-8">
              <div className="flex flex-col items-center gap-2 text-center">
                <h3 className="text-[19px] font-extrabold md:text-[24px]">Và những lời nhắn mỗi ngày từ học viên</h3>
                <p className="text-[14.5px] text-[#CFE6D8]">Tin nhắn, bình luận thật gửi Cô Ly sau khi học và mở quán.</p>
              </div>
              <FeedbackWall />
            </div>
            <Link href="/hoat-dong" className="btn btn-lg self-center border border-white/50 text-white">Xem thêm câu chuyện học viên <Icon name="arrowRight" size={16} /></Link>
          </div>
        </div>
        <Wave color="#0B8148" flip />
      </section>

      {/* ───── Video giới thiệu ───── */}
      <section className="section container-site flex flex-col gap-12 pb-0 md:gap-16 md:pb-0">
        <div className="grid items-center gap-8 lg:grid-cols-[0.8fr_1.2fr] lg:gap-14">
        <div className="flex flex-col gap-5">
          <SectionHead eyebrow="XEM TRONG 1 PHÚT" title="Khóa học pha chế toàn diện dành cho người khởi nghiệp" sub="Cô Ly giới thiệu lộ trình hơn 150 bài học: từ công thức đồ uống đến giá cost, menu và vận hành quán." center={false} />
          <ul className="flex flex-col gap-2.5 text-[14.5px] text-ink-2">
            {[`${SITE.stats.videos} video bài giảng, công thức có sẵn giá cost`, 'Thủ tục pháp lý, marketing và bán hàng qua app giao đồ ăn', 'Học trọn đời, xem lại mọi lúc trên điện thoại'].map((t) => <li key={t} className="flex gap-2"><CheckCircle size={16} />{t}</li>)}
          </ul>
        </div>
        <div className="relative">
          <Sparkle size={28} className="absolute -right-2 -top-5 z-10" />
          <YouTubeLite {...INTRO_VIDEO} />
        </div>
        </div>
        <HomeShorts />
      </section>

      {/* ───── Cô Ly & hành trình ───── */}
      <section className="section container-site flex flex-col gap-12 md:gap-16">
        <div className="grid items-end gap-8 lg:grid-cols-[1.1fr_0.9fr] lg:gap-16">
          <div className="flex flex-col gap-5">
            <SectionHead eyebrow="HÀNH TRÌNH CỦA CÔ LY" title="Từ một chiếc xe Lục Coffee đến học viện pha chế" center={false} />
            <p className="lead max-w-[560px]">Chủ thương hiệu Lục Coffee &amp; Tea, Co-Founder SaLy Group, tác giả sách “Làm Chủ Từ Đam Mê Pha Chế”, diễn giả khóa MAP – Thực chiến xây dựng kế hoạch kinh doanh F&amp;B.</p>
            <Link href="/author/ly-pham" className="btn btn-outline self-start">Tìm hiểu về Cô Ly <Icon name="arrowRight" size={16} /></Link>
          </div>
          <div className="grid grid-cols-3 gap-3 rounded-[22px] bg-white p-4 shadow-[0_10px_30px_rgba(20,67,42,0.06)] md:p-7">
            {[[SITE.stats.years, 'năm kinh nghiệm'], [SITE.stats.students, 'học viên'], ['330.000+', 'người theo dõi']].map(([n, l]) => (
              <div key={l} className="flex min-w-0 flex-col"><CountUp value={n} className="block whitespace-nowrap text-[19px] font-extrabold tabular-nums text-brand-600 sm:text-[24px] xl:text-[26px] 2xl:text-[30px]" /><span className="text-[12.5px] text-muted md:text-[13px]">{l}</span></div>
            ))}
          </div>
        </div>
        <JourneyTimeline />
      </section>

      {/* ───── Câu hỏi ───── */}
      <section id="cau-hoi" className="scroll-mt-20 bg-[#FEF4ED]">
        <div className="section mx-auto flex max-w-[1000px] flex-col gap-8 px-4 md:gap-12 md:px-6">
          <h2 className="flex flex-col items-center gap-2 text-center font-extrabold uppercase leading-tight tracking-[-0.01em] [text-shadow:0_6px_24px_rgba(255,255,255,0.95)]">
            <span className="text-[20px] text-accent-500 [text-wrap:balance] md:text-[38px]">Bạn có câu hỏi về khóa học?</span>
            <span className="flex flex-wrap items-center justify-center gap-x-3 gap-y-1 text-[20px] text-[#0A7D45] md:text-[38px]">
              <Image src="/images/logo-saly-academy.png" alt="SaLy Academy" width={936} height={250} className="h-9 w-auto md:h-14" />
              có thể giúp gì cho bạn
            </span>
          </h2>
          <Faq />
          <p className="text-center text-[15px] text-muted">Không thấy câu hỏi của bạn? Gọi <a href={SITE.hotlineTel} className="font-bold text-accent-600">{SITE.hotline}</a> để được tư vấn miễn phí.</p>
        </div>
      </section>

      {/* ───── Form tư vấn ───── */}
      <section id="tu-van" className="section container-site scroll-mt-20">
        <div className="relative grid gap-8 overflow-hidden rounded-[32px] bg-forest p-6 text-white md:p-12 lg:grid-cols-2 lg:gap-12 lg:p-14">
          <LeafMark size={160} className="absolute -bottom-10 -left-10 opacity-15" />
          <div className="relative flex flex-col gap-5">
            <SectionHead eyebrow="SẴN SÀNG BẮT ĐẦU?" title="Quán đầu tiên của bạn bắt đầu từ hôm nay" sub="Để lại thông tin, đội ngũ SaLy gọi tư vấn lộ trình phù hợp với mô hình bạn muốn mở. Miễn phí." center={false} light />
            <ul className="flex flex-col gap-2.5 text-[14.5px] text-[#E3F1E8]">
              {['Tư vấn chọn đúng mô hình', 'Gợi ý khóa học phù hợp', 'Ưu đãi riêng khi đăng ký sớm'].map((t) => <li key={t} className="flex gap-2"><CheckCircle size={16} bg="#F29546" />{t}</li>)}
            </ul>
          </div>
          <div className="relative rounded-[22px] bg-white p-5 text-ink md:p-7"><ConsultForm variant="capital" source="trang-chu" /></div>
        </div>
      </section>

            {/* Thanh hành động cố định trên Mobile */}
      <div className="mobile-cta fixed inset-x-0 bottom-0 z-30 flex gap-2.5 border-t border-line bg-white px-3 pb-3.5 pt-2.5 shadow-[0_-6px_20px_rgba(20,67,42,0.08)] md:hidden">
        <a href={SITE.hotlineTel} aria-label={`Gọi tư vấn ${SITE.hotline}`} className="flex h-[50px] w-[52px] shrink-0 items-center justify-center rounded-[14px] border border-brand-600 text-brand-600"><Icon name="phone" size={21} /></a>
        <a href="#dang-ky" className="btn btn-accent btn-lg flex-1">Học thử miễn phí <Icon name="arrowRight" size={16} strokeWidth={2.4} /></a>
      </div>
    </>
  );
}
