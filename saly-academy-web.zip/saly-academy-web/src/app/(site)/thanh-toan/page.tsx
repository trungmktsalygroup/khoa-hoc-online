import type { Metadata } from 'next';
import { Checkout } from '@/components/checkout/Checkout';

export const metadata: Metadata = { title: 'Giỏ hàng & thanh toán', robots: { index: false } };

export default function CheckoutPage() {
  return (
    <div className="container-site max-w-[1200px] pb-20 pt-7 md:pt-10">
      <Checkout />
    </div>
  );
}
