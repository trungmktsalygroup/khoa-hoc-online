import type { Metadata } from 'next';
import { Suspense } from 'react';
import { CourseCatalog } from '@/components/courses/CourseCatalog';
import { PackageGrid } from '@/components/courses/PackageGrid';
import { PackageCompare } from '@/components/courses/PackageCompare';
import { Icon } from '@/components/ui/Icon';

function Leaf({ className = '', size = 28 }: { className?: string; size?: number }) {
  return <svg width={size} height={size} viewBox="0 0 24 24" aria-hidden className={className}><path d="M4 20C4 10 10 4 21 3c-1 11-7 17-17 17z" fill="currentColor" /><path d="M4 20L14 10" stroke="#fff" strokeWidth="1.2" /></svg>;
}
import { SITE } from '@/data/site';
import { PACKAGES } from '@/data/packages';
import { JsonLd } from '@/components/shared/JsonLd';
import { abs, breadcrumb } from '@/lib/schema';

export const metadata: Metadata = { title: 'Khóa học theo mô hình quán', description: 'Chọn gói khóa học pha chế & kinh doanh theo đúng mô hình quán bạn muốn mở: xe trà, Coffee & Tea mang đi, ngồi lại, lộ trình trọn bộ.' };

export default function CoursesPage() {
  return (
    <div className="container-site flex flex-col gap-14 pb-18 pt-7 md:gap-20">
      <JsonLd data={[breadcrumb([{ name: 'Trang chủ', path: '/' }, { name: 'Khóa học', path: '/khoa-hoc' }]), {
        '@context': 'https://schema.org', '@type': 'ItemList', name: 'Khóa học pha chế & kinh doanh theo mô hình quán',
        itemListElement: PACKAGES.map((p, i) => ({ '@type': 'ListItem', position: i + 1, url: abs(`/khoa-hoc/${p.slug}`), name: p.name })),
      }]} />
      <section className="relative flex flex-col gap-8">
        <Leaf className="absolute -left-2 top-16 hidden rotate-[-30deg] text-brand-600 md:block" size={30} />
        <Leaf className="absolute -right-1 -top-2 hidden rotate-[20deg] text-brand-600 md:block" size={34} />
        <div className="flex flex-wrap items-center justify-between gap-6 xl:flex-nowrap">
          <div className="flex min-w-0 flex-col gap-2 md:pl-6 xl:flex-1">
            <span className="flex items-center gap-2 font-script text-[20px] text-brand-600">
              <span className="h-4 w-0.5 -rotate-[25deg] rounded bg-accent-500" aria-hidden />Khóa học nổi bật<span className="flex gap-1" aria-hidden><span className="h-4 w-0.5 rotate-[25deg] rounded bg-accent-500" /><span className="mt-1 h-3 w-0.5 rotate-[50deg] rounded bg-accent-500" /></span>
            </span>
            <h1 className="text-[28px] font-extrabold leading-[1.15] tracking-[-0.02em] text-brand-700 md:text-[38px]">Khởi đầu vững vàng – <span className="text-accent-500">Kinh doanh bền lâu</span></h1>
            <p className="text-[15px] leading-6 text-ink-2">Các khóa học thực chiến, dễ hiểu, đồng hành cùng bạn từ những bước đầu tiên đến khi mở quán thành công.</p>
          </div>
        </div>
        <Suspense><PackageGrid /></Suspense>
        <p className="rounded-2xl bg-accent-100 px-5 py-4 text-center text-[14.5px] text-ink-2">
          Chưa chắc nên chọn gói nào? <a href="/#von" className="font-bold text-accent-600 underline underline-offset-2">Chọn mô hình của bạn</a> để được gợi ý, hoặc gọi <a href={SITE.hotlineTel} className="font-bold text-brand-600">{SITE.hotline}</a>.
        </p>
      </section>

      <PackageCompare />

      <section id="khoa-le" className="flex scroll-mt-24 flex-col gap-6 border-t border-line pt-12">
        <div className="flex flex-col gap-1.5">
          <span className="eyebrow">KHÓA LẺ THEO CHUYÊN ĐỀ</span>
          <h2 className="text-[22px] font-extrabold text-brand-700 md:text-[26px]">Chỉ cần thêm một món? Mua khóa lẻ</h2>
          <p className="text-[15px] text-muted">Phù hợp khi bạn đã có quán và muốn bổ sung chuyên đề vào menu.</p>
        </div>
        <Suspense><CourseCatalog /></Suspense>
      </section>
    </div>
  );
}
