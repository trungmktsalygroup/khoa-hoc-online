import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { PackageDetail } from '@/components/courses/PackageDetail';
import { PACKAGES } from '@/data/packages';
import { SITE } from '@/data/site';
import { FAQS } from '@/data/home';
import { JsonLd } from '@/components/shared/JsonLd';
import { abs, breadcrumb, faqPage, ORG_ID } from '@/lib/schema';

export function generateStaticParams() { return PACKAGES.map((p) => ({ slug: p.slug })); }

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params;
  const p = PACKAGES.find((x) => x.slug === slug);
  return p ? { title: p.name, description: `${p.focus} Học xong: ${p.outcomes.slice(0, 2).join('; ')}.`, openGraph: { images: [p.image] } } : {};
}

export default async function PackagePage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const p = PACKAGES.find((x) => x.slug === slug);
  if (!p) notFound();
  const ld = {
    '@context': 'https://schema.org', '@type': 'Course', name: p.name, description: p.focus,
    provider: { '@type': 'EducationalOrganization', '@id': ORG_ID, name: SITE.name, sameAs: SITE.url },
    url: abs(`/khoa-hoc/${p.slug}`), image: abs(p.image), inLanguage: 'vi',
    teaches: p.outcomes,
    hasCourseInstance: { '@type': 'CourseInstance', courseMode: 'Online', courseWorkload: 'Tự học theo video, học trọn đời' },
    offers: { '@type': 'Offer', price: p.dealPrice ?? p.price, priceCurrency: 'VND', category: 'Paid', url: abs(`/khoa-hoc/${p.slug}`), availability: 'https://schema.org/InStock' },
  };
  return (
    <>
      <JsonLd data={[ld, breadcrumb([{ name: 'Trang chủ', path: '/' }, { name: 'Khóa học', path: '/khoa-hoc' }, { name: p.name, path: `/khoa-hoc/${p.slug}` }]), faqPage(FAQS)]} />
      <PackageDetail p={p} />
    </>
  );
}
