import type { MetadataRoute } from 'next';
import { ALL_POSTS } from '@/data/blog';
import { SITE } from '@/data/site';
import { PACKAGES } from '@/data/packages';

export default function sitemap(): MetadataRoute.Sitemap {
  const pages = ['', '/khoa-hoc', '/cong-cu', '/hoat-dong', '/blog', '/author/ly-pham'];
  return [
    ...pages.map((p) => ({ url: `${SITE.url}${p}`, changeFrequency: 'weekly' as const, priority: p === '' ? 1 : 0.8 })),
    ...PACKAGES.map((p) => ({ url: `${SITE.url}/khoa-hoc/${p.slug}`, changeFrequency: 'weekly' as const, priority: 0.9 })),
    ...ALL_POSTS.map((p) => ({ url: `${SITE.url}/blog/${p.slug}`, changeFrequency: 'monthly' as const, priority: 0.6 })),
  ];
}
