import type { ReactNode } from 'react';
/*
 * Bài kiến thức (SEO / AEO): "Mở quán cà phê, trà sữa cần bao nhiêu vốn?"
 * Mức vốn theo chính sách tư vấn của SaLy Academy (4 mô hình). Trang bán khóa học KHÔNG công khai vốn
 * (theo Insight học viên) – bài kiến thức này trả lời câu hỏi tìm kiếm rồi dẫn người đọc về "chọn đúng mô hình".
 * TODO: đội đào tạo duyệt nội dung trước khi đăng.
 */
import Image from 'next/image';
import Link from 'next/link';
import { PACKAGES } from '@/data/packages';
import { CheckCircle, Icon } from '@/components/ui/Icon';
import type { ArticleContent } from './types';

const P = 'text-base leading-[28px] text-[#2E2A26] md:text-[17px] md:leading-[30px]';
const H2 = 'scroll-mt-24 pt-4 text-[21px] font-extrabold leading-8 tracking-tight text-brand-700 md:text-[25px]';
const A = 'font-semibold text-brand-600 underline decoration-brand-600/30 underline-offset-2 hover:decoration-brand-600';

function Note({ title = 'Lưu ý', children }: { title?: string; children: ReactNode }) {
  return (
    <aside className="flex gap-3 rounded-[14px] bg-accent-100 px-5 py-4">
      <Icon name="bulb" size={22} className="mt-0.5 shrink-0 text-accent-700" />
      <div className="flex flex-col gap-1"><strong className="text-[15px] text-accent-700">{title}</strong><span className="text-[15px] leading-[25px] text-ink-2">{children}</span></div>
    </aside>
  );
}

/** Vốn tham khảo theo mô hình – cùng thứ tự với PACKAGES */
const MODELS: { fit: string; menu: string }[] = [
  { fit: 'Người mới, muốn thử sức với vốn nhỏ; bán mang đi ở khu dân cư, gần trường học, khu công nghiệp.', menu: 'Vài nhóm món chủ lực: trà trái cây, trà sữa, topping.' },
  { fit: 'Muốn chỉn chu hơn xe đẩy nhưng chưa cần chỗ ngồi; bán mang đi và bán Online.', menu: 'Trà trái cây, cà phê, matcha, trà sữa đậm vị.' },
  { fit: 'Có hoặc đang tìm mặt bằng có chỗ ngồi; chú trọng trải nghiệm của khách.', menu: 'Menu phong phú hơn, thường thêm nước ép.' },
  { fit: 'Đầu tư nghiêm túc, quy mô lớn, cần đội ngũ và quy trình bài bản.', menu: 'Menu đầy đủ: trà, cà phê, matcha, đá xay, sinh tố, sữa chua…' },
];

const COSTS: [string, string][] = [
  ['Mặt bằng:', 'tiền cọc và tiền thuê những tháng đầu – thường là khoản lớn nhất với quán có chỗ ngồi.'],
  ['Cải tạo, thi công:', 'quầy pha chế, điện nước, bảng hiệu, trang trí, bàn ghế.'],
  ['Máy móc, dụng cụ:', 'máy pha cà phê, máy xay, tủ mát, bình ủ trà, shaker, dụng cụ đong…'],
  ['Nguyên liệu ban đầu:', 'trà, cà phê, sữa, syrup, trái cây, topping, ly và bao bì.'],
  ['Giấy phép, thủ tục:', 'đăng ký hộ kinh doanh, an toàn thực phẩm, thuế.'],
  ['Marketing khai trương:', 'chương trình khai trương, ảnh món, quảng cáo, đăng ký các app giao đồ ăn.'],
  ['Vốn dự phòng:', 'chi phí vận hành vài tháng đầu khi doanh thu chưa ổn định.'],
];

export const FAQ_VON: [string, string][] = [
  ['Mở quán cà phê nhỏ cần bao nhiêu vốn?', 'Theo kinh nghiệm tư vấn của SaLy Academy, xe trà hoặc quầy nhỏ bán mang đi cần khoảng 50–70 triệu đồng; quán Coffee & Tea bán mang đi khoảng 100–200 triệu đồng. Con số thực tế phụ thuộc nhiều nhất vào mặt bằng và khu vực.'],
  ['Mở quán cà phê có chỗ ngồi cần bao nhiêu vốn?', 'Quán Coffee & Tea có không gian ngồi lại thường cần khoảng 300–500 triệu đồng, vì phát sinh thêm chi phí mặt bằng rộng hơn, thi công, bàn ghế và trang trí.'],
  ['Chi phí nào chiếm nhiều nhất khi mở quán?', 'Với quán có chỗ ngồi, mặt bằng và thi công thường là khoản lớn nhất. Với xe trà hay quầy nhỏ, máy móc, dụng cụ và nguyên liệu ban đầu chiếm phần lớn vốn.'],
  ['Có nên để lại vốn dự phòng không?', 'Nên. Vài tháng đầu doanh thu thường chưa ổn định, vốn dự phòng giúp quán duy trì nhân sự, nguyên liệu và marketing mà không phải đóng cửa sớm.'],
  ['Chưa biết pha chế có mở quán được không?', 'Được. Nhiều học viên SaLy Academy bắt đầu từ con số 0. Quan trọng là chọn đúng mô hình với số vốn, học đúng nhóm món cần bán và có kế hoạch mở quán trước khi bỏ tiền.'],
];

export const MO_QUAN_VON: ArticleContent = {
  lead: 'Vốn mở quán cà phê, trà sữa dao động rất rộng: từ vài chục triệu cho một xe trà đến vài trăm triệu cho quán có chỗ ngồi. Câu hỏi đúng không phải "cần bao nhiêu tiền" mà là "với số vốn mình có, nên mở mô hình nào".',
  updated: '06/10/2026',
  tags: ['vốn mở quán', 'mở quán cà phê', 'khởi nghiệp F&B', 'chọn mô hình quán'],
  quickAnswer: [
    'Xe trà, quầy nhỏ bán mang đi: khoảng 50–70 triệu đồng.',
    'Quán Coffee & Tea bán mang đi: khoảng 100–200 triệu đồng.',
    'Quán Coffee & Tea có chỗ ngồi: khoảng 300–500 triệu đồng; quy mô lớn, đầu tư bài bản: từ 500 triệu đồng.',
    'Mặt bằng và khu vực là yếu tố làm vốn chênh lệch nhiều nhất – luôn giữ lại một phần vốn dự phòng.',
  ],
  faq: FAQ_VON,
  packageSlug: 'coffee-tea-mang-di',
  toc: [
    ['bang-von', '1. Vốn mở quán theo từng mô hình'],
    ['khoan-chi', '2. Vốn mở quán gồm những khoản nào?'],
    ['chon-mo-hinh', '3. Chọn mô hình theo vốn, không chọn vốn theo mô hình'],
    ['hoi-dap', '4. Câu hỏi thường gặp'],
  ],
  Body: () => (
    <>
      <h2 id="bang-von" className={H2}>1. Vốn mở quán cà phê, trà sữa theo từng mô hình</h2>
      <p className={P}>Bảng dưới là mức vốn tham khảo SaLy Academy dùng khi tư vấn cho học viên, chia theo 4 mô hình quán phổ biến.</p>
      <div className="overflow-x-auto rounded-[14px] border border-line">
        <table className="w-full min-w-[560px] text-left text-[15px]">
          <caption className="sr-only">Vốn mở quán tham khảo theo mô hình</caption>
          <thead className="bg-brand-600 text-white"><tr><th scope="col" className="px-4 py-3 font-bold">Mô hình</th><th scope="col" className="px-4 py-3 font-bold">Vốn tham khảo</th><th scope="col" className="px-4 py-3 font-bold">Phù hợp với</th></tr></thead>
          <tbody className="divide-y divide-line bg-white">
            {PACKAGES.map((p, i) => (
              <tr key={p.slug} className={i % 2 ? 'bg-mint/60' : ''}>
                <th scope="row" className="px-4 py-3 font-bold text-brand-700">{p.short}</th>
                <td className="whitespace-nowrap px-4 py-3 font-bold text-accent-600">{p.capital} đồng</td>
                <td className="px-4 py-3 text-ink-2">{MODELS[i].fit}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <Note>Đây là mức tham khảo. Cùng một mô hình, quán ở trung tâm thành phố có thể cần vốn gấp nhiều lần quán ở khu dân cư vì giá thuê mặt bằng.</Note>

      <div className="grid gap-4 sm:grid-cols-2">
        {PACKAGES.map((p, i) => (
          <figure key={p.slug} className="flex flex-col overflow-hidden rounded-[16px] border border-line bg-white">
            <Image src={p.image} alt={`Mô hình ${p.short} của học viên SaLy Academy`} width={560} height={360} sizes="(max-width: 640px) 100vw, 380px" className="aspect-[16/10] w-full object-cover" />
            <figcaption className="flex flex-col gap-1 p-4">
              <span className="text-[12px] font-extrabold uppercase tracking-wide text-accent-600">{p.capital}</span>
              <strong className="text-[16px] text-brand-700">{p.short}</strong>
              <span className="text-[14px] leading-[22px] text-ink-2">{MODELS[i].menu}</span>
            </figcaption>
          </figure>
        ))}
      </div>

      <h2 id="khoan-chi" className={H2}>2. Vốn mở quán gồm những khoản nào?</h2>
      <p className={P}>Dù mở mô hình nào, số vốn cũng chia vào các nhóm chi phí dưới đây. Liệt kê đủ từ đầu giúp bạn không bị "đội vốn" khi đã lỡ ký mặt bằng.</p>
      <ul className="flex flex-col gap-3">
        {COSTS.map(([b, t]) => <li key={b} className="flex gap-2.5 text-base leading-[27px] md:text-[17px]"><CheckCircle /><span><strong>{b}</strong> {t}</span></li>)}
      </ul>

      <h2 id="chon-mo-hinh" className={H2}>3. Chọn mô hình theo vốn, không chọn vốn theo mô hình</h2>
      <p className={P}>Sai lầm thường gặp là thích một quán đẹp rồi cố gom đủ tiền để mở giống vậy. Cách an toàn hơn: bắt đầu từ số vốn thật bạn có (sau khi trừ dự phòng), chọn mô hình vừa với số đó, rồi học đúng nhóm món mô hình đó cần bán.</p>
      <ol className="flex flex-col gap-4">
        {[
          ['Tính vốn thật', 'Cộng tiền mặt sẵn có, trừ đi phần dự phòng cho vài tháng đầu.'],
          ['Chọn mô hình vừa vốn', 'Đối chiếu với bảng ở trên, chọn mô hình nằm trong tầm vốn.'],
          ['Học đúng nhóm món', 'Mỗi mô hình cần một menu khác nhau – không cần học hết mọi chuyên đề.'],
          ['Lập kế hoạch trước khi chi', 'Dự trù máy móc, nguyên liệu, giá bán và mốc khai trương trước khi ký mặt bằng.'],
        ].map(([t, d], i) => (
          <li key={t} className="flex gap-4">
            <span className="flex size-9 shrink-0 items-center justify-center rounded-full bg-accent-500 text-[15px] font-extrabold text-white">{i + 1}</span>
            <div className="flex flex-col gap-1 pt-1"><strong className="text-[17px] text-brand-700">{t}</strong><p className={P}>{d}</p></div>
          </li>
        ))}
      </ol>
      <p className={P}>Chưa chắc mô hình nào hợp với mình? Xem <Link href="/khoa-hoc" className={A}>các khóa học theo mô hình quán</Link> hoặc dùng <Link href="/cong-cu" className={A}>công cụ tính chi phí miễn phí</Link> của SaLy Academy.</p>

      <h2 id="hoi-dap" className={H2}>4. Câu hỏi thường gặp về vốn mở quán</h2>
      <div className="flex flex-col gap-2.5">
        {FAQ_VON.map(([q, a], i) => (
          <details key={q} open={i === 0} className="group rounded-2xl border border-line bg-white px-5 py-1 open:border-brand-600">
            <summary className="flex min-h-14 cursor-pointer items-center justify-between gap-3 text-[16px] font-bold text-brand-700">{q}<Icon name="chevronDown" size={18} className="shrink-0 transition-transform group-open:rotate-180" /></summary>
            <p className="pb-4 text-[15px] leading-[26px] text-ink-2">{a}</p>
          </details>
        ))}
      </div>
    </>
  ),
};
