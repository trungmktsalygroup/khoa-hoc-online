import type { ReactNode } from 'react';
/* Nội dung bài viết – nguồn: https://lypham.vn/tra-quyt-tuoi/ (Ly Phạm – Dạy Pha Chế) */
import Image from 'next/image';
import Link from 'next/link';
import { YouTubeLite } from '@/components/shared/YouTubeLite';
import { CheckCircle, Icon } from '@/components/ui/Icon';
import type { ArticleContent } from './types';

const IMG = '/images/blog/tra-quyt-tuoi/';
const P = 'text-base leading-[28px] text-[#2E2A26] md:text-[17px] md:leading-[30px]';
const H2 = 'scroll-mt-24 pt-4 text-[21px] font-extrabold leading-8 tracking-tight text-brand-700 md:text-[25px]';
const H3 = 'scroll-mt-24 pt-1 text-[18px] font-bold leading-7 text-brand-700 md:text-[19px]';
const A = 'font-semibold text-brand-600 underline decoration-brand-600/30 underline-offset-2 hover:decoration-brand-600';

function Figure({ src, alt, w = 800, h = 700 }: { src: string; alt: string; w?: number; h?: number }) {
  return (
    <figure className="flex flex-col gap-2">
      <Image src={IMG + src} alt={alt} width={w} height={h} sizes="(max-width: 768px) 100vw, 780px" className="h-auto w-full rounded-[14px]" />
      <figcaption className="text-center text-[13px] text-muted">{alt}</figcaption>
    </figure>
  );
}
function Note({ title = 'Lưu ý', children }: { title?: string; children: ReactNode }) {
  return (
    <aside className="flex gap-3 rounded-[14px] bg-accent-100 px-5 py-4">
      <Icon name="bulb" size={22} className="mt-0.5 shrink-0 text-accent-700" />
      <div className="flex flex-col gap-1"><strong className="text-[15px] text-accent-700">{title}</strong><span className="text-[15px] leading-[25px] text-ink-2">{children}</span></div>
    </aside>
  );
}
function Bullets({ items }: { items: [string, string][] }) {
  return (
    <ul className="flex flex-col gap-3">
      {items.map(([b, t]) => <li key={b} className="flex gap-2.5 text-base leading-[27px] md:text-[17px]"><CheckCircle /><span><strong>{b}</strong> {t}</span></li>)}
    </ul>
  );
}

const FAQ: [string, string][] = [
  ['Trà quýt tươi có dễ bán không khi kinh doanh quán?', 'Có. Trà quýt tươi có vị chua ngọt thanh mát, hương quýt tự nhiên và dễ uống, phù hợp với nhiều nhóm khách hàng, đặc biệt được ưa chuộng vào những ngày nóng. Nguyên liệu dễ chuẩn bị, quy trình đơn giản và thời gian phục vụ nhanh giúp quán dễ kiểm soát chi phí khi đưa món vào menu.'],
  ['Có thể dùng trà xanh thay trà đen khi pha trà quýt được không?', 'Có thể. Trà đen có vị đậm, cân bằng tốt với vị chua ngọt của quýt; trà xanh cho vị thanh nhẹ, dễ uống. Bạn cũng có thể thử hồng trà hoặc loại trà khác để tạo hương vị riêng, nhưng cần điều chỉnh định lượng để trà và quýt không lấn át nhau.'],
  ['Thay syrup đường bằng mật ong có ảnh hưởng gì không?', 'Bạn hoàn toàn có thể thay. Mật ong tạo vị ngọt dịu và hương thơm đặc trưng, giúp ly trà khác biệt. Tuy nhiên mật ong có mùi khá rõ, nên cho từ từ, nếm và cân chỉnh đến khi độ ngọt vừa và không lấn hương quýt.'],
  ['Trà quýt tươi nên kết hợp với topping nào ngon?', 'Các topping vị thanh nhẹ như thạch dừa, nha đam, trân châu trắng hợp với trà quýt. Có thể thêm tép quýt ngâm để tăng hương thơm. Dùng topping vừa phải để không lấn át vị trà và quýt.'],
  ['Có thể chuẩn bị sẵn nguyên liệu trà quýt để bán không?', 'Có. Chuẩn bị sẵn trà đen, nước quýt ngâm và syrup đường, bảo quản riêng trong hộp/chai kín ở ngăn mát. Khi có khách chỉ cần dằm quýt ngâm, thêm tắc tươi, cho vào shaker cùng đá và lắc đều – rất hợp quán đông khách hoặc mô hình take-away.'],
];

export const TRA_QUYT_TUOI: ArticleContent = {
  lead: 'Trà quýt tươi là món trà trái cây nổi bật với hương thơm tự nhiên của quýt tươi và vị trà đen đậm đà, chua ngọt hài hòa, thanh mát và dễ uống.',
  source: 'https://lypham.vn/tra-quyt-tuoi/',
  quickAnswer: [
    'Ly 500ml: 100ml trà đen, 50ml nước sốt ngâm quýt, 20ml syrup đường, 2 trái tắc, 1/2 trái quýt ngâm dằm – lắc shaker với đá 8–10 giây.',
    'Giá cost nguyên liệu khoảng 6.700đ/ly 500ml và 7.600đ/ly 700ml; giá bán tham khảo 22.000–35.000đ.',
    'Nước quýt ngâm để ngăn mát, dùng trong 3–5 ngày; dằm quýt nhẹ tay để không đắng vỏ.',
  ],
  faq: FAQ,
  packageSlug: 'coffee-tea-mang-di',
  tags: ['trà quýt', 'trà trái cây', 'công thức pha chế', 'giá cost'],
  toc: [
    ['cong-thuc', '1. Công thức pha trà quýt tươi chuẩn vị'],
    ['nguyen-lieu', '1.1 Nguyên liệu chuẩn bị'],
    ['cac-buoc', '1.2 Các bước pha chi tiết'],
    ['meo', '2. Mẹo pha giữ vị chuẩn, thu hút khách'],
    ['gia-cost', '3. Tính giá cost 1 ly trà quýt'],
    ['hoi-dap', '4. Câu hỏi thường gặp'],
    ['khoa-hoc', '5. Khóa học Trà trái cây Online'],
    ['loi-ket', '6. Lời kết'],
  ],
  Body: () => (
    <>
      <p className={P}>Đặc biệt, hương tinh dầu nhẹ từ quýt giúp món trà thêm hấp dẫn, hợp khẩu vị nhiều khách hàng. Trong bài viết này, <strong>Ly Phạm – Dạy Pha Chế</strong> chia sẻ công thức pha trà quýt tươi đơn giản, dễ làm và phù hợp để kinh doanh: nguyên liệu dễ chuẩn bị, pha nhanh và kiểm soát cost tốt – đáng cân nhắc cho quán cà phê, trà sữa và mô hình take-away.</p>

      <h2 id="cong-thuc" className={H2}>1. Cách pha trà quýt tươi thơm ngon, công thức chuẩn vị cho quán</h2>
      <p className={P}>Để có ly trà quýt chua ngọt hài hòa và đậm vị trà, bạn cần cân đối nguyên liệu và làm đúng từng bước.</p>

      <h3 id="nguyen-lieu" className={H3}>1.1 Nguyên liệu chuẩn bị để pha trà quýt tươi chuẩn vị</h3>
      <p className={P}>Định lượng dưới đây được cân đối cho cả ly 500ml và 700ml, tiện áp dụng thực tế.</p>
      <div className="overflow-x-auto rounded-[14px] border border-line">
        <table className="w-full min-w-[420px] text-left text-[15px]">
          <thead className="bg-brand-600 text-white"><tr><th className="px-4 py-3 font-bold">Thành phần</th><th className="px-4 py-3 font-bold">Ly 500ml</th><th className="px-4 py-3 font-bold">Ly 700ml</th></tr></thead>
          <tbody className="divide-y divide-line bg-white">
            {[['Trà đen cao cấp Phúc Sang', '100ml', '150ml'], ['Nước sốt ngâm quýt', '50ml', '70ml'], ['Syrup đường', '20ml', '30ml'], ['Tắc tươi', '2 trái', '3 trái'], ['Quýt ngâm dằm', '1/2 trái', '1/2 trái'], ['Quýt ngâm trang trí', '1/2 trái', '1/2 trái']].map(([a, b, c], i) => (
              <tr key={a} className={i % 2 ? 'bg-mint/60' : ''}><td className="px-4 py-2.5 font-medium">{i === 0 ? <a href="https://traphucsang.vn/tra-den-phuc-sang-500g/" className={A}>{a}</a> : a}</td><td className="px-4 py-2.5">{b}</td><td className="px-4 py-2.5">{c}</td></tr>
            ))}
          </tbody>
        </table>
      </div>
      <Note>Nên dùng trà đen vị đậm để cân bằng vị ngọt và chua của nước quýt. Quýt ngâm cần chuẩn bị trước để hương vị ổn định và màu sắc đẹp khi pha.</Note>
      <Figure src="nguyen-lieu-chuan-bi-de-pha-tra-quyt-tuoi.jpg" alt="Nguyên liệu chuẩn bị để pha trà quýt tươi chuẩn vị" />

      <h3 id="cac-buoc" className={H3}>1.2 Các bước pha trà quýt tươi chi tiết cho người mới bắt đầu</h3>
      <ol className="flex flex-col gap-5">
        {[
          ['Chuẩn bị nguyên liệu', ['Ủ trà đen Phúc Sang đúng thời gian, lọc sạch xác trà và để nguội hoàn toàn. Ly 500ml dùng khoảng 100ml trà, ly 700ml khoảng 150ml để hương trà vẫn đủ đậm khi kết hợp quýt.', 'Quýt ngâm chuẩn bị trước để tép mềm, thấm vị, ngọt thanh. Khi pha chỉ dằm nhẹ để tinh dầu và nước quýt hòa vào thức uống – dằm mạnh tay vỏ quýt dễ tiết vị đắng.']],
          ['Pha trà quýt', ['Với ly 500ml, cho vào bình shaker: 100ml trà đen đã nguội, 20ml syrup đường, 50ml nước sốt ngâm quýt và 1/2 trái quýt ngâm dằm nhẹ; vắt thêm 2 trái tắc tươi để tăng vị chua và hương thơm.', 'Cho đá đầy bình, đậy kín và lắc đều 8–10 giây để tạo bọt nhẹ và dậy mùi thơm.']],
          ['Hoàn thiện và trang trí', ['Rót toàn bộ ra ly phục vụ. Trang trí 1/2 trái quýt ngâm cắt lát hoặc để nguyên múi, thêm một nhánh lá húng lủi tươi cho hương thơm nhẹ.', 'Có thể thêm vài tép quýt ngâm vào ly. Thành phẩm chua ngọt hài hòa, hương quýt nổi bật, hậu trà thanh nhẹ.']],
        ].map(([t, ps], i) => (
          <li key={t as string} className="flex gap-4">
            <span className="flex size-9 shrink-0 items-center justify-center rounded-full bg-accent-500 text-[15px] font-extrabold text-white">{i + 1}</span>
            <div className="flex flex-col gap-2 pt-1">
              <strong className="text-[17px] text-brand-700">Bước {i + 1}: {t as string}</strong>
              {(ps as string[]).map((x) => <p key={x} className={P}>{x}</p>)}
            </div>
          </li>
        ))}
      </ol>
      <Note>Pha ly 700ml thì điều chỉnh trà, syrup, nước sốt ngâm quýt và tắc theo bảng nguyên liệu ở trên.</Note>
      <figure className="flex flex-col gap-2">
        <YouTubeLite id="zr1KP-jbe6E" title="Video hướng dẫn cách làm trà quýt tươi thơm ngon, chuẩn vị và hút khách" thumb={IMG + 'video-zr1KP-jbe6E.jpg'} />
        <figcaption className="text-center text-[13px] text-muted">Video hướng dẫn cách làm trà quýt tươi thơm ngon, chuẩn vị và hút khách</figcaption>
      </figure>

      <h2 id="meo" className={H2}>2. Mẹo pha trà quýt thơm ngon, giữ vị chuẩn để thu hút khách</h2>
      <Bullets items={[
        ['Dằm quýt nhẹ tay:', 'chỉ lấy nước và tinh dầu thơm từ tép quýt; dằm mạnh vỏ quýt tiết vị đắng.'],
        ['Lắc shaker đủ thời gian:', 'khoảng 8–10 giây là đủ lạnh đều, không làm trà loãng hay mất vị.'],
        ['Vắt tắc ngay trước khi pha:', 'giữ trọn hương thơm và vị chua tươi mới.'],
        ['Bảo quản nước quýt ngâm đúng cách:', 'để ngăn mát và dùng trong khoảng 3–5 ngày.'],
        ['Điều chỉnh linh hoạt:', 'tăng giảm syrup hoặc nước quýt theo khẩu vị khách, nhưng luôn giữ nền trà đen đậm.'],
        ['Trang trí bắt mắt:', 'quýt ngâm nguyên múi hoặc lát cắt đẹp cùng lá húng lủi tươi giúp ly trà hấp dẫn hơn.'],
      ]} />
      <Figure src="meo-pha-tra-quyt-thom-ngon-giu-vi-chuan.jpg" alt="Mẹo pha trà quýt thơm ngon, giữ vị chuẩn để thu hút khách" />

      <h2 id="gia-cost" className={H2}>3. Công thức tính giá cost 1 ly trà quýt tối ưu lợi nhuận cho quán</h2>
      <p className={P}>Tính đúng <a href="https://lypham.vn/gia-cost-la-gi/" className={A}>giá cost</a> giúp quán kiểm soát chi phí nguyên liệu và đặt giá bán phù hợp.</p>
      <div className="grid gap-3 sm:grid-cols-2">
        {[['Ly 500ml', '6.700đ', '22.000 – 28.000đ'], ['Ly 700ml', '7.600đ', '28.000 – 35.000đ']].map(([s, c, p]) => (
          <div key={s} className="flex flex-col gap-2 rounded-2xl border border-line bg-white p-5">
            <span className="text-[13px] font-extrabold tracking-wide text-accent-600">{s.toUpperCase()}</span>
            <div className="flex items-baseline justify-between"><span className="text-[14px] text-muted">Giá cost nguyên liệu</span><strong className="text-[20px] text-brand-700">~{c}</strong></div>
            <div className="flex items-baseline justify-between"><span className="text-[14px] text-muted">Giá bán tham khảo</span><strong className="text-[16px] text-accent-600">{p}</strong></div>
          </div>
        ))}
      </div>
      <Note>Giá bán chỉ mang tính tham khảo. Khi chốt giá, cộng thêm chi phí bao bì, mặt bằng, nhân công, điện nước, marketing và các chi phí vận hành khác.</Note>
      <Figure src="cong-thuc-tinh-gia-cost-1-ly-tra-quyt.jpg" alt="Công thức tính giá cost 1 ly trà quýt tối ưu lợi nhuận cho quán" />

      <h2 id="hoi-dap" className={H2}>4. Một số câu hỏi thường gặp khi pha trà quýt tươi để kinh doanh</h2>
      <div className="flex flex-col gap-2.5">
        {FAQ.map(([q, a], i) => (
          <details key={q} open={i === 0} className="group rounded-2xl border border-line bg-white px-5 py-1 open:border-brand-600">
            <summary className="flex min-h-14 cursor-pointer items-center justify-between gap-3 text-[16px] font-bold text-brand-700">{q}<Icon name="chevronDown" size={18} className="shrink-0 transition-transform group-open:rotate-180" /></summary>
            <p className="pb-4 text-[15px] leading-[26px] text-ink-2">{a}</p>
          </details>
        ))}
      </div>

      <h2 id="khoa-hoc" className={H2}>5. Nâng tầm kỹ năng với khóa học Trà trái cây Online</h2>
      <p className={P}>Muốn bổ sung món trà trái cây dễ bán vào menu nhưng không có thời gian học trực tiếp? <Link href="/khoa-hoc" className={A}>Khóa học Trà trái cây Online</Link> tại SaLy Academy có hơn 70 video bài học, 50+ công thức và tài khoản học trọn đời, đi từ kiến thức nền đến thực hành để áp dụng ngay vào menu.</p>
      <Figure src="chuyen-de-pha-che-tra-trai-cay-hot-trend.jpg" alt="Nâng tầm kỹ năng với khóa học trà trái cây tại Ly Phạm – Dạy Pha Chế" w={1000} h={707} />
      <Bullets items={[
        ['Giáo trình bài bản:', 'từ ủ trà, sơ chế, bảo quản trái cây đến hoàn thiện một ly trà trái cây.'],
        ['Kho công thức đa dạng:', '50+ công thức trà nhiệt đới, trà dâu, trà đào cam sả, trà tắc…'],
        ['Chọn và xử lý nguyên liệu:', 'dùng trái cây tươi, mứt, syrup phù hợp và tối ưu chi phí.'],
        ['Kiến thức gắn với kinh doanh:', 'tính cost, xây giá bán, chọn món phù hợp định hướng menu.'],
        ['Cập nhật công thức hot trend', 'để menu luôn bắt kịp nhu cầu khách.'],
        ['Học trọn đời, có hỗ trợ:', 'video HD, xem lại không giới hạn, hỏi đáp qua CSKH, Zalo và cộng đồng học viên.'],
      ]} />

      <h2 id="loi-ket" className={H2}>6. Lời kết</h2>
      <p className={P}>Với công thức đơn giản, nguyên liệu dễ chuẩn bị và vị chua ngọt thanh mát, <strong>trà quýt tươi</strong> là lựa chọn đáng thêm vào menu. Chỉ cần đúng định lượng và đúng các bước, bạn sẽ có ly trà thơm ngon, đồng đều và dễ chinh phục khách. Đừng quên theo dõi để cập nhật thêm nhiều công thức pha chế thực tế cho quán nhé!</p>
    </>
  ),
};
