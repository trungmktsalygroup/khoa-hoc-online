import type { ArticleContent } from './types';
import { TRA_QUYT_TUOI } from './tra-quyt-tuoi';
import { MO_QUAN_VON } from './mo-quan-can-bao-nhieu-von';

export const ARTICLES: Record<string, ArticleContent> = {
  'tra-quyt-tuoi': TRA_QUYT_TUOI,
  'mo-quan-ca-phe-can-bao-nhieu-von': MO_QUAN_VON,
};
