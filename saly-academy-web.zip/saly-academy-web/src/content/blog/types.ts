import type { ComponentType } from 'react';

/** Nội dung bài viết soạn sẵn. Khi nối CMS, Dev thay bằng dữ liệu từ CMS (Markdown / rich text). */
export type ArticleContent = {
  lead: string;
  toc: [id: string, label: string][];
  tags: string[];
  source?: string;
  /** Trả lời nhanh (2–4 ý) ngay dưới tiêu đề – cho người đọc vội, Google và trợ lý AI trích dẫn */
  quickAnswer?: string[];
  /** Câu hỏi thường gặp – hiển thị trong bài và xuất dữ liệu FAQPage */
  faq?: [q: string, a: string][];
  /** Ngày cập nhật gần nhất (dd/mm/yyyy) */
  updated?: string;
  /** Gói khóa học phù hợp để gợi ý cuối bài (slug trong src/data/packages.ts) */
  packageSlug?: string;
  Body: ComponentType;
};
