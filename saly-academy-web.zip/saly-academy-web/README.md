# SaLy Academy Web

Website **SaLy Academy – Ly Phạm Dạy Pha Chế**, viết bằng **Next.js 15 (App Router) + React 19 + TypeScript + Tailwind CSS 4**.
Giao diện responsive một bộ code cho cả Desktop và Mobile (điểm ngắt chính: 768px).

## Chạy thử

```bash
npm install
cp .env.example .env.local   # điền LEAD_WEBHOOK_URL nếu muốn nhận form về n8n
npm run dev                   # http://localhost:3000
```

Build production:

```bash
npm run build && npm start
```

Tạo **1 file HTML xem thử** (gửi link test, không cần máy chủ – chạy chính code trong `src/`):

```bash
npm run preview:file   # → preview-dist/saly-academy-preview.html
```

Yêu cầu Node.js ≥ 18.18 (khuyên dùng Node 22 – xem `.nvmrc`).

## Các trang

| Đường dẫn | Trang |
|---|---|
| `/` | Trang chủ (người chưa có quán): chọn số vốn → mô hình gợi ý, lộ trình, khóa nổi bật, câu hỏi thường gặp, form tư vấn |
| `/khoa-hoc` | Gói khóa học theo mô hình + bảng so sánh; khóa lẻ theo chuyên đề (bộ lọc, sắp xếp) |
| `/khoa-hoc/[gói]` | Trang thông tin khóa học của từng gói (4 gói theo mô hình) |
| `/hoc/[slug]` | Trang học Online: video, tiến độ, danh sách bài, tab Mô tả/Tài liệu/Hỏi đáp |
| `/cong-cu` | Công cụ cho chủ quán: tính nhanh giá vốn 1 ly, danh sách công cụ |
| `/hoat-dong` | Hoạt động: tin nhanh, bài đăng, video ngắn + trình xem dọc kiểu TikTok |
| `/blog`, `/blog/[slug]` | Blog và bài viết (mục lục, Author bio, bài liên quan, dữ liệu có cấu trúc Article) |
| `/author/ly-pham` | Trang tác giả Cô Ly Phạm: hành trình, sách, sự kiện, bài viết, form tư vấn (link cũ `/giang-vien-ly-pham` chuyển hướng về đây) |
| `/dang-nhap` | Đăng nhập / Đăng ký (`?che-do=dang-ky` mở thẳng tab Đăng ký) |
| `/thanh-toan` | Giỏ hàng & thanh toán: danh sách khóa, mã giảm giá, thông tin người học, chọn phương thức, màn hình hoàn tất |
| `/api/lead` | Nhận form tư vấn → chuyển tiếp về webhook n8n |

Menu: Trang chủ · Khóa học · Công cụ · Hoạt động · Blog · Về Cô Ly Phạm — Giỏ hàng · Hotline 0964 220 098 · Đăng nhập · Học thử miễn phí.

## Cấu trúc

```
src/
├── app/
│   ├── (site)/          # Trang có header + footer
│   ├── (auth)/          # Đăng nhập (chỉ header)
│   ├── (learn)/         # Trang học (header học viên)
│   ├── api/lead/        # API nhận form
│   ├── globals.css      # Design tokens (@theme) + lớp dùng chung
│   ├── sitemap.ts, robots.ts, not-found.tsx
├── components/          # site/ ui/ shared/ home/ courses/ tools/ activity/ blog/ auth/ learn/
├── data/                # Nội dung mẫu: site, courses, lessons, tools, blog, activity, home
└── lib/format.ts        # Định dạng tiền, % giảm, ảnh ghép video
public/images/           # Ảnh (logo, ảnh Cô Ly tách nền, sách, khóa học, sự kiện…)
docs/                    # Hướng dẫn Dev + ảnh chụp màn hình
```

Toàn bộ nội dung đang nằm trong `src/data/*.ts`. Khi nối CMS/API chỉ cần thay nguồn dữ liệu, không phải sửa giao diện.

## Sửa nội dung nhanh

| Muốn sửa | Mở file |
|---|---|
| Hotline, email, số liệu (8+ năm, 6.000+ học viên…), link app, thông tin chuyển khoản | `src/data/site.ts` |
| Câu hỏi thường gặp, học viên tiêu biểu, đặc quyền PRO, hành trình, video giới thiệu, ảnh quán học viên, ảnh lời khen | `src/data/home.ts` |
| **Gói khóa học theo mô hình** (vốn, giá, giá mở bán, quà tặng, khóa trong gói), thời gian ưu đãi | `src/data/packages.ts` |
| Khóa lẻ theo chuyên đề, giá | `src/data/courses.ts` |
| Bài học (trang học) | `src/data/lessons.ts` |
| Công cụ | `src/data/tools.ts` |
| Hoạt động, video ngắn | `src/data/activity.ts` |
| Danh sách bài Blog | `src/data/blog.ts` · nội dung bài: `src/content/blog/` |

Sửa xong chạy `npm run dev` để xem, đẩy lên GitHub là Vercel tự cập nhật.

## Deploy

- **Vercel:** Import repo → Framework *Next.js* → thêm biến môi trường → Deploy.
- **VPS (Docker):** bật `output: 'standalone'` trong `next.config.ts`, rồi:
  ```bash
  docker build -t saly-academy-web .
  docker run -d -p 3000:3000 --env-file .env.local saly-academy-web
  ```
  Đặt sau Caddy/Nginx để có HTTPS.

## Việc tiếp theo cho Dev

Xem **[docs/HUONG-DAN-DEV.md](docs/HUONG-DAN-DEV.md)** – các điểm cần nối hệ thống (đăng nhập, thanh toán, video, CMS), quy ước giao diện và danh sách nội dung còn chờ chốt. Các vị trí cần làm tiếp được đánh dấu `TODO` trong code (`grep -rn TODO src`).

## Bản quyền

© SaLy Group. Nội dung, hình ảnh và thương hiệu thuộc Công ty TNHH Thương mại và Dịch vụ Sa Ly Group.
