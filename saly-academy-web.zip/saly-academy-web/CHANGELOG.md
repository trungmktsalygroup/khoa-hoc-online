# Nhật ký thay đổi

## 1.3.1 – 07/10/2026
- **Chuẩn hóa heading toàn site:** mỗi trang 1 H1, đi tuần tự không nhảy cấp (đã quét 18 trang, máy tính và điện thoại). Trang Khóa học: tên 4 gói lên H2 (trước bị nhảy H1 → H3). Bài Blog: chỉ còn heading của bài + H2 "Bài viết liên quan" + H3 tên bài liên quan; nhãn "Trả lời nhanh" là chữ thường.
- **Trang tác giả `/author/ly-pham`** (thay `/giang-vien-ly-pham`, chuyển hướng 308): giữ giao diện, thêm khối **Bài viết của Ly Phạm**; dữ liệu ProfilePage + Person dùng chung với tác giả trong bài Blog; tên tác giả trong bài viết dẫn về trang này.

## 1.3.0 – 06/10/2026 · Visual Semantic + SEO / AEO / GEO
- **Chế độ nhẹ:** bỏ hiệu ứng lúc tải trang – tiêu đề đánh máy, số chạy từ 0, nội dung ẩn chờ cuộn mới hiện, thẻ nổi lơ lửng, huy hiệu xoay. Mọi nội dung hiển thị đủ ngay khi tải (Google chụp trang và máy yếu đều thấy đúng). Tường lời khen chỉ tự chạy trên màn hình lớn. Giữ hiệu ứng khi rê chuột/bấm.
- **Dữ liệu có cấu trúc (schema.org):** tổ chức giáo dục (toàn site); câu hỏi thường gặp (trang chủ, trang khóa học, bài blog); khóa học có giá, hình thức học, kết quả học; danh sách khóa học; đường dẫn điều hướng; bài blog có tác giả, ngày đăng/cập nhật.
- **Blog trả lời trước:** khối “Trả lời nhanh” ngay dưới tiêu đề; ô “Áp dụng vào quán của bạn” cuối bài dẫn sang gói khóa học phù hợp.
- **Bài kiến thức mới:** “Mở quán cà phê, trà sữa cần bao nhiêu vốn? Vốn tham khảo theo 4 mô hình” – bảng vốn, 7 khoản chi, 4 bước chọn mô hình, 5 câu hỏi. Trang bán vẫn không công khai vốn; bài này đón người tìm kiếm rồi dẫn về chọn mô hình.
- `public/llms.txt`: tóm tắt website cho các trợ lý AI.

## 1.2.0 – 05/10/2026
- **Đồng bộ số liệu:** số lớn khối nền cam đổi 2.000+ → **6.000+**; mọi chỗ ghi 2.000+ (form học thử, ô Cộng đồng) dùng chung `SITE.stats.students`. Sửa “150+ công thức độc quyền” thành “150+ video bài giảng” (150+ là số video; sách là 130+ công thức). Các số 150+ video, 30+ bài miễn phí viết cứng đều chuyển sang `SITE.stats`.
- Trang học: trình phát video bài học hỗ trợ **Vimeo và YouTube** (dữ liệu theo từng bài); tạm dùng video YouTube mẫu. Ở môi trường xem thử chặn nhúng (link claude.ai) tự đổi sang ảnh bìa + mở video ở tab mới.
- **Trang Khóa học theo mẫu thiết kế mới:** đầu trang “Khóa học nổi bật – Khởi đầu vững vàng, Kinh doanh bền lâu” + dải 4 cam kết (Thực hành 100%, Công thức chuẩn vị, Hỗ trợ sau khóa học, Giảng viên kinh nghiệm); thẻ gói mới: tên mô hình chữ viết tay trên ảnh, biểu tượng từng gói, khung giá xanh/cam, quà tặng có biểu tượng, nút bo tròn có mũi tên, thẻ “Được chọn nhiều nhất” góc ảnh. Thêm font viết tay Pacifico.
- **Đổi tông xanh sáng, tươi hơn:** tiêu đề #14432A → #0A7D45; khối nền xanh #0E6B3D → #0B8148; màn hình đầu, nhãn PRO, tiêu đề FAQ, tiêu đề nền cam cùng tông mới. Giữ tương phản chữ đạt chuẩn đọc (≥ 4.5:1 cho chữ thường).
- **Điều chỉnh theo bộ Insight học viên Online 4 mô hình:**
  - Không công khai mức vốn cho khách tự so sánh: “Bước đầu tiên” đổi thành *“Bạn đang hình dung quán của mình thế nào?”* (Xe trà, quầy nhỏ · Quán bán mang đi · Quán có chỗ ngồi · Đầu tư lớn, bài bản); bỏ “Vốn dự kiến” và “% chi phí trên vốn” khỏi thẻ gói, bảng so sánh, trang khóa học. Mức vốn chỉ còn trong dữ liệu nội bộ cho Sale.
  - Mỗi gói có câu định vị, mục “Phù hợp nếu bạn…” và kết quả học viết lại theo insight (định hướng mô hình, nhóm món, menu, lộ trình – không đẩy bài toán tài chính).
  - Khối Nỗi lo đổi sang 4 pain trước chốt: chưa biết chọn mô hình, không biết học gì để bắt đầu bán, không biết xây menu/chọn món chủ lực, sợ học Online chỉ có video; hình minh họa đổi từ “chi phí/doanh thu” sang “nên mở mô hình nào / học cái nào trước”.
  - Form tư vấn hỏi “Mô hình bạn đang quan tâm” thay cho số vốn; câu hỏi thường gặp về vốn đổi thành “Chưa biết nên mở mô hình nào thì học gói nào?”.
- **Sắp xếp lại trang chủ theo hành trình khách:** Biết (màn hình đầu) → Đồng cảm (nỗi lo) → Giải pháp (lộ trình 4 bước) → Chọn gói (chọn số vốn) → Yên tâm (đặc quyền) → Tin (2.000+ học viên, câu chuyện + lời nhắn gộp 1 khối) → Xem trước (video) → Người dạy (hành trình Cô Ly) → Gỡ băn khoăn (câu hỏi) → Chốt (form tư vấn). Bỏ khối gói lặp lại; trang ngắn hơn khoảng 15%.
- Trang chủ: làm lại khối **Đặc quyền học viên** dạng ô ảnh – Trợ giảng hỗ trợ 1-1, Học trọn đời, Setup menu & giá bán, Cộng đồng chủ quán; mỗi quyền lợi có ảnh thật và nhãn minh họa.
- **Trang thông tin khóa học** `/khoa-hoc/[gói]` cho 4 gói theo mô hình: giá & đăng ký, kết quả sau khóa học, chương trình học (mở từng chuyên đề, có bài học thử), quyền lợi & quà tặng, giảng viên, học viên, câu hỏi, gợi ý gói khác, thanh đăng ký cố định trên điện thoại; dữ liệu có cấu trúc Course cho Google. Thẻ gói, khối chọn vốn và trang chủ dẫn thẳng vào trang này.
- Rà soát giao diện 11 trang × 5 độ rộng (1440 / 1024 / 768 / 390 / 360): sửa tiêu đề “Loại khóa học” đè lên viền khung, các nút chủ đề tư vấn bị đẩy ra ngoài màn hình (trang Cô Ly), trang chủ bị trượt ngang trên điện thoại, số thứ tự “Đọc nhiều nhất” tràn ô, nút Combo sách tràn chữ, huy hiệu FREE lấn nút ở màn hình 360px; bố cục máy tính bảng (768px) cho khối chọn vốn, video, đặc quyền, học viên, hành trình, lộ trình, video ngắn, form tư vấn.
- Mỗi gói thêm **“Học xong, bạn làm được”**, **quà tặng kèm** và **quyền lợi** (đánh dấu điểm nổi bật riêng của gói); cửa sổ **Xem chi tiết gói**; **bảng so sánh 4 gói** trên trang Khóa học.
- Khối chọn vốn hiển thị kết quả học, số khóa / quyền lợi / quà tặng và lý do nên học theo mô hình.
- **Bán theo mô hình:** 4 gói khóa học theo mô hình quán (Xe trà · Coffee & Tea mang đi · Coffee & Tea ngồi lại · Lộ trình trọn bộ) theo chính sách bán mới – vốn dự kiến, học phí, % chi phí trên vốn, giá mở bán 10/10–20/10, quà tặng, danh sách khóa trong gói.
- Trang Khóa học: gói theo mô hình là sản phẩm chính, khóa lẻ theo chuyên đề xếp phía dưới.
- Khối chọn số vốn (trang chủ) dùng đúng 4 mức vốn của chính sách, nút dẫn tới gói tương ứng (`/khoa-hoc?goi=`).
- Giỏ hàng & thanh toán nhận cả gói và khóa lẻ; tự áp giá mở bán và quà tặng trong thời gian ưu đãi.
- Màn hình đầu trang chủ mới: tiêu đề, lời Cô Ly, form Đăng ký học thử / Đăng nhập.

## 1.1.0 – 03/10/2026
**Trang chủ (theo nhận diện saly.academy / lypham.vn)**
- Màn hình đầu: ảnh Cô Ly tách nền, lát cam và 2 thẻ số liệu nổi lên – xuống; chữ nhỏ lại, nhiều khoảng trắng.
- Video giới thiệu YouTube (tải nhẹ, bấm mới phát) + hàng **SaLy Video** (video ngắn, trình xem dọc kiểu TikTok).
- Khối **Nỗi lo**: thẻ viền đỏ dấu ✕, hình minh họa trôi hai bên.
- **Lộ trình 4 bước**: xuất hiện lần lượt 1 → 4, đường nối tự vẽ, hiệu ứng rê chuột.
- **Đặc quyền học viên PRO**, **Tấm gương học viên** (số liệu từ saly.academy), **tường lời khen** chạy lên/xuống (ảnh lypham.vn).
- Khối nền cam **“Trong suốt hơn 8 năm qua”**: 25 ảnh ghép đúng bố cục lypham.vn, số 2.000+ chạy, bấm xem ảnh lớn.
- **Hành trình Cô Ly** dạng ảnh zig-zag 2017 → 2023, số liệu đếm tăng dần.
- **Câu hỏi thường gặp** kiểu saly.academy (nền kem cam, logo, danh sách đánh số).
- Nút “Xem kế hoạch chi tiết” dẫn về `demo-app-qua-tang-mkt.vercel.app`.

**Trang mới / sửa lỗi**
- Trang **Giỏ hàng & thanh toán** `/thanh-toan` (mã giảm giá, chọn phương thức, màn hình hoàn tất).
- Blog: bài nổi bật **Công thức trà quýt tươi** (nội dung từ lypham.vn); bài viết đọc nội dung từ `src/content/blog`.
- Sửa lỗi trang học: ảnh video tràn toàn màn hình trên máy tính.
- Script `npm run preview:file` tạo bản xem thử 1 file HTML từ chính code.

## 1.0.0 – 03/10/2026
- Khởi tạo Next.js 15 + React 19 + Tailwind 4: 9 trang responsive (Trang chủ, Khóa học, Trang học, Công cụ, Hoạt động, Blog, Bài viết, Về Cô Ly Phạm, Đăng nhập).
- Số liệu chuẩn 8+ năm · 6.000+ học viên · hotline 0964 220 098; API `/api/lead` chuyển form về n8n.
