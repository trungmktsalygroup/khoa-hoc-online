# Hướng dẫn cho Dev – SaLy Academy Web

## 1. Nguyên tắc

- **Một bộ code responsive.** Mobile là ưu tiên (đa số khách vào từ điện thoại). Điểm ngắt chính `md` = 768px, menu đầy đủ từ `lg` = 1024px.
- **Màu, chữ, bo góc** chỉ lấy từ `src/app/globals.css` (`@theme`). Không tự đặt mã màu mới.
- **Nút cam** (`btn-accent`) chỉ dùng cho hành động chuyển đổi (Học thử miễn phí, Thêm vào giỏ, Hoàn thành & học tiếp, Gửi tư vấn). Mỗi màn hình chỉ một nút cam nổi bật.
- **Chữ cam trên nền trắng** dùng `text-accent-600` (#E5761F), không dùng #F29546 cho chữ nhỏ.
- Vùng bấm tối thiểu 44×44px, mọi ô nhập có nhãn, nút chỉ có biểu tượng phải có `aria-label`.
- Số liệu thương hiệu tập trung ở `SITE.stats` trong `src/data/site.ts`: **8+ năm**, **6.000+ học viên**, 150+ video, 30+ bài miễn phí. Hotline `SITE.hotline` = **0964 220 098**.

## 2. Dấu ấn thương hiệu (theo saly.academy)

- **Nhịp khối màu:** các phần nền sáng (xanh bạc hà, kem) xen kẽ khối **xanh lá tươi `#0B8148`**, nối với nhau bằng **đường cong** (`<Wave />`).
- **Họa tiết:** lát cam (`<OrangeSlice />`, dùng làm số thứ tự), ngôi sao lấp lánh (`<Sparkle />`, đặt cạnh nhãn phần), hai chiếc lá lấy từ logo (`<LeafMark />`). Dùng tiết chế, mỗi khu vực 1–2 họa tiết.
- **Nhãn cam dạng viên thuốc** cho mục đánh số (Đặc quyền #1…).
- **Cỡ chữ vừa phải, nhiều khoảng trắng:** H1 trang chủ 30/46px, H2 23/31px, chữ thân 15/16.5px; khoảng cách giữa các phần 64px (Mobile) / 112px (Desktop) qua lớp `.section`.
- Ảnh nhân vật Cô Ly tách nền (`ly-pham-nhan-vat.png`) đặt trên khối màu bo tròn.

## 3. Nguyên tắc nội dung theo Insight học viên Online

- **Không hiển thị mức vốn cho khách** (không bảng “mở mô hình X cần bao nhiêu tiền”, không % trên vốn). Khách chọn theo *kiểu mô hình*; vốn (`capital` trong `src/data/packages.ts`) chỉ dùng nội bộ cho Sale.
- Pain chỉ dùng để mở nhu cầu (mơ hồ về mô hình và lộ trình), sau đó chuyển ngay sang cảm giác “được định hướng đúng mô hình, đúng lộ trình”.
- Luôn xử lý rào cản “học Online chỉ có video”: nhấn mạnh lộ trình, trợ giảng hỗ trợ, xem lại lâu dài.

## 3b. Bảng màu

| Token | Mã | Dùng cho |
|---|---|---|
| `brand-700` | #0A7D45 | Tiêu đề (xanh tươi, tương phản 4.9:1 trên nền sáng) |
| `brand-600` | #0D824B | Xanh chính, chip đang chọn, nút phụ |
| `brand-500` | #0C864A | Nhãn PRO, nút Đăng nhập |
| `brand-100` | #E7F2EB | Nền chip, mục menu đang chọn |
| `accent-500` | #F29546 | Nút chuyển đổi |
| `accent-600` | #E5761F | Chữ cam |
| `accent-100` | #FFF4E8 | Nền hộp mẹo, khối tư vấn |
| `muted` | #5F5A54 | Chữ phụ (không làm nhạt hơn) |
| Gradient | `.bg-brand-h`, `.bg-brand-corner`, `.bg-brand-hero` | Thẻ giảng viên, khối khóa học, ảnh bìa trang Cô Ly |

Font: **Be Vietnam Pro** (next/font, có bộ chữ tiếng Việt).

## 4. Việc cần nối hệ thống (tìm `TODO` trong code)

| Hạng mục | Hiện trạng | Đề xuất |
|---|---|---|
| Đăng nhập | `AuthCard`/`HeroSignup` chuyển thẳng sang trang học mẫu; hiện ghi chú **DEMO** khi `SITE.demoMode = true` – đổi thành `false` khi nối tài khoản thật | NextAuth/Auth.js: Google + email/mật khẩu; bảo vệ `/hoc/*` bằng middleware |
| Giỏ hàng / thanh toán | Trang `/thanh-toan` đã có giao diện đủ 3 bước; giỏ lưu localStorage; đơn gửi tạm về `/api/lead`; mã giảm giá thử `SALY10` | API tạo đơn + cổng thanh toán (VietQR / MoMo / VNPay), kiểm tra mã giảm giá ở máy chủ, điền tài khoản nhận tiền trong `PAYMENT` (`src/data/site.ts`) |
| Video bài học | Đã nhúng **Vimeo** (`lesson.vimeo` trong `src/data/lessons.ts`, chưa có thì dùng `DEMO_VIMEO`) | Gán id/hash Vimeo cho từng bài; thêm tên miền web vào danh sách *cho phép nhúng* của Vimeo; dùng Vimeo Player API (`player.js`) để tự đánh dấu hoàn thành khi xem hết và lưu tiến độ |
| Khóa học, bài học, blog, hoạt động | `src/data/*.ts` | CMS (Payload/Strapi/WordPress headless) hoặc API nội bộ |
| Video ngắn TikTok | Ảnh ghép `video-shorts-sprite.jpg` + trình xem demo | Lấy danh sách qua TikTok Display API hoặc nhập link trong CMS; nhúng player thật |
| Form tư vấn | `POST /api/lead` → `LEAD_WEBHOOK_URL` | Webhook n8n hiện có, gắn `source` theo trang |
| Đề xuất công cụ | Form chưa gửi | Dùng chung `/api/lead` với `source: "de-xuat-cong-cu"` |
| Theo dõi | Chưa có | Umami/GA4: `view`, `start_trial`, `add_to_cart`, `submit_lead` |

## 5. Nội dung còn chờ chốt

1. ~~Mốc vốn ↔ mô hình~~ – đã theo chính sách bán theo mô hình (`src/data/packages.ts`). Còn chờ: tên đầy đủ của viết tắt **TP, MC & ĐX, ST & SC**; quà tặng gói Trọn bộ; danh mục quà gói Coffee & Tea (chính sách ghi “chưa chốt”); nội dung “Học xong làm được” cần đội đào tạo duyệt; khoảng vốn 70–100 triệu và 200–300 triệu thuộc gói nào.
2. Giá 2 khóa Nước ép trái cây 2026 và Trà Trái Cây [Update 2026] (`price: null`).
3. Danh mục Blog thật, nội dung bài viết, ngày đăng, thời gian đọc.
4. Bài đăng & tin nhanh trang Hoạt động. (Câu chuyện học viên trang chủ đã lấy từ saly.academy – kiểm tra lại số liệu trước khi chạy.)
5. Chính sách học lại miễn phí / hỗ trợ sau khóa học.
6. ~~Bộ lọc "Khóa học thử"~~ – đã đổi thành "Khóa học thử".
7. Danh sách công cụ thật (4/6 công cụ đang là đề xuất) và ảnh chụp app thật.
8. Ảnh gốc độ phân giải cao cho ảnh bìa khóa học và ảnh bài học.
9. Chưa thiết kế: trang chi tiết khóa học, bài PRO bị khóa với tài khoản FREE.
10. Thông tin tài khoản nhận chuyển khoản và mã QR cho trang thanh toán.

11. **Số liệu:** dùng chung `SITE.stats` trong `src/data/site.ts` (8+ năm · 6.000+ học viên · 150+ video · 30+ bài miễn phí) – khối nền cam cũng lấy 6.000+ từ đây; “330.000+ người theo dõi” và “200.000+ TikTok” lấy từ saly.academy – cần xác nhận.
12. **Blog trùng nội dung lypham.vn** (bài trà quýt tươi): chọn dẫn link về bài gốc hoặc viết lại để tránh trùng lặp SEO.
13. Thẻ công cụ “Mở Quán” (`src/data/tools.ts`) vẫn trỏ `mo-quan-app.vercel.app`; nút “Xem kế hoạch chi tiết” đã trỏ `demo-app-qua-tang-mkt.vercel.app`.

## 6. Ảnh chụp màn hình

Thư mục `docs/anh-chup/`: mỗi trang có bản Desktop (`_d`) và Mobile (`_m`).


## Visual Semantic, SEO, AEO, GEO

- **Trung tâm từng loại trang:** trang chủ = đăng ký học thử + chọn mô hình; trang Khóa học = 4 gói + bảng so sánh; trang gói = giá + nút đăng ký + kết quả học; bài blog = khối "Trả lời nhanh" rồi mới đến phần giải thích. Nhãn "Trả lời nhanh" là chữ thường (không phải H2) để không chen vào dàn ý tiêu đề của bài.
- **Không ẩn nội dung lúc tải trang** (không `opacity: 0` chờ cuộn, không số chạy từ 0, không chữ đánh máy). Hiệu ứng chỉ chạy khi người dùng rê chuột hoặc bấm.
- **Dữ liệu có cấu trúc** tạo bằng `src/lib/schema.ts` + `<JsonLd />`. Bài blog mới: điền `quickAnswer`, `faq`, `updated`, `packageSlug` trong file nội dung.
- **Thông tin quan trọng viết bằng chữ**, không chỉ nằm trong ảnh (giá, quyền lợi, kết quả học, câu chuyện học viên).
- Kiểm tra nhanh: Google Rich Results Test cho trang chủ, 1 trang gói, 1 bài blog; Search Console sau khi lên web thật.

## Quy tắc heading (bắt buộc)

- Mỗi trang đúng **1 H1**. Đi tuần tự H1 → H2 → H3…, **không nhảy cấp** (H1 sang H3, H2 sang H4).
- Nhãn trang trí (eyebrow, "Trả lời nhanh", "Mục lục bài viết", tên trong thẻ tác giả) **không dùng heading** – dùng `<p>`/`<span>`.
- **Trang bài viết Blog** chỉ có: H1 tên bài → H2/H3 của chính nội dung bài → H2 "Bài viết liên quan" → H3 tên từng bài liên quan. Không thêm heading nào khác (khung tác giả, ô khóa học, mục lục, chia sẻ đều không phải heading).
- Trang tác giả: `/author/ly-pham` (link cũ `/giang-vien-ly-pham` chuyển hướng vĩnh viễn 308). Khối "Bài viết của Ly Phạm": H2 + H3 tên bài.
- Kiểm tra nhanh: tiện ích HeadingsMap (Chrome) hoặc `document.querySelectorAll('h1,h2,h3,h4')`.
