import type { NextConfig } from 'next';

const nextConfig: NextConfig = {
  reactStrictMode: true,
  // Bật khi deploy VPS bằng Docker: output: 'standalone',
  // Trang Cô Ly chuyển sang dạng trang tác giả – giữ thứ hạng & liên kết cũ bằng chuyển hướng vĩnh viễn (301/308)
  async redirects() {
    return [{ source: '/giang-vien-ly-pham', destination: '/author/ly-pham', permanent: true }];
  },
  images: {
    formats: ['image/avif', 'image/webp'],
  },
};

export default nextConfig;
